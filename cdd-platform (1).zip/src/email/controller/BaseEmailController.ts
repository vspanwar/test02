import { BaseController } from "../../common/web/BaseController";

export abstract class BaseEmailController extends BaseController{

}