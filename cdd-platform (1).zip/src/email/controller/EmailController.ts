import { EmailService } from './../service/EmailService';

import { Request, Response } from 'express'
import { BaseEmailController } from './BaseEmailController';

export class EmailController extends BaseEmailController {
    private static instance: EmailController;
    private service:EmailService;

    private constructor(){
        super();
        this.service = new EmailService();
    }
    
    public static getInstance = () => {
        if (EmailController.instance == null) {
            EmailController.instance = new EmailController();
        }
        return EmailController.instance;
    }


    public async action(req: Request, res: Response) {
        console.log(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
