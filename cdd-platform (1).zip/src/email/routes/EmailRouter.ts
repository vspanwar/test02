import { EmailController } from '../controller/EmailController';
import { Router, NextFunction, Request, Response } from 'express';
import { Module } from './../../common/enums/PlatformEnums';
import { BaseRouter } from "../../common/web/BaseRouter";

export class EmailRouter extends BaseRouter {

    private controller:EmailController;
    /**
   * Initialize the Router
   */
    constructor() {
        super(Module.EMAIL);
        //this.controller = new AdminController();
    }


    onInit(router: Router) {
        console.log(' action ...');
        router.get('/action', this.action);

        
        // throw new Error("Method not implemented.");
    }

    public action(req: Request, res: Response) {
        EmailController.getInstance().action(req, res);
    }

}