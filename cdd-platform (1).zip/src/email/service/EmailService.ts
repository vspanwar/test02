import { BaseEmailService } from "./BaseEmailService";
import { EmailDao } from "../dao/EmailDao";


export class EmailService extends BaseEmailService{
    private dao:EmailDao;

    constructor(){
        super();
        this.dao = new EmailDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}