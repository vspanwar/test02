import { BaseEmailDao } from "./BaseEmailDao";


export class EmailDao extends BaseEmailDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}