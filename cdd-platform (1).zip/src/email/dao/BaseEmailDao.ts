import { BaseDao } from "../../common/core/BaseDao";

export abstract class BaseEmailDao extends BaseDao{

}