import { BaseMetricsDao } from "./BaseMetricsDao";

export class MetricsDao extends BaseMetricsDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}