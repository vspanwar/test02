import { BaseDao } from "../../common/core/BaseDao";

export abstract class BaseMetricsDao extends BaseDao{

}