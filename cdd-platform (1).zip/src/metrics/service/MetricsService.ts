import { MetricsDao } from './../dao/MetricsDao';
import { BaseMetricsService } from './BaseMetricsServie';


export class MetricsService extends BaseMetricsService{
    private dao:MetricsDao;

    constructor(){
        super();
        this.dao = new MetricsDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}