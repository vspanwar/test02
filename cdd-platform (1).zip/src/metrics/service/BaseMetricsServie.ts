import { BaseService } from "../../common/core/BaseService";

export abstract class BaseMetricsService extends BaseService{

}