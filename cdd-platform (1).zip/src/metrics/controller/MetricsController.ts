import {  MetricsService } from '../service/MetricsService';
import { BaseMetricsController } from "./BaseMetricsController";
import { Request, Response } from 'express';

export class MetricsController extends BaseMetricsController {
    private static instance: MetricsController;
    private service:MetricsService;

    private constructor(){
        super();
        this.service = new MetricsService();
    }
    
    public static getInstance = () => {
        if (MetricsController.instance == null) {
            MetricsController.instance = new MetricsController();
        }
        return MetricsController.instance;
    }

    

    public async action(req: Request, res: Response) {
        console.log(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
