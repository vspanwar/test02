import { BaseController } from "../../common/web/BaseController";

export abstract class BaseMetricsController extends BaseController{

}