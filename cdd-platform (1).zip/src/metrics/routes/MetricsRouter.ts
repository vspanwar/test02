import { MetricsController } from './../controller/MetricsController';
import { Router, NextFunction, Request, Response } from 'express';
import { Module } from '../../common/enums/PlatformEnums';
import { BaseRouter } from "../../common/web/BaseRouter";

export class MetricsRouter extends BaseRouter {

    /**
   * Initialize the Router
   */
    constructor() {
        super(Module.METRICS);
        //this.controller = new AdminController();
    }


    onInit(router: Router) {
        console.log(' action ...');
        router.get('/action', this.action);

        
        // throw new Error("Method not implemented.");
    }

    public action(req: Request, res: Response) {
        MetricsController.getInstance().action(req, res);
    }

}