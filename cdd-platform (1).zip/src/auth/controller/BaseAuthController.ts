import { BaseController } from "../../common/web/BaseController";

export abstract class BaseAuthController extends BaseController{

}