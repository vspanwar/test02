import {Request, Response} from 'express';
import {SecurityService} from '../service/security/SecurityService';
import { LoggingUtil } from './../../common/utils/log4js';
import { BaseController } from "../../common/web/BaseController";

export class SecurityController extends BaseController{

    private static instance: SecurityController
    public static getInstance():SecurityController{
        if(SecurityController.instance == null){
            SecurityController.instance = new SecurityController()
        }
        return SecurityController.instance
    }

    public async authenticateAadUser(req:Request, res:Response, botUser:Boolean){
        LoggingUtil.log.info("Inside controller..");
        let ts = SecurityService.getInstance();
        ts.authenticateUser(req, res, botUser).then(data => {
        //logger.debug("Result :: " +data["status"]);
        }).catch(error => {
            LoggingUtil.log.error("Error: ", error);
        }) ;
    }

    private constructor(){
        super()
    }
        


}