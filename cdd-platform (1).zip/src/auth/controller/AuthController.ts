import { AuthService } from '../service/AuthService';
import { BaseAuthController } from "./BaseAuthController";
import { Request, Response } from 'express';

export class AuthController extends BaseAuthController {
    private static instance: AuthController;
    private service:AuthService;

    private constructor(){
        super();
        this.service = new AuthService();
    }
    
    public static getInstance = () => {
        if (AuthController.instance == null) {
            AuthController.instance = new AuthController();
        }
        return AuthController.instance;
    }

    

    public async action(req: Request, res: Response) {
        console.log(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
