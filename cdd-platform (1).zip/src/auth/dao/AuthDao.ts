import { BaseAuthDao } from "./BaseAuthDao";

export class AuthDao extends BaseAuthDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}