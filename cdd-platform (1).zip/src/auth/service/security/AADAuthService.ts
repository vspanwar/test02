import { DirectLineTokenService } from './DirectLineTokenService';
import { Logger } from "log4js";
import { LoggingUtil } from './../../../common/utils/log4js';
import { HttpUtil } from './../../../common/utils/HttpUtil';



export class AADAuthService {
    private static instance: AADAuthService;

    private constructor() {
    }

    public static getInstance(): AADAuthService {
        LoggingUtil.log.info("Inside AADAuth");
        if (AADAuthService.instance == null) {
            LoggingUtil.log.info("Inside AADAuth1");
            // AADAuthService.instance = new AADAuthService();
            this.instance = new AADAuthService();
        }
        // return AADAuthService.instance;
        return this.instance;
    }

    public async sleepRandom(ms: number) {
        return new Promise(resolve => {
            setTimeout(resolve, ms)
        })
    }
    public async login(tenantOrg: any, userCredentials: any): Promise<any> {
        LoggingUtil.log.info("AADAuthService Enetred in the login  : " + JSON.stringify(tenantOrg));
        try {
            let data: any = {}
            if (process.env.devAuthentication === 'true') {
                data.status = "success"
            } else {
                data = this.tenantDeatils(tenantOrg, userCredentials);
            }
            LoggingUtil.log.debug("### Tenant Data Query Result:" + JSON.stringify(data));
            if (data.status === "success") {
                /*
                var result : any = JSON.parse(await HttpUtil.MShttpPostCall(data.url, this.obj_to_query(data.queryData)));
                console.log("### Authentication Result:" + JSON.stringify(result))
                if(!result.error) {
                    var response = {
                        'status': 200,
                        'message': {
                            'bot_refresh_token': result.refresh_token,
                            'bot_access_token': result.access_token,
                            'bot_user': userCredentials.userName,
                            'bot_expires_on': result.expires_on,
                            'directlineSecrect': data.directlineSecrect
                        }
                    }
                    return response;
                } else {
                    return result;
                }*/
                var response = {
                    'status': 200,
                    'message': {
                        'bot_refresh_token': "refresh_token",
                        'bot_access_token': "access_token",
                        'bot_user': userCredentials.userName,
                        'bot_expires_on': 1800,
                        'directlineSecrect': data.directlineSecrect
                    }
                }
                return response;
            } else {
                return data;
            }
        } catch (e) {
            return { "status": 100, "message": "error in your request" };
        }
    }

    private tenantDeatils = (tenantOrg: any, userCredentials: any): any => {
        var tDetails: any = {
            status: "success",
            url: "https://login.microsoftonline.com/" + tenantOrg.tenantDomain + "/oauth2/token",
            queryData: {
                "grant_type": "password",
                "resource": "https://graph.windows.net",
                "client_id": tenantOrg.appId,
                "username": userCredentials.userName,
                "password": userCredentials.password,
                "scope": "openid"
            }
        };
        if (tenantOrg === undefined) {
            tDetails = {
                "status": "error",
                "message": "invalid user name"
            };
        }
        return tDetails;
    }

    private obj_to_query: any = (obj: any) => {
        var parts = [];
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]));
            }
        }
        return parts.join('&');
    }
}


