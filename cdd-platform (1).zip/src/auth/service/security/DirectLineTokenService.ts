import { LoggingUtil } from './../../../common/utils/log4js';
import { HttpUtil } from './../../../common/utils/HttpUtil';


export class DirectLineTokenService {

    public static instance: DirectLineTokenService;
    private constructor() {
    }

    public static getInstance(): DirectLineTokenService {
        if (DirectLineTokenService.instance == null) {
            DirectLineTokenService.instance = new DirectLineTokenService();
        }
        return DirectLineTokenService.instance;
    }

    public async getDirectlineToken(directlineSecret: any): Promise<any> {
        try {
            if (directlineSecret) {
                LoggingUtil.log.debug("getDirectlineSecret:", directlineSecret)
                var baseApi = "https://directline.botframework.com";
                var query = "/v3/directline/tokens/generate";
                var header = {
                    'Authorization': `Bearer ${directlineSecret}`,
                    'Content-Type': 'application/json',
                }
                var result = await HttpUtil.post(baseApi + query, null, header);
                return result;

            } else {
                return { "error": "error in your request, could not able to generate tokens" };
            }


        }
        catch (e) {
            LoggingUtil.log.error(e);
            return { "error": "error in your request, could not able to generate tokens" };
        }
    }

    public getDirectLineSecret(tenantChannelData: any) {
        LoggingUtil.log.debug("getDirectLineSecret in the login  : " + JSON.stringify(tenantChannelData))
        let channelData = tenantChannelData.channel
        LoggingUtil.log.debug("getDirectLineSecret in the login  : " + channelData)
        for (let channel of channelData) {
            if(channel.channelId == 1) {
                return channel.secret;
            }
        }
    }
}