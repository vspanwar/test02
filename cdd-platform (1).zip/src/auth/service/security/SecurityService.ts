import { Request, Response } from 'express';
import { AADAuthService } from './AADAuthService';
import { DirectLineTokenService } from './DirectLineTokenService';
import { TenantChannelService } from '../tenant/TenantChannelService';
import { LoggingUtil } from './../../../common/utils/log4js';
import { BaseAuthService } from "./../BaseAuthService";


export class SecurityService extends BaseAuthService{
    private static instance: SecurityService;

    private constructor() {super() }


    public static getInstance(): SecurityService {
        // if (SecurityService.instance == null) {
        if (!SecurityService.instance) {
            this.instance = new SecurityService()
        }
        return this.instance;
    }

    public async authenticateUser(req: Request, res: Response, botUser: Boolean): Promise<any> {
        const tenantId = req.params.tenantId;
        const botId = req.params.botId;
        var userCredentials = {
            "userName": req.body.username,
            "password": req.body.password
        };
        let ts = TenantChannelService.getInstance();
        let domainName = (userCredentials.userName).split("@")[1];
        let responses = ts.getTenantChannelData(tenantId-1,botId-1).then(tenantChannels => {
            LoggingUtil.log.debug(` Tenant Channels ${tenantChannels}`)
            if (tenantChannels != undefined) {
                if (botUser == true) {
                    LoggingUtil.log.debug(` Tenant Channels Found: ${tenantChannels}`)
                    this.botUserAuthentication(tenantChannels, userCredentials, res);
                } else {
                    LoggingUtil.log.debug(` Tenant Organization Found: ${tenantChannels}`)
                    this.userAuthentication(tenantChannels, userCredentials, res);
                }
            } else {
                    LoggingUtil.log.error('Tenant Channel not found');
            }
        })
    }

    private botUserAuthentication(tenantOrg: any, userCredentials: any, res: Response) {
        LoggingUtil.log.debug(`  Bot Name ${tenantOrg.botName}`)
        LoggingUtil.log.info(` Dev  Authentication ${process.env.devAuthentication}`)

        return this.botUserAuthenticationAzure(tenantOrg, userCredentials, res);
    }

    private userAuthentication(tenantOrg: any, userCredentials: any, res: Response) {
        LoggingUtil.log.debug(` Bot Name ${tenantOrg.botName}`)

        return this.userAuthenticationAzure(tenantOrg, userCredentials, res);      
    }

    private botUserAuthenticationAzure(tenantOrg: any, userCredentials: any, res: Response) {
        LoggingUtil.log.info("botUserAuthenticationAzure")
        let ds = AADAuthService.getInstance()
        let authResponse = ds
            .login(tenantOrg, userCredentials)
            .then(tb => {
                var payload = { id: userCredentials.userName };
                var response = tb;
                //logger.debug(`Response ${JSON.stringify(tb)}`)
                if (tb.status === 200) {


                    response = {
                        'message': {
                            'bot_refresh_token': tb.refresh_token,
                            'bot_access_token': tb.access_token,
                            'bot_user': userCredentials.userName,
                            'bot_expires_on': tb.expires_on
                        }
                    }

                    
                    if (tenantOrg.defaultLang) {
                        response.message.defaultLang = tenantOrg.defaultLang;
                    }
                    if (tenantOrg.langs) {
                        response.message.langs = tenantOrg.langs;
                    }
                        
                    
                    let dsService = DirectLineTokenService.getInstance();
                    let dsSecret = dsService.getDirectLineSecret(tenantOrg)
                    LoggingUtil.log.info("### dsSecret:" + dsSecret)
                    dsService.getDirectlineToken(dsSecret)
                        .then(dsResults => {
                            LoggingUtil.log.debug("### dsResults:" +  JSON.stringify(dsResults))
                            let directlineObj = dsResults
                            if (directlineObj.token) {
                                response.message.directLineToken = directlineObj.token;
                                res.status(200).send(response);
                            } else {
                                let errResponse = {
                                    "message": "Directline Token generation failed",
                                    "error": directlineObj
                                }
                                res.status(401).send(errResponse);
                            }

                        })

                } else {
                    LoggingUtil.log.error("Error", tb)
                    response = tb;
                    res.status(401).send(response);
                }
            });

    }

    private userAuthenticationAzure(tenantOrg: any, userCredentials: any, res: Response) {
        LoggingUtil.log.info("userAuthenticationAzure")
        let ds = AADAuthService.getInstance()
        let authResponse = ds
            .login(tenantOrg, userCredentials)
            .then(tb => {
                var payload = { id: userCredentials.userName };
                var response = tb;
                if (tb.status === 200) {
                    response = {
                        'message': {
                            'bot_refresh_token': tb.refresh_token,
                            'bot_access_token': tb.access_token,
                            'bot_user': userCredentials.userName,
                            'bot_expires_on': tb.expires_on
                        }
                    }
                    res.status(200).send(response);
                } else {
                    LoggingUtil.log.error("Error", tb)
                    response = tb;
                    res.status(401).send(response);
                }
            });

    }


    obj_to_query: any = (obj: any) => {
        var parts = [];

        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                LoggingUtil.log.debug(key + " " + obj[key])
                parts.push(encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]));
            }
        }
        return parts.join('&');
    }

}