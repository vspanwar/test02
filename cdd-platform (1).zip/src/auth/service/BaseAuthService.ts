import { BaseService } from "../../common/core/BaseService";

export abstract class BaseAuthService extends BaseService{

}