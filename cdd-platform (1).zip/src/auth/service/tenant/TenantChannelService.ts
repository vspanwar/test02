import { TenantService } from './../../../pltaform/service/TenantService';
import { LoggingUtil } from './../../../common/utils/log4js';

export class TenantChannelService {

    public static tenantChannelService: TenantChannelService;

    private constructor() {
    }

    public static getInstance(): TenantChannelService {
        if (TenantChannelService.tenantChannelService == null) {
            TenantChannelService.tenantChannelService = new TenantChannelService();
        }
        return TenantChannelService.tenantChannelService;
    }

    public async getTenantChannelData(tenantId: any,BotId: any): Promise<any> {
        const cfg = TenantService.getTenantCfg();
        LoggingUtil.log.debug("getTenantChannelData::: "  + cfg[tenantId].tenantBot[BotId]);

        return cfg[tenantId].tenantBot[BotId];
    }




}