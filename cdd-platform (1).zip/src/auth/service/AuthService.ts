import { AuthDao } from '../dao/AuthDao';
import { BaseAuthService } from "./BaseAuthService";

export class AuthService extends BaseAuthService{
    private dao:AuthDao;

    constructor(){
        super();
        this.dao = new AuthDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}