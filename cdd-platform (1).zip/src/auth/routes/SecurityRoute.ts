import{Router, Request, Response, NextFunction} from 'express';
import{SecurityController} from '../controller/SecurityController';


export class SecurityRoute{
    private static router:Router
    private constructor(){
        SecurityRoute.router = Router()
    }
    public static getInstance():Router{
        if(SecurityRoute.router == null){
            let sr = new SecurityRoute()
            sr.init()
        }            
        return SecurityRoute.router
    }

    public authenticateAadUser(req:Request, res:Response, next:NextFunction){
        let securityHandler = SecurityController.getInstance()
        securityHandler.authenticateAadUser(req,res, false)
    }

    public authenticateBotUser(req:Request, res:Response, next:NextFunction){
        let securityHandler = SecurityController.getInstance()
        securityHandler.authenticateAadUser(req,res, true)
    }

    private init(){
        SecurityRoute.router.post('/auth/aad',  this.authenticateAadUser);
        SecurityRoute.router.post('/auth/botuser/:tenantId/:botId',  this.authenticateBotUser);
    }

}