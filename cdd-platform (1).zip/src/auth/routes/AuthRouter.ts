import { LoggingUtil } from './../../common/utils/log4js';
import { AuthController } from './../controller/AuthController';
import { Router, NextFunction, Request, Response } from 'express';
import { Module } from '../../common/enums/PlatformEnums';
import { BaseRouter } from "../../common/web/BaseRouter";
import { SecurityRoute } from './SecurityRoute';

export class AuthRouter extends BaseRouter {

   
    /**
   * Initialize the Router
   */
    constructor() {
        super(Module.AUTH);
        //this.controller = new AdminController();
    }


    onInit(router: Router) {
        LoggingUtil.log.debug(' action ...');
        router.get('/action', this.action);
        router.use('/security', SecurityRoute.getInstance())        
        // throw new Error("Method not implemented.");
    }

    public action(req: Request, res: Response) {
        AuthController.getInstance().action(req, res);
    }

}