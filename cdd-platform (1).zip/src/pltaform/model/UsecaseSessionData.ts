import { Activity } from "botframework-schema";
import { LoggingUtil } from "../../common/utils/log4js";
import { DialogUtils } from "../dialogs/impl/DialogUtils";

export class UsecaseSessionData {
    private static instance: UsecaseSessionData = null;
    public static getInstance(): UsecaseSessionData {
        if (UsecaseSessionData.instance == null) {
            UsecaseSessionData.instance = new UsecaseSessionData();
        }
        return UsecaseSessionData.instance;
    }
    public async startData(activity:Partial<Activity>, useCase:string){
        
        let payload={}
        //payload['userId']=await DialogUtils.getInstance().getUserName(activity)
        payload['conversationId']=activity.conversation.id
        payload['usecase']=useCase,
        payload['userUtterance']=activity.text
        payload['date']=new Date()
        
        
        LoggingUtil.log.debug("insert UseCaseHistory payload" + JSON.stringify(payload))
        
        return payload
    }
}