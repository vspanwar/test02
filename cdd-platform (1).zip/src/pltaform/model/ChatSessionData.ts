import { Activity } from "botframework-schema";
import { LoggingUtil } from "../../common/utils/log4js";
import { DialogUtils } from "../dialogs/impl/DialogUtils";

export class ChatSessionData {
    private static instance: ChatSessionData = null;
    public static getInstance(): ChatSessionData {
        if (ChatSessionData.instance == null) {
            ChatSessionData.instance = new ChatSessionData();
        }
        return ChatSessionData.instance;
    }
    public async startData(activity:Partial<Activity>){
        let finalPayload={}
        finalPayload['conversationId']=activity.conversation.id
        let payload={}
      //  payload['from']=await DialogUtils.getInstance().getUserName(activity)
        payload['message']=activity.text
        payload['date']=new Date()
        finalPayload['updatePayload']=payload['from'] + " :: " +  payload['message'] 
        
        
        


        LoggingUtil.log.debug("insert chatHistory payload" + JSON.stringify(payload))
        
        return finalPayload
    }

    public async setData(activity:Partial<Activity>){
        
        let payload={}
        
        payload['conversationId']=activity.conversation.id
        
        payload['chat']={
            'date':new Date(),
            //'from': await DialogUtils.getInstance().getUserName(activity),
            'Message':activity.text
            
        }


        LoggingUtil.log.debug("insert usecase payload" + JSON.stringify(payload))
        
        return payload
    }


}