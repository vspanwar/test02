import { DialogContext } from 'botbuilder-dialogs';
import { WebRequest, WebResponse, TurnContext } from 'botbuilder';

export class testData {
   
    public po_number: string;
    public inv_ref_number: string;
    public channelId:string;
    public userName:string;
    public reqBody:any;
    public intent:string;
}