import { DialogContext, DialogSet } from 'botbuilder-dialogs';
import { WebRequest, WebResponse, TurnContext } from 'botbuilder';

export class RequestData {
    public webRequest: WebRequest;
    public webResponse: WebResponse;
    public turnContext: TurnContext;
    public dialogContext: DialogContext;
    public tenantId: string;
    public botId: string;
    public channelId:string;
    public userName:string;
    public reqBody:any;
    public intent:string;


    public po_number:string;
    public po_currency:string;
    public comp_code:string;
    public vendor_name:string;
    public vendor_number:string;
    public domaincode:string;
    public process_name:string;
    public document_id:string;
    public business_rule: string;
    public invoice_ref:string;
    public invoice_amount:string;
    public bol_number:string;
    public email:string;
    public browser_language:string;
    public date:string;
    public dialogSet: DialogSet;


     //public test: string;
    // public test1: string;

}