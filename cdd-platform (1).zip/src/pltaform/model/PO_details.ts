export class po_data {
    public details = {
        // "po_number" : "",
        // "po_currency":"",
        //  "comp_code":"",
        // "vendor_name":"",
        // "vendor_number":"",
        // "domaincode":"",
        // "process_name":"",
        // "document_id":"",
        // "business_rule":"",  
        // "invoice_ref":"",
        // "invoice_amount":"",

        // "browser_language":"",
        // "email": "",

    //     "date":"",
    //     "bol_number":"",   
    //    "qty_attempt":0,
    //    "docid_result":""
      
      
       
    }
    // store the value from sap tool
   // public static get_po_details = []

    // to store the item quantity 
   // public static req_data = []

   // public static sap_req_data = []

   // public static transcript = []
}