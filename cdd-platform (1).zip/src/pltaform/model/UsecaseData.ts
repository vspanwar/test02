import { LoggingUtil } from "../../common/utils/log4js";

export class UsecaseData {
    private static instance: UsecaseData = null;
    public static getInstance(): UsecaseData {
        if (UsecaseData.instance == null) {
            UsecaseData.instance = new UsecaseData();
        }
        return UsecaseData.instance;
    }
    public setData(userName:any,usecase:string, conversationId: string){
        
        let payload={}
        payload['conversationId']=conversationId
        payload['userId']=userName
        payload['useCase']=usecase
        payload['date']=new Date()
        payload['sessionID']=""
        payload['region']=""
        payload['language']=""
        payload['ticketNumber']=""
        


        LoggingUtil.log.debug("insert usecase payload" + JSON.stringify(payload))
        
        return payload
    }
}