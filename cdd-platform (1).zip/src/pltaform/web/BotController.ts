import { LoggingUtil } from './../../common/utils/log4js';
import { BasePlatformBot } from './../core/bot/BasePlatformBot';
import { PlatformCache } from './../core/PlatformCache';
import { PlatformApplicationContext } from './../core/PlatformApplicationContext';
import { NextFunction, Request, Response } from 'express';

export class BotController {

    public static listen(req: Request, res: Response, next: NextFunction) {
        const cache = PlatformCache.getInstance();
        const tenantId = req.params.tenantId;
        const botId = req.params.botId;
        const data =  PlatformApplicationContext.getInstance().getRequestData();
        data.webRequest = req;
        data.webResponse = res;
        data.tenantId = tenantId;
        data.botId =botId;
        data.userName=req.body.from.name;
        data.channelId=req.body.channelId;
        data.reqBody=req.body;

        LoggingUtil.log.info(`Messages from Tenant: ${tenantId} -> Bot: ${botId} ->user: ${req.body.from.name}`);
        if (tenantId != null && botId != null) {
            const bot:BasePlatformBot = cache.getBot(botId);
            req.body.tenantId = tenantId;
            req.body.botId = botId;
            bot.adapter.process(req,res,async (context) => {
                await bot.run(context);
            });
        }
    }
}