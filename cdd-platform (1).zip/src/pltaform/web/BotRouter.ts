import { Module } from './../../common/enums/PlatformEnums';
import { Router, NextFunction, Request, Response } from 'express';
import { BotController } from './BotController';
import { BaseRouter } from '../../common/web/BaseRouter';

export class BotRouter extends BaseRouter {
  
  /**
   * Initialize the Router
   */
    constructor( module:Module) {
        super(module);
    }


    /**
       * Take each handler, and attach to one of the Express.Router's
       * endpoints.
       */
    onInit(router:Router) {
      router.post('/messages/:tenantId/:botId', BotController.listen);
    }

}
