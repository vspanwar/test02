import { LoggingUtil } from './../../common/utils/log4js';
import { PlatformApplicationContext } from './../core/PlatformApplicationContext';
import { BaseDialog } from './BaseDialog';
import { InputHints, MessageFactory } from 'botbuilder';
//import { StatePropertyAccessor, TurnContext } from 'botbuilder-core';
import { ConversationState, MemoryStorage, UserState, Storage, StatePropertyAccessor } from 'botbuilder';
import {
    ComponentDialog,
    DialogContext,
    DialogSet,
    DialogState,
    DialogTurnResult,
    DialogTurnStatus,
    TextPrompt,
    WaterfallDialog,
    WaterfallStepContext
} from 'botbuilder-dialogs';
import { AdminService } from "../service/AdminService"

import { BaseRecognizer } from '../../common/utils/nlp/BaseRecognizer';
import { DC_PO_check } from './impl/platform/DC_PO_check';
import { PlatFormCarType } from './impl/platform/PlatformCards';
import { DC_Greetings } from './impl/platform/DC_Greetings';
import { UsecaseSessionData } from '../model/UsecaseSessionData';
import { TranslatorService } from '../service/TranslatorService';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';
import { Datastore } from './impl/Datastore';
import { DialogUtils } from './impl/DialogUtils';
import { JsonConfigDao } from '../../admin/dao/JsonConfigDao';

export class RootDialog extends BaseDialog {

    private dialogCache: Map<string, BaseDialog>;
    constructor(id: string, dialogs: BaseDialog[], private recognizer: BaseRecognizer) {
        super(id);
        this.dialogCache = new Map<string, BaseDialog>();
        const MAIN_WATERFALL_DIALOG = id;

        for (var i = 0; i < dialogs.length; i++) {
            this.addDialog(dialogs[i]);
            this.dialogCache.set(dialogs[i].id, dialogs[i]);
        }

        this.addDialog(new TextPrompt('TextPrompt'))
        this.addDialog(new DC_PO_check(PlatFormCarType.po_cehck))
        this.addDialog(new DC_Greetings(PlatFormCarType.Greeting))      
        //this.addDialog(new PlatformTimeOut("Timeout"))

        this.addDialog(new WaterfallDialog(MAIN_WATERFALL_DIALOG, [
            // this.introductionStep.bind(this),
            this.findIntentAndDialog.bind(this),
            this.finalStep.bind(this)]));

        this.initialDialogId = MAIN_WATERFALL_DIALOG;

    }
    private async findIntentAndDialog(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {



        let text = stepContext.context.activity.text



        let payload = {
            po_number: "",
            po_currency: "",
            comp_code: "",
            vendor_name: "",
            vendor_number: "",
            domaincode: "",
            process_name: "",
            document_id: "",
            business_rule: "",
            invoice_ref: "",
            invoice_amount: "",
            header_text: "",
            bol_number: "",
            email: "",
            browser_language: "",
            date: "",
            transcript: [],
            req_data: [],
            get_po_details: [],
            Form_submite_text: "The form has been submitted!"
        }

        if(stepContext.context.activity.channelId == 'msteams'||stepContext.context.activity.channelId == 'emulator'){
        //if(stepContext.context.activity.channelId == 'msteams'){
            
            const intentResult = await this.recognizer.recognize(stepContext.context);
            PlatformApplicationContext.getInstance().getRequestData().intent = intentResult.topIntent;
            LoggingUtil.log.debug(`intentResult.topIntent in root ${intentResult.topIntent}`);
           
            if(intentResult.topIntent == 'HR.Greeting' && intentResult.topScore>0.80){                
                return await stepContext.beginDialog("HrGreeting", {});
            }
            else if(intentResult.topScore<0.80){
                await stepContext.context.sendActivity("Please type a greeting like \"Hello\" or \"Good Morning\" to get started.");
                return await stepContext.endDialog()
            }
        }

        if (text == '' || text == ' ' || text == "hi") {

            if (stepContext.context.activity.channelId == 'directline') {

                payload.po_number = stepContext.context.activity.channelData.sendParamData.bpn_purchaseOrder
                payload.po_currency = stepContext.context.activity.channelData.sendParamData.bpn_currency
                payload.comp_code = stepContext.context.activity.channelData.sendParamData.bpn_companyCode
                payload.vendor_name = stepContext.context.activity.channelData.sendParamData.bpn_vendorName
                payload.vendor_number = stepContext.context.activity.channelData.sendParamData.bpn_vendorNumber
                payload.domaincode = stepContext.context.activity.channelData.sendParamData.domainCode
                payload.process_name = stepContext.context.activity.channelData.sendParamData.bpn_processName
                payload.document_id = stepContext.context.activity.channelData.sendParamData.bpn_documentID
                payload.business_rule = stepContext.context.activity.channelData.sendParamData.bpn_businessRule
                payload.invoice_ref = stepContext.context.activity.channelData.sendParamData.bpn_invoiceReference
                payload.invoice_amount = stepContext.context.activity.channelData.sendParamData.bpn_invoiceAmount
                payload.email = stepContext.context.activity.channelData.mail_id
                payload.browser_language = stepContext.context.activity.channelData.Browser_Language


            }
            else {
                payload.po_number =  "7130009723"      
                // "7130007823" //"7130007361"
                // payload.po_number = "4500681183"
                payload.invoice_ref = 'QJQ1463'       //'D53252' //'34960' 
                payload.browser_language = 'en-US',
                payload.comp_code = '9001'
                payload.email = 's.a@duracell.com'

            }     
            console.log("Payload in root :" + JSON.stringify(payload))
           
            let payload1 = await Datastore.getInstance().getPayload(process.env.domainCode)
            payload1.User_conversation_id = stepContext.context.activity.conversation.id,
            payload1.User_name = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
            payload1.User_email = payload.email

            LoggingUtil.log.info("Payload for db:" + JSON.stringify(payload1))
            await Datastore.getInstance().logdatatodb(payload1, payload)
            
            return await stepContext.beginDialog('DC_Greeting', { payload: payload })
        }
        else {
            return await this.handleUndefinedDialog(stepContext);
        }
    }

    /**
     * This is the final step in the main waterfall dialog.
     * It wraps up the sample "book a flight" interaction with a simple confirmation.
     */
    private async finalStep(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {
        // Restart the main dialog waterfall with a different message the second time around
        return await stepContext.replaceDialog(this.initialDialogId,
            { restartMsg: 'What else can I do for you?' });
    }

    /**
     * The run method handles the incoming activity (in the form of a DialogContext) and passes it through the dialog system.
     * If no dialog is active, it will start the default dialog.
     * @param {TurnContext} context
     */
    
    public async run(context, accessor) {
        try {
            //FOR MS TEAMS---------HR BOT
            const dialogSet = new DialogSet(accessor);
            dialogSet.add(this);
            PlatformApplicationContext.getInstance().getRequestData().dialogSet = dialogSet;
            const dialogContext = await dialogSet.createContext(context);
            const results = await dialogContext.continueDialog();
            if (results.status === DialogTurnStatus.empty) {
                await dialogContext.beginDialog(this.id);
            }
        } catch (e) {
            LoggingUtil.log.error(`Failed to continue the dialog`, e);
            //throw e;
        }
    }


    private async handleUndefinedDialog(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {
        // const messageText = 'Sorry, I could not find any matching flow. Try again';
        // const promptMessage = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
        // return await stepContext.prompt('TextPrompt', { prompt: promptMessage });
        return await stepContext.cancelAllDialogs()
    }

    public getNewInstance(bot: any) {
        throw new Error("Method not implemented.");
    }


}