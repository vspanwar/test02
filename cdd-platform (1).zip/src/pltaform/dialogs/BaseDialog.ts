import { PlatformApplicationContext } from '../core/PlatformApplicationContext';
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

//import { InputHints } from 'botbuilder';
//import { ComponentDialog, , DialogTurnResult, DialogTurnStatus } from 'botbuilder-dialogs';
import { InputHints, MessageFactory, StatePropertyAccessor, TurnContext } from 'botbuilder';
import {
    ComponentDialog,
    DialogContext,
    DialogSet,
    DialogState,
    DialogTurnResult,
    DialogTurnStatus,
    TextPrompt,
    WaterfallDialog,
    WaterfallStepContext
} from 'botbuilder-dialogs';
import { ExternalApp, NLP, ExternalAppCategory } from '../../common/enums/PlatformEnums';
import { ItsmFacade } from '../../common/utils/itsm/ItsmFacade';
import { SingleRecognizer } from '../../common/utils/nlp/impl/SingleRecognizer';
import {WeatherService} from "../../../src/esi/service/WeatherService"
/**
 * This base class watches for common phrases like "help" and "cancel" and takes action on them
 * BEFORE they reach the normal bot logic.
 */
export abstract class BaseDialog extends ComponentDialog {
    private _bot:any;
    private _name:any;
    private _itsmService: ItsmFacade;
    private _nlpService:SingleRecognizer;
    private _weatherService:WeatherService;
    

    constructor(id: string) {
        super(id);
        this._name = id;
    }

   
    public getItsmService(){
        return this._itsmService;
    }

    public getWeatherService(){
        return this._weatherService;
    }

    public abstract getNewInstance(bot:any);

    public get name(){
        return this._name;
    }

    public get nlpService(){
        //console.log("pratik" ,this._nlpService)
        return this._nlpService;
    }
    
    public set bot(bot:any){        
        this._bot = bot;
        this._nlpService = new SingleRecognizer(bot);
        //console.log("~~~~~~~~~~~~~~", this._nlpService)
        const itsmConfig = this.getExternalAppConfig(ExternalAppCategory.ITSM);
        if(itsmConfig){
            this._itsmService = new ItsmFacade(itsmConfig);
        }
    }
    public get bot(){
        return this._bot;
    }

    public getExternalAppConfig(extApp:ExternalAppCategory ){
        for (let app of this._bot.extApp) {
            if( app.category === extApp.toString())
               return app;
        }
        return {}
    }
    public getExternalAppConfigByName(name:string ){
        for (let app of this._bot.extApp) {
            if( app.name === name)
               return app;
        }
        return {}
    } 


    public getNlpAppConfig(nlpApp:NLP ){
        for (let app of this._bot.nlpApps) {
            if( app.type === nlpApp.toString())
               return app;
        }
        return {}
    } 


}
