import { TenantService } from './../service/TenantService';
import { PlatformApplicationContext } from './../core/PlatformApplicationContext';
import { BaseDialog } from './BaseDialog';


import { InputHints, MessageFactory, StatePropertyAccessor, TurnContext } from 'botbuilder';


import {
    ComponentDialog,
    DialogContext,
    DialogSet,
    DialogState,
    DialogTurnResult,
    DialogTurnStatus,
    TextPrompt,
    WaterfallDialog,
    WaterfallStepContext
} from 'botbuilder-dialogs';


export abstract class BaseComponentDialog extends BaseDialog {
    private _dialogCfg:any;
    private _userName:any;
    private _firstName:any;
    constructor(id: string) {
        super(id);
        this._dialogCfg = TenantService.getDialogCfg(id);
    }

    public get dialogCfg(){
        return this._dialogCfg;
    }
    public set dialogCfg(dialogCfg){
        this._dialogCfg = dialogCfg;
    }

    public async onContinueDialog(innerDc: DialogContext): Promise<DialogTurnResult> {
        PlatformApplicationContext.getInstance().getRequestData().dialogContext=innerDc;

        const result = await this.interrupt(innerDc);
        if (result) {
            return result;
        }
        return await super.onContinueDialog(innerDc);
    }
    public async onBeginDialog(innerDC: DialogContext,options:any): Promise<DialogTurnResult>{
        if(innerDC.context.activity.channelId=='directline' || innerDC.context.activity.channelId=='webchat'){
            this._userName = innerDC.context.activity.from.id;
            let breakName = this.userName.split(' ')[0]
            this._firstName = breakName[0].toUpperCase()+breakName.substring(1)
        }else if(innerDC.context.activity.channelId=='emulator'){
            this._userName = 'Ashmeet Singh';
            let breakName = this.userName.split(' ')[0]
            this._firstName = breakName[0].toUpperCase()+breakName.substring(1)
        }else{
            this._userName = innerDC.context.activity.from.name;
            let breakName = this.userName.split(' ')[0]
            this._firstName = breakName[0].toUpperCase()+breakName.substring(1)
        }
        return await super.onBeginDialog(innerDC,options);
    }

    public get userName(){
        return this._userName;
    }
    public get firstName(){
        return this._firstName;
    }

    private async interrupt(innerDc: DialogContext): Promise<DialogTurnResult|undefined> {
        if (innerDc.context.activity.text) {
            const text = innerDc.context.activity.text.toLowerCase();
            // let arr=['frustrated','irate','losing my patience','impatient','escalate','escalation','affected','hamper','hampering','productivity','frustrate','furious']
          //  let arr=['Change language']
            
            // // let text='Yes matters'
            // let arrr1=['expedite', 'quick resolution', 'fast resolution', 'faster resolution', 'faster solution', 'expediting process', 'attention required', 'immediate', 'immediately', 'quick', 'fast', 'urgently', 'quickly']
             let lower=innerDc.context.activity.text.toLowerCase();
         
            //  for(var i=0;i<arr.length;i++){
            //    let arr1=arr[i].toLowerCase()
            //    if(lower.includes(arr1)){
            //      console.log("Yes it include")
            //      return await innerDc.replaceDialog('platform.testing');
            //       }}
            //   for(var i=0;i<arrr1.length;i++){
            //     let arrr2=arrr1[i].toLowerCase()
            //     if(lower.includes(arrr2)){
            //       console.log("Yes it include")
            //       await innerDc.context.sendActivity("Surely i will help to connect with our solution expert.")
            //       return await innerDc.replaceDialog('sentiment');
            //     }
            // }

            switch (text) {
                // case 'help':
                // case '?':
                //case 'menu':
                //    // const helpMessageText = 'Show help here';
                //     await innerDc.context.sendActivity(helpMessageText, helpMessageText, InputHints.ExpectingInput);
                //     return { status: DialogTurnStatus.waiting };
               // return await innerDc.beginDialog('')
                //case 'cancel':
                case 'sdfghjobjgfihjkfhtijkfgggfhgibjkfnjfhjygkbfngjkfrgujhgkjsndiswoaknvbnfjhk':
                    const cancelMessageText = 'Cancelled';
                    await innerDc.context.sendActivity(cancelMessageText, cancelMessageText, InputHints.IgnoringInput);
                   return await innerDc.cancelAllDialogs();
            }
        }
    }




}
