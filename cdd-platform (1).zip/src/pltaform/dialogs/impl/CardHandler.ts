const { InputHints, CardFactory} = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog,ListStyle } from 'botbuilder-dialogs';
import { isUndefined } from 'util';
import { CddCardFactory } from './CddCardFactory';
import { PlatFormCarType } from '../impl/platform/PlatformCards';
import { IMessageActivity, ActivityFactory,ActivityTypes,MessageFactory } from 'botbuilder';
import { LoggingUtil } from '../../../common/utils/log4js';
const {} = require('botframework-schema');


export class CardHandler{
    private static instance:CardHandler

    constructor(){}

    public static getInstance():CardHandler{
        if(CardHandler.instance==null){
            CardHandler.instance = new CardHandler();
        }
        return CardHandler.instance;
    }


    static getCardType(stepContext:any){
        let ChannelId = stepContext.context.activity.channelId;
        return ChannelId.toLowerCase();
    }

    public createCardMsgActivity(stepContext:any,cardName:any,esiResult:any,options?:any,msg?:any,cardtype?:any,endOfconversation?:any){
        let cardType= (cardtype)?cardtype:"richcard";
        let endOfConversation = (endOfconversation)?endOfconversation:"true";
        let Msg = (msg)?msg:'';
        let type = "message";
        let channelId = CardHandler.getCardType(stepContext);
        let card:any;

        if(options){
            card = CddCardFactory.getPlatformAdaptiveCard(cardName,stepContext, options[0],options[1],options[2]);
        }else{
            card = CddCardFactory.getPlatformAdaptiveCard(cardName,stepContext, esiResult);
        }
        
        let channelData:any = {}
        channelData.message = Msg;
        channelData.type = type;
        channelData.cardType = cardType;
        channelData.endOfConversation = endOfConversation;
        channelData.dialogName = cardName;
        channelData.dataType = cardName;
        
        let message = MessageFactory.attachment(card)
        //const message:ActivityTypes.Message = 
        console.log(channelData)
        message.channelData = channelData;

        return message;
    }

    public static async textPromptWithChoice(stepContext:any,promptType:any,promptMsg:any,promptOptions?:any,isYesNo?:Boolean)
    {

        let channelType = CardHandler.getCardType(stepContext)
        let optionString:string;

        if(promptOptions){
            optionString =promptOptions[0];

            for(let i=1;i<promptOptions.length;i++){
                optionString = optionString + "|"+promptOptions[i];
            }

            LoggingUtil.log.info("Choice String: "+optionString);
        }
       
        if(channelType=='directline' || channelType =='webchat'){
            let channelData:any = {
                "message": promptMsg,
                "rawData": optionString,
                "dataType": (isYesNo) ? "YES_NO" : "OTHER_CHOICE",
                //"wrap": true
            }
            let message = MessageFactory.text(promptMsg,promptMsg,InputHints.ExpectingInput);
            message.channelData = channelData
            return await stepContext.prompt(promptType, {
                prompt: message,
                choices: ChoiceFactory.toChoices(promptOptions)
            });
        }
        else{
            // let data = {
            //     options : promptOptions,
            //     message : promptMsg,
            //     //"wrap": true
            // }
            // const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext,PlatFormCarType.GET_FEEDBACK_CARD,data)
            // return await stepContext.prompt(promptType, {
            //     prompt: cardmsg,
            // });

            let cardArray = []
            let data = {
                options : promptOptions,
                message : promptMsg
            }

            for(let i = 0 ; i < data.options.length ; i = i + 5)
                {
                    let res = []
                    for(let j = 0 ; j < 5 ; j++)
                    {
                        if(i+j<data.options.length)
                        {
                            if(stepContext.context.activity.channelId == "emulator")
                            {
                                res.push({
                                    "type": "Action.Submit",
                                    "title": data.options[i+j],
                                    "data" : data.options[i+j]
                                    })
                            }
                            else{
                                res.push({
                                    "type": "Action.Submit",
                                    "title": data.options[i+j],
                                    "data" : {"msteams": {
                                                "type": "imBack",
                                                "value": data.options[i+j]
                                            }}
                                    })
                            }
                            
                        }
                        else
                        {
                            break;
                        }
                        
                    }

                    var adaptiveCard = CardFactory.adaptiveCard({
                        "type": "AdaptiveCard",
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "msTeams": {

                            "width": "full"
            
                        },
                        "version": "1.0",
                        "body": [
                            {
                            "type": "TextBlock",
                            "text" : data.message,
                            "wrap" :true
                            }
                        ],
                        "actions" : res
                        });

                        cardArray.push(adaptiveCard);
                }

           // const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext,PlatFormCarType.GET_FEEDBACK_CARD,data)
           return await stepContext.prompt(promptType, {
                prompt:  MessageFactory.carousel(cardArray),
            });
        }
    }

    public static async sendPrompt(stepContext:any,promptType:any,promptMsg:any,promptOptions?:any,isYesNo?:Boolean){
        let channelType = CardHandler.getCardType(stepContext)
        let optionString:string;

        if(promptOptions){
            optionString =promptOptions[0];

            for(let i=1;i<promptOptions.length;i++){
                optionString = optionString + "|"+promptOptions[i];
            }

            LoggingUtil.log.info("Choice String: "+optionString);
        }

        if(channelType=='directline' || channelType =='webchat'){
            let channelData:any = {
                "message": promptMsg,
                "rawData": optionString,
                "dataType": (isYesNo) ? "YES_NO" : "OTHER_CHOICE"
            }
            let message = MessageFactory.text(promptMsg,promptMsg,InputHints.ExpectingInput);
            message.channelData = channelData
            
            if(promptType=="confirmPrompt"){
                message.channelData.dataType = "YES_NO";
                return await stepContext.prompt(promptType, { prompt: message });
            }else{
                return await stepContext.prompt(promptType, {
                    prompt: message,
                    choices: ChoiceFactory.toChoices(promptOptions),
                    
                });
            }

        }else{
            if(promptType=="confirmPrompt"){
                let msg = MessageFactory.text(promptMsg, promptMsg, InputHints.ExpectingInput)
                return await stepContext.prompt(promptType, { prompt: msg });
            }else{
                return await stepContext.prompt(promptType, {
                    prompt: promptMsg,
                    choices: ChoiceFactory.toChoices(promptOptions),
                    style:ListStyle.heroCard
                });
            }

        }
    }
}