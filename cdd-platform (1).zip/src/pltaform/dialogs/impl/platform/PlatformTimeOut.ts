import { PlatFormCarType } from './PlatformCards';
import { WaterfallDialog, ChoicePrompt, Dialog, WaterfallStep, WaterfallStepContext, WaterfallStepInfo, TextPrompt } from 'botbuilder-dialogs';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { ItsmRequestType } from '../../../../common/enums/PlatformEnums';
import { LoggingUtil } from '../../../../common/utils/log4js';
import { TurnContext, UserState } from 'botbuilder';
import { TranslatorService } from '../../../service/TranslatorService';
import { MSSQLConfig } from '../../../../common/repository/MSSQLConfig';
import { Datastore } from '../Datastore';


export class PlatformTimeOut extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new PlatformTimeOut(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'Timeout');
        this.addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))

            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.Step1.bind(this),
                //this.Step2.bind(this),

            ]));
        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async Step1(stepContext) {
        let turnCtx: TurnContext;
        //LoggingUtil.log.info("Timeout========>", stepContext.context.activity.from);
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        LoggingUtil.log.info("Timeout========>", sess_id)
        let msg;
        
        if(stepContext.context.activity.channelId == 'msteams'||stepContext.context.activity.channelId == 'emulator'){
            await Datastore.getInstance().updateStatusHR(stepContext.context.activity, 'Completed-Timeout')
            msg="Your session has ended!\n\n When you come back, you can start a new conversation by typing any greeting message."
            await Datastore.getInstance().logTranscriptHR("Your session has ended! When you come back, you can start a new conversation by typing any greeting message.",sess_id,"BOT")
        }
        else{
            msg ="Your session has ended!\n\nOpen a new browser tab to start another conversation."
            await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-Timeout')
            await Datastore.getInstance().logTranscript("Your session has ended! When you come back, you can start a new conversation by typing any greeting message.",stepContext.context.activity.conversation.id)
            //msg = await TranslatorService.getInstance().translate(tt, stepContext.options.language)
        }

        await stepContext.context.sendActivity(msg);
        await stepContext.cancelAllDialogs();
        return await stepContext.endDialog();
    }
  
}
