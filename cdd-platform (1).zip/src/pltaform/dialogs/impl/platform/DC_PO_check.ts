import { ItsmRequestType } from './../../../../common/enums/PlatformEnums';
import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
import { CddCardFactory } from '../CddCardFactory';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';

import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { MessageUtils } from '../MessageUtils';
import { TranslatorService } from '../../../service/TranslatorService';
import { AdminService } from '../../../service/AdminService';
import { HttpUtil } from '../../../../common/utils/HttpUtil';
import { NextThinkService } from '../../../../esi/service/nextThink/NextThinkService';
import { EmailService } from '../../../../email/service/EmailService';
import { soapService } from '../../../service/soapService';
import { SendMessageActivity } from '../../../core/liveagent/model/SendMessageActivity';
import { po_data } from '../../../model/PO_details';
import { DialogUtils } from '../DialogUtils';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Find_email } from '../Find_email';
import { PlatformApplicationContext } from '../../../core/PlatformApplicationContext';
import { servicenow } from '../../../service/servicenow';
import { Datastore } from '../Datastore';
import { DC_checkuser } from './DC_checkuser';
import { DC_GR_Process } from './DC_GR_Process';
var parseString = require('xml2js').parseString;
var moment = require('moment-timezone')



export class DC_PO_check extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new DC_PO_check(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'PO.check');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new DC_GR_Process(PlatFormCarType.DC_GR_Process))
            .addDialog(new DC_checkuser(PlatFormCarType.check_user))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.startStep.bind(this),
                this.secondStep.bind(this),

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }



    async startStep(stepContext) {


        let payload = stepContext.options.payload
        let po_number = ''
        let date = ''
        let iv_ref_number = ''
        let msg = ''

       
        date = await Datastore.getInstance().getDate()
        payload.date = date
        //console.log("Language code: "+stepContext.options.language)


        po_number = payload.po_number
        iv_ref_number = payload.invoice_ref
        LoggingUtil.log.info("data in po check:" + po_number + " " + iv_ref_number)

        stepContext.options.po_number = po_number

        if (stepContext.options.skip_firstStep) {
            let payload1 = await Datastore.getInstance().getPayload(process.env.domainCode)
            payload1.User_conversation_id = stepContext.context.activity.conversation.id,
            payload1.User_name = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
            payload1.User_email = payload.email

            LoggingUtil.log.info("Payload for db:" + JSON.stringify(payload1))
            Datastore.getInstance().logdatatodb(payload1, payload)
            return await stepContext.next()
        }

        //End the convo, if PO number starts with 55
        else {
            console.log("inside po check else block")
            await Datastore.getInstance().Updatedb('status', 'InProgress', stepContext.context.activity.conversation.id)
            
            if(po_number == null ||po_number == undefined ||iv_ref_number == null||iv_ref_number == undefined||payload.comp_code== null||payload.comp_code==undefined){
                
                let email = await Find_email.getInstance().getEmail(payload.comp_code)
                let msg = "I am sorry, but I can't proceed further with the GR creation since some of the required values are missing. For assistance, please contact (" + email + ")."
                let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                await stepContext.context.sendActivity(tt)
                
                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-FieldMissing')
                return await stepContext.endDialog()

            }
            else{
                if (po_number.startsWith("55")) {
                    await stepContext.context.sendActivities([
                        { type: 'delay', value: 1000 * 1 }
                    ]);
                    let email = await Find_email.getInstance().getEmail(payload.comp_code)
                    let msg = "I am sorry, but this PO requires additional information that I am not yet trained to process. Please create the GR in REFLEX/SAP or contact the Accounts Payable team"
                    if (email != '') {
                        msg += " (" + email + ")."
                    }
                    let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                    await stepContext.context.sendActivity(tt)
                    await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-POwith55')
    
                    let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                    await stepContext.context.sendActivity(tqmsg)
    
                    return await stepContext.endDialog()
                }
                else {
    
                    let payload = stepContext.options.payload
                    // let email = payload.email
                    let email = "piccione.n@duracell.com"
                    //Authorization check for the user
                    try {
                        let url
                        if (stepContext.context.activity.channelId == "emulator") {
                            url = "zws_check_user_auth?spnego=disabled&saml2=disabled&sap-client=400"
    
                        }
                        else {
                            url = process.env.Auth_url
                        }
    
                        // let url = process.env.Auth_url
                        let body = '<?xml version="1.0"?><soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions"><soapenv:Header/><soapenv:Body><urn:ZRFC_CHECK_USER_AUTH><IV_OBJ_KEY>' + po_number + '</IV_OBJ_KEY><IV_TCODE>MIGO</IV_TCODE><IV_USER_EMAIL>' + email + '</IV_USER_EMAIL></urn:ZRFC_CHECK_USER_AUTH></soapenv:Body></soapenv:Envelope>"'
                        let res = await soapService.getInstance().getAuthResponse(body, url)
                        stepContext.options.api_response = res
                        // console.log("Response in po check:"+res)
    
                        var res1 = ''
                        let response = ''
    
                        parseString(res, function (err, result) {
                            response = result
                            //  console.log("Result value:"+JSON.stringify(result))
                            res1 = result['env:Envelope']['env:Body'][0]['n0:ZRFC_CHECK_USER_AUTHResponse'][0]['EV_AUTHORIZED'][0]
    
                        });
                        let auth = JSON.stringify(res1)
                        // console.log("Auth value:"+auth)
    
                        if (auth == '"X"') {
                            stepContext.options.authorizec = true
                            let msg1 = "I will be assisting you to complete the requested goods receipt (GR). After the GR is successfully created, You will receive a Material Document Number confirming the GR creation. If You would like to cancel the action at any point before receiving the confirmation, simply close the browser tab. Let's get started...."
                            let tt = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                            await stepContext.context.sendActivity(tt)
                            let text = tt.replace("'", " ")
    
                            let time1 = await Datastore.getInstance().getTimestamp()
                            let tc1 = "Bot (" + time1 + ") :" + text
                            payload.transcript.push(tc1)
    
    
                            let msg2 = "I will be assisting you to create a GR for PO number " + po_number + " and invoice reference " + iv_ref_number + " with the receipt date as " + date + ". Do you want to continue?"
                            // let msg2 = "Can you please confirm to create a GR for PO number "+po_number+" and invoice reference "+iv_ref_number+ " with the receipt date as "+date
                            msg = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
                            let opt1 = await TranslatorService.getInstance().translate("Yes", stepContext.options.language)
                            let opt2 = await TranslatorService.getInstance().translate("No", stepContext.options.language)
                            let options = [opt1, opt2]
    
                            let time = await Datastore.getInstance().getTimestamp()
                            let tc = "Bot (" + time + ") :" + msg
                            payload.transcript.push(tc)
                            return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, msg, options);
    
    
    
                        }
                        else {
                            let msg = "It looks like you are not authorized to generate GR for the purchase order"
                            let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                            await stepContext.context.sendActivity(tt)
                            let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                            await stepContext.context.sendActivity(tqmsg)
                            await Datastore.getInstance().updateStatus(stepContext.context.activity,'Completed-NotAuthor')
                            return await stepContext.endDialog()
    
                        }
    
                    }
                    catch (e) {
    
                        console.log("##########ERROR####### in auth:" + e)
                        let msg = "Error in server. Please try later"
                        let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                        await stepContext.context.sendActivity(tt)
    
                        let payload1 = await Find_email.getInstance().getPayload("Authorization API Failed", e, payload, stepContext.options.api_response)
                        let ticket = await servicenow.getInstance().CreateTicket(payload1)
                        LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
                        let ticket_number = ticket.result.number
                        // await stepContext.context.sendActivity("Ticket number : "+ticket_number)
    
                        await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-ErrorinSAP')
    
                        return await stepContext.endDialog()
    
                    }
    
                }
                
            }
           
        }

    }
    async secondStep(stepContext) {

        if (stepContext.options.skip_firstStep || stepContext.result.index == 0) {
            if (stepContext.options.skip_firstStep) {
                return await stepContext.beginDialog('GRProcess', { language: stepContext.options.language, edit_info_attempt: 0, payload: stepContext.options.payload})

            }
            else {
                let payload = stepContext.options.payload
                let tc_data =await Datastore.getInstance().gettranscript(stepContext.context.activity,process.env.bcr_name)
                let tc = tc_data + stepContext.result.value
                payload.transcript.push(tc)
                LoggingUtil.log.info("Payload:::::" + payload.transcript)
                //console.log("Lang in po check:"+stepContext.options.language)
                return await stepContext.beginDialog('checkuser', { language: stepContext.options.language, payload: stepContext.options.payload })

                //  return await stepContext.beginDialog('gr.request',{language:stepContext.options.language,bol_attempt:1,edit_info_attempt:0,header_attempt:0,payload:stepContext.options.payload})

            }
        }
        else {
            await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-userDisc')
            let tqmsg = await this.getThankyouMsg(stepContext.options.language)
            await stepContext.context.sendActivity(tqmsg)
            return await stepContext.endDialog()
        }
    }

    public async getThankyouMsg(language: any) {
        let msg1 = "Thank you for using"
        let msg2 = "Virtual Assistant. Please close the browser tab as your session has ended. Have a great day."
        let msg3 = await TranslatorService.getInstance().translate(msg1, language)
        let msg4 = await TranslatorService.getInstance().translate(msg2, language)
        return msg3 + " Duracell " + msg4
    }

    public async sendEmail(payload: any, error: any) {
        console.log("Inside sendmail::" + error)
        var nodemailer = require('nodemailer');
        let po_number = payload.po_number
        let email = payload.email
        let res
        try {
            var moment = require('moment-timezone')
            let m = moment().tz('America/Toronto').format()
            let time = m.substring(0, 10) + " " + m.substring(11, 19)

            let transporter = await nodemailer.createTransport({
                host: "smtp.duracell.com",
                port: 25,
                secure: false, // true for 465, false for other ports

            });
            console.log("Message sent: inside nodemailer");

            await transporter.verify(function (error, success) {
                if (error) {
                    LoggingUtil.log.info("Error in verify")
                    console.log(error);
                } else {
                    res = true
                    console.log("Server is ready to take our messages");
                }
            });
            LoggingUtil.log.info("After transporter verify")

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: 'duracmbf@duracell.com', // sender address
                to: 's.a@duracell.com',
                subject: "Automation Failed", // Subject line
                text: "test mail", // plain text body
                html: "<html> <head></head>" +
                    "<body>" +
                    "<p>" +
                    "Please find the error details below:</br>" +
                    "<b>PO number</b>: " + po_number + " </br>" +
                    "<b>User Email</b>: " + email + " </br>" +
                    "<b>Timestamp</b>: " + time + " </br>" +
                    "<b>Error</b>: " + error + "</br>" +
                    "</p>" +
                    "</body>" +
                    "</html>",
            });
            LoggingUtil.log.info("After sendmail ")

        }
        catch (e) {
            LoggingUtil.log.error("Error in send mail=" + e)
        }

        return res

    }


}

