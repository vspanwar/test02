import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { TranslatorService } from '../../../service/TranslatorService';
import { DialogUtils } from '../DialogUtils';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { MSSQLConfig } from '../../../../common/repository/MSSQLConfig'
import { Datastore } from '../Datastore';
import { DC_GR_Process } from './DC_GR_Process';

var parseString = require('xml2js').parseString;
var moment = require('moment-timezone')



export class DC_checkuser extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new DC_checkuser(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'checkuser');

        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new DC_GR_Process(PlatFormCarType.DC_GR_Process))
            // .addDialog(gr)
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.startStep.bind(this),
               // this.secondStep.bind(this)
                //  this.finalstep.bind(this),


            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async startStep(stepContext) {
        let payload = stepContext.options.payload

        let user_Company_code = payload.comp_code
        let comp_code_for_attachment = (process.env.comp_code_for_attachment).split(',')
        LoggingUtil.log.info("company code in check user", user_Company_code)

        if (comp_code_for_attachment.includes(user_Company_code)) {
         

            //let msg2 = 'I see that you are required to attach proof to the GR and I am not yet trained to attach documents to a GR. Please click here to be redirected to Procur where you will be able to attach the required documents.'

            //let msg = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
            //let opt1 = await TranslatorService.getInstance().translate("Yes", stepContext.options.language)
           // let opt2 = await TranslatorService.getInstance().translate("No", stepContext.options.language)
            //let options = [opt1, opt2]

            // let time = await Datastore.getInstance().getTimestamp()
            // let tc = "Bot (" + time + ") :" + msg
            // payload.transcript.push(tc)
            //return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, msg, options)
           
            //let msg1 = "I am sorry, I can't help you to add an attachment."
            //let payload = stepContext.options.payload
            let url = process.env.sap_url_for_attachment+'GODYNPRO-PO_NUMBER='+payload.po_number
            let url_msg = await MessageFormattingHandler.getInstance().getAnchorString(stepContext.context.activity,url,'click here')
            let msg1 = 'I see that you are required to attach proof to the GR and I am not yet trained to attach documents to a GR. Please '
            let tt = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
            
            let msg2 = 'to be redirected to Procur where you will be able to attach the required documents.'
            let tt1 = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
            let language = stepContext.options.language;
            //let msgg1 = 'I am not yet train to attach documents to a GR. If you are required to add attachments to the GR record itself, please '+url_msg+' to be redirected to Procur.'
           // let msgg = await TranslatorService.getInstance().translate(msg2, language)
            //await stepContext.context.sendActivity(msgg)
            let msg3 = tt+url_msg+tt1
            await stepContext.context.sendActivity(msg3)
            let tq = await Datastore.getInstance().getThankyouMsg(language)
            await stepContext.context.sendActivity(tq)
            await Datastore.getInstance().updateStatus(stepContext.activity, 'Completed-attachReq')
            
            return await stepContext.endDialog()
            

        }
        else {
           // stepContext.options.no_attachment = true
            return await stepContext.replaceDialog('GRProcess', { language: stepContext.options.language, edit_info_attempt: 0, payload: stepContext.options.payload })

        
        }


    }


    // async secondStep(stepContext) {
    //     let language = stepContext.options.language
       

    //         let payload = stepContext.options.payload
    //         // let msg = await TranslatorService.getInstance().translate('No', language)
    //         // let tc_data = await MessageFormattingHandler.getInstance().gettranscript(stepContext.context.activity)
    //         // let tc = tc_data + msg
    //         // LoggingUtil.log.info("TC data:" + tc)
    //         // payload.transcript.push(tc)
    //         return await stepContext.replaceDialog('GRProcess', { language: stepContext.options.language, edit_info_attempt: 0, payload: stepContext.options.payload })

    //         //return await stepContext.beginDialog('gr.request',{language:stepContext.options.language,bol_attempt:1,edit_info_attempt:0,header_attempt:0,payload:stepContext.options.payload})
        
        


    // }

}

