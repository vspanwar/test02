import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Datastore } from '../Datastore';
import { searchService } from '../../../service/searchService';
import { DialogUtils } from '../DialogUtils';




export class Personal_Info extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new Personal_Info(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'Personal.intent');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))


            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                
                
                this.firstStep.bind(this),
                this.secondStep.bind(this),
                this.thirdStep.bind(this)   

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

 
   
    
    async firstStep(stepContext) {
        const messageText = `Please select one of the options below`;
        let options = ['Personal Information','Contact Information','Job Information','On-premises Information'];
        return CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,messageText,options);

    }

    async secondStep(stepContext) {
        let result = await searchService.getInstance().PersonalIntent(await DialogUtils.getInstance().getemail(stepContext.context))
        console.log("Persoal details of User====>>>> ", result.data)
        if(stepContext.result.index == 0)
        {
            
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Personnel_Card.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            return await stepContext.next()
        }
        else if(stepContext.result.index == 1)
        {
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Contact_Crad.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            return await stepContext.next()
        }
        else if(stepContext.result.index == 2)
        {
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Office_Card.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            return await stepContext.next()
        }       
        else if(stepContext.result.index == 3)
        {
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.OnPremise_Crad.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            return await stepContext.next()
        }
    }
    
    async thirdStep(stepContext) {
        return await stepContext.replaceDialog("HR_IsThere")
    }
}

