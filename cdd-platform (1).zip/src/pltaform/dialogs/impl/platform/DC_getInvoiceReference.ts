import { PlatFormCarType } from './PlatformCards';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog, Dialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { TranslatorService } from '../../../service/TranslatorService';
import { Find_email } from '../Find_email';
import { servicenow } from '../../../service/servicenow';
import { Datastore } from '../Datastore';
import { soapService } from '../../../service/soapService';
import { MessageFormattingHandler } from '../MessageFormatingHandler';




export class Dc_getInvoiceReference extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new Dc_getInvoiceReference(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'getInvoiceReference');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.startStep.bind(this),
                this.secondStep.bind(this),
                this.thirdStep.bind(this)

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async startStep(stepContext) {
        let po = stepContext.options.payload
        // LoggingUtil.log.info("Payload in startStep :::"+JSON.stringify(po))
        // LoggingUtil.log.info("Skip step:"+stepContext.options.skip_step)
        // LoggingUtil.log.info("Attempt :"+stepContext.options.attempt)
        if (stepContext.options.skip_step) {
            return await stepContext.next()
        }

        let msg2 = ''
        if (stepContext.options.edit_info) {
            msg2 = 'Current reference is ' + po.invoice_ref + '. Do you want to change it?'
        }
        else {
            msg2 = "Would you like to change the Invoice Reference Number?"
        }


        let msg = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
        let opt1 = await TranslatorService.getInstance().translate("Yes", stepContext.options.language)
        let opt2 = await TranslatorService.getInstance().translate("No", stepContext.options.language)
        let options = [opt1, opt2]

        let time = await Datastore.getInstance().getTimestamp()
        let tc = "Bot (" + time + ") :" + msg
        po.transcript.push(tc)
        return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, msg, options);
    }
    async secondStep(stepContext) {

        let payload = stepContext.options.payload
        // LoggingUtil.log.info("Skip step:"+stepContext.options.skip_step)

        if (stepContext.options.skip_step) {

            let data = stepContext.options.payload
            let msg1 = "Sorry you have exceeded the maximum length. Please re-enter the invoice reference number (max char:16)."
            let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)

            let time = await Datastore.getInstance().getTimestamp()
            let tc = "Bot (" + time + "): " + msg
            payload.transcript.push(tc)
            // LoggingUtil.log.info("Payload in if:"+payload.transcript)
            return await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, msg)
        }
        else {

            let tc_data = await Datastore.getInstance().gettranscript(stepContext.context.activity,process.env.bcr_name)
            let tc1 = tc_data + stepContext.result.value
            payload.transcript.push(tc1)

            if (stepContext.result.index == 0) {
                let data = stepContext.options.payload
                let msg1 = "Please enter the New Invoice Reference Number in the bottom of the page (Current number: " + data.invoice_ref + ")"
                let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)

                let time = await Datastore.getInstance().getTimestamp()
                let tc = "Bot (" + time + "): " + msg
                payload.transcript.push(tc)
                //  LoggingUtil.log.info("Payload in else:"+payload.transcript)
                return await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, msg)
            }
            else {
                stepContext.context.activity.value = payload
                return await stepContext.endDialog()
            }
        }


    }

    async thirdStep(stepContext) {
        let res = stepContext.result
        let payload = stepContext.options.payload
        let attempt = stepContext.options.attempt
        let tc_data = await Datastore.getInstance().gettranscript(stepContext.context.activity,process.env.bcr_name)
        let tc = tc_data + res
        payload.transcript.push(tc)
        //LoggingUtil.log.info("Length in 3rd:"+res.length+ "Result:"+res+ " attempt :"+attempt)
        if (res.length <= 16 && attempt < 3) {
            payload.invoice_ref = res
            stepContext.context.activity.value = payload
            return await stepContext.endDialog()
        }
        else {
            if (attempt >= 3) {
                let msg1 = " I am sorry! I cannot proceed further with the GR creation as you have exceeded the number of allowed tries."
                let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                await stepContext.context.sendActivity(msg)
                let tqmsg = await Datastore.getInstance().getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                //  await Datastore.getInstance().updateendtimestamp(stepContext.context.activity)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-LimExceed')

                return await stepContext.cancelAllDialogs()
            }
            else {

                return await stepContext.beginDialog('getInvoiceReference', { language: stepContext.options.language, payload: payload, attempt: attempt + 1, skip_step: true })
            }
        }

    }

}

