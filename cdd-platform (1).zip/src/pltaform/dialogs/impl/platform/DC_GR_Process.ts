import { PlatFormCarType } from './PlatformCards';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog, Dialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { TranslatorService } from '../../../service/TranslatorService';
import { Find_email } from '../Find_email';
import { servicenow } from '../../../service/servicenow';
import { Datastore } from '../Datastore';
import { soapService } from '../../../service/soapService';
import { DialogUtils } from '../DialogUtils';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Dc_getInvoiceReference } from './DC_getInvoiceReference';
import { strictEqual } from 'assert';
import { DC_getBolNumber } from './DC_getBolNumber';
import { DC_getDescription } from './DC_getDescription';
import { Activity } from 'botbuilder-core';
import { KeyVaultService } from '../../../../common/utils/keyvault/keyVaultService';
import { JsonConfigDao } from '../../../../admin/dao/JsonConfigDao';




export class DC_GR_Process extends BaseComponentDialog {

    public getNewInstance(bot: any) {
        const instance = new DC_GR_Process(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'GRProcess');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new Dc_getInvoiceReference(PlatFormCarType.Get_Invoice_Reference))
            .addDialog(new DC_getBolNumber(PlatFormCarType.getBolNumber))
            .addDialog(new DC_getDescription(PlatFormCarType.getDesctiption))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.startStep.bind(this),
                this.secondStep.bind(this),
                this.thirdStep.bind(this),
                this.fourthStep.bind(this),
                this.fifthStep.bind(this),
                this.sixthStep.bind(this),
                this.seventhStep.bind(this),
                this.eighthStep.bind(this),
                this.ninthStep.bind(this),
                this.tenthStep.bind(this)

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async startStep(stepContext) {
        let payload = stepContext.options.payload
        LoggingUtil.log.info("Came inside gr new")
        if (stepContext.options.skipStep) {       //If the entered quantity is greater than available quantity
            return await stepContext.next()
        }

        else if (stepContext.options.edit_info) {        //If user clicks edit info
            stepContext.options.attempt = 0
            return await stepContext.next()
        }
        else {
            try {
                let payload = stepContext.options.payload
                payload.get_po_details = []
                payload.req_data = []

                stepContext.options.attempt = 0
                let data = stepContext.options.payload
                let po_number = data.po_number
                console.log("po number in bd_cgrequ class : " + po_number)

                let url = ''
                if (stepContext.context.activity.channelId == "emulator") {
                    url = "zws_bapi_po_getdetail?sap-client=400&saml2=disabled&spnego=disabled"

                }
                else {
                    url = process.env.get_line_item
                }

                let body = '<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions"><soapenv:Header/><soapenv:Body><urn:BAPI_PO_GETDETAIL><PURCHASEORDER>' + po_number + '</PURCHASEORDER><ITEMS>X</ITEMS><HISTORY>X</HISTORY><PO_ITEMS/><PO_ITEM_HISTORY/><PO_ITEM_HISTORY_TOTALS/></urn:BAPI_PO_GETDETAIL></soapenv:Body></soapenv:Envelope>'
                let res = await soapService.getInstance().getPODetails(body, url)
                stepContext.options.api_response = res
                res = await soapService.getInstance().xmltojson(res)
                let res2 = ''
                let res1 = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"]
                LoggingUtil.log.info("length of res1:" + res1.length)
                let po_histoty = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEM_HISTORY_TOTALS"].toString()


                stepContext.options.is_PO_History_Empty = false
                if (po_histoty == "") {
                    stepContext.options.is_PO_History_Empty = true
                }
                else {
                    res2 = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEM_HISTORY_TOTALS"][0]["item"]

                }

                stepContext.options.lineitemCount = res1.length

                let Details = payload.get_po_details
                if (res1.length == 0) {
                    // no lineitems
                    let email = await Find_email.getInstance().getEmail(data.comp_code)
                    let text = 'Sorry, I cannot perform the GR. All line items have been received, deleted or locked. For assistance, please contact (' + email + ').'
                    // let text = 'Sorry, there are no lines available for GR creation in this PO. All lines are already fully received, deleted or locked. Please contact the Help Desk ('+email +')  for assistance.'
                    let tt = await TranslatorService.getInstance().translate(text, stepContext.options.language)
                    await stepContext.context.sendActivity(tt)

                    let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                    await stepContext.context.sendActivity(tqmsg)
                    // await Datastore.getInstance().updateendtimestamp(stepContext.context.activity)
                    await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-NolineItem')

                    return await stepContext.endDialog()
                }
                else {
                    let arr2 = []   //for history_total calculation
                    let payload = stepContext.options.payload
                    //store the item info in get_po_details array

                    let vendor_number = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_HEADER"][0]["VENDOR"].toString()
                    payload.vendor_number = vendor_number
                    console.log("Vendor number from response:" + payload.vendor_number)
                    let vendor_name = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_HEADER"][0]["VEND_NAME"].toString()
                    payload.vendor_name = vendor_name
                    console.log("Vendor name from response:" + payload.vendor_name)

                    for (let i = 0; i < res1.length; i++) {
                        let po_item = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["PO_ITEM"].toString()
                        let short_text = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["SHORT_TEXT"].toString()
                        let quantity = parseFloat(res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["QUANTITY"].toString()).toFixed(2)
                        let plant = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["PLANT"].toString()
                        let entry_uom = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["UNIT"].toString()
                        let entry_iso = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["UNIT"].toString()
                        let po_name = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["SHORT_TEXT"].toString()
                        let deleted_item = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEMS"][0]["item"][i]["DELETE_IND"].toString()
                        Details[i] = { po_item: po_item, short_text: short_text, quantity: quantity, plant: plant, Entry_uom: entry_uom, Entry_iso: entry_iso, input_qty: "", avail_qty: 0.00, received_qty: 0.00, po_name: po_name, deleted_item: deleted_item }

                    }

                    let qty0count = 0

                    if (stepContext.options.is_PO_History_Empty) {
                        for (let i = 0; i < res1.length; i++) {
                            Details[i]['avail_qty'] = Details[i]['quantity']

                        }
                    }
                    else {
                        // storing the item history in temporary array
                        for (let i = 0; i < res2.length; i++) {
                            let po_item = res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEM_HISTORY_TOTALS"][0]["item"][i]["PO_ITEM"].toString()
                            let quantity = parseFloat(res["env:Envelope"]["env:Body"][0]["n0:BAPI_PO_GETDETAILResponse"][0]["PO_ITEM_HISTORY_TOTALS"][0]["item"][i]["DELIV_QTY"].toString())
                            arr2[i] = { deliv_quantity: quantity, po_item: po_item }

                        }

                        //calculating available qty and pushing the detials into get_po_details array
                        for (let i = 0; i < res1.length; i++) {
                            let delivered_qty = 0
                            for (let j = 0; j < res2.length; j++) {
                                if (Details[i]['po_item'] == arr2[j]['po_item']) {
                                    delivered_qty += arr2[j]['deliv_quantity']
                                }
                            }

                            Details[i]['received_qty'] = delivered_qty.toFixed(2)
                            Details[i]['avail_qty'] = (Details[i]['quantity'] - delivered_qty).toFixed(2)

                            if (Details[i]['avail_qty'] == 0.00) {
                                qty0count++
                            }
                        }
                    }

                    //Calaulating the line item count for which GR can be created
                    let noGRPossible = 0
                    for (let i = 0; i < res1.length; i++) {
                        if (Details[i]["avail_qty"] != 0.00 && Details[i]["deleted_item"] == "") {
                            noGRPossible++
                        }
                    }

                    let lineitemCount = stepContext.options.lineitemCount
                    stepContext.options.availlable_lineitem = noGRPossible

                    if (noGRPossible == 0) {
                        //no line item after omitting locked/deleted line item

                        let email = await Find_email.getInstance().getEmail(data.comp_code)
                        let text = 'Sorry, I cannot perform the GR. All line items have been received, deleted or locked. For assistance, please contact (' + email + ').'
                        let tt = await TranslatorService.getInstance().translate(text, stepContext.options.language)
                        await stepContext.context.sendActivity(tt)

                        let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                        await stepContext.context.sendActivity(tqmsg)
                        //  await Datastore.getInstance().updateendtimestamp(stepContext.context.activity)
                        await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-NolineItem')

                        return await stepContext.endDialog()
                    }
                    else {
                        //Display the line item
                        let msg = "Please select the PO lines for this GR."
                        let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                        await stepContext.context.sendActivity(tt)

                        let time = await Datastore.getInstance().getTimestamp()
                        let tc = "Bot (" + time + ") :" + msg
                        payload.transcript.push(tc)
                        let data = payload.get_po_details

                        let url_data = stepContext.options.payload
                        url_data.browser_language = stepContext.options.language

                        let options = [data, url_data, ""]; //always send array of three , if not then put blank value
                        const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Podetails.toString(), '', options)
                        await stepContext.context.sendActivity(cardmsg)
                        //  LoggingUtil.log.info("po details card1:"+JSON.stringify(cardmsg))
                        return Dialog.EndOfTurn;
                    }

                }
            }
            catch (e) {
                console.log("##########ERROR####### :" + e)
                let msg = "Error in the server. Please try later"
                let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
                await stepContext.context.sendActivity(tt)

                let payload1 = await Find_email.getInstance().getPayload("Getline item API Failed", e, payload, stepContext.options.api_response)
                let ticket = await servicenow.getInstance().CreateTicket(payload1)
                LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
                //await Datastore.getInstance().updateendtimestamp(stepContext.context.activity)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-ErrorinSAP')

                return await stepContext.endDialog()

            }
        }

    }

    async secondStep(stepContext) {
        let payload = stepContext.options.payload
        if (stepContext.options.skipStep || stepContext.options.edit_info) {
            let msg = "Please re-enter the quantity!"
            let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
            await stepContext.context.sendActivity(tt)
            let time = await Datastore.getInstance().getTimestamp()
            let tc = "Bot (" + time + ") :" + msg
            payload.transcript.push(tc)
        }
        else {

            let data = stepContext.context.activity.value
            let Infor = JSON.parse(JSON.stringify(data))
            let len = stepContext.options.lineitemCount
            //LoggingUtil.log.info("info from adaptive card:" + JSON.stringify(Infor))
            let payload = stepContext.options.payload
            let po_Details = payload.get_po_details
            let details = payload.req_data
            //console.log("Data in req array>>>>>"+details)

            let index = 0
            let selectd_item = ''

            //Pushing user input from 1'st adaptive card to 2'nd adaptive card
            for (let i = 0; i < len; i++) {
                if (po_Details[i]["avail_qty"] != 0.00) {
                    if (Infor["val" + i] == "true") {
                        details[index] = po_Details[i]
                        selectd_item += po_Details[i]['po_item'] + MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity)
                        index++
                    }
                }
            }


            let tc_data = await Datastore.getInstance().gettranscript(stepContext.context.activity, process.env.bcr_name)
            let data1 = tc_data + selectd_item
            payload.transcript.push(data1)

            //console.log("selected details...", payload.req_data)
            let newArr = []
            for (let i = 0; i < payload.req_data.length; i++) {
                //console.log("selected PO items", payload.req_data[i]['po_item'] )
                newArr.push(payload.req_data[i]['po_item'])
            }
            console.log("selected PO items", newArr)
            let count = []
            for (let i = 0; i < newArr.length; i++) {
                count[i] = await Datastore.getInstance().check_LineItem(newArr[i], payload.po_number, payload.invoice_ref)
                console.log("count of line items from db", count[i])
            }
            console.log("total count of line items", count)
            //console.log("po number & invoice ref-->", payload.po_number, payload.invoice_ref)
            let sum = 0;
            for (let i = 0; i < count.length; i++) {
                sum += count[i];
                //console.log("sum of all line items",sum)
            }
            console.log("sum output", sum)

            if (sum > 0) {
                console.log("inside sum greater than zero")
                let email = await Find_email.getInstance().getEmail(payload.comp_code)
                console.log("Email in error message:" + email)

                let msg1 = "I am sorry! I cannot proceed further with the GR creation, please contact the Help Desk (" + email + ")  for assistance."
                let opt = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                await stepContext.context.sendActivity(opt)
                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-GRRestricted')
                return await stepContext.cancelAllDialogs();
            }
            else if (sum == 0 || sum == undefined || sum == null) {
                console.log("inside sum equal zero")
                //return await stepContext.next()
                // Datastore.getInstance().Updatedb('transcript',data1,stepContext.context.activity.conversation.id)        
                let msg1 = "Please enter the quantity for the selected line item(s)."
                let msg2 = "Note: The quantity entered cannot be greater than the available quantity."
                let tt1 = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                let tt3 = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
                let msg = tt1 + MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity) + tt3
                await stepContext.context.sendActivity(msg)
                
                let msg3 = "Please do NOT use thousands separator and use \".\" (dot) for decimal point when entering the quantity."
                let tt4 = await TranslatorService.getInstance().translate(msg3, stepContext.options.language)
                let displaymsg = MessageFormattingHandler.getInstance().getBoldString(stepContext.context.activity,tt4)
                await stepContext.context.sendActivity(displaymsg)

                let time = await Datastore.getInstance().getTimestamp()
                let tc = "Bot (" + time + ") :" + msg + displaymsg
                payload.transcript.push(tc)

            }
        }   
            // get the quantity for selected line item
            let data1 = payload.req_data

            const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Get_Quantity_card, data1)
            await stepContext.context.sendActivity(cardmsg)
            return Dialog.EndOfTurn;

    }
    
    async thirdStep(stepContext) {
        let payload = stepContext.options.payload
        LoggingUtil.log.info("Payload in 3rd step " + JSON.stringify(payload))
        let data = stepContext.context.activity.value
        let Info = JSON.parse(JSON.stringify(data))
        console.log("value in 3rd step--->", Info)

        let len = Object.keys(Info).length

        for (let i = 0; i < len; i++) {
            console.log("value in 3rd step info value --->", Info["qty" + i])
            let userqnty = parseFloat(Info["qty" + i])
            Info["qty" + i]= userqnty.toFixed(3);
        }

        console.log("User input after round off - ", Info);

        // let quantity_data = stepContext.options.req_data
        let quantity_data = payload.req_data
        LoggingUtil.log.info("Quantity data in 3rd step: " + JSON.stringify(quantity_data))
        let item_name = ''
        let provided_quantity = ''

        // Check whether the enterted quantity is less than avail quantity
        for (let i = 0; i < len; i++) {
            let temp = quantity_data[i]["avail_qty"]
            let availqty = parseFloat(temp)

            if (Info["qty" + i] <= availqty) {


                quantity_data[i]["input_qty"] = Info["qty" + i]
                let data = quantity_data[i]['po_item'] + ":" + Info["qty" + i] + MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity)
                provided_quantity += data

                // else{
                // let data = quantity_data[i]['po_item'] + ":" + Info["qty" + i] + MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity)
                // // LoggingUtil.log.info("Quantity value:"+ data)
                // }

            }
            else {

                item_name += MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity) + quantity_data[i]['po_item'].replace(/^0+/, '') + "  " + quantity_data[i]["short_text"] + "."

                let data = quantity_data[i]['po_item'] + ":" + Info["qty" + i] + MessageFormattingHandler.getInstance().getNextline(stepContext.context.activity)
                provided_quantity += data

            }
        }
        console.log("provided quantiy", provided_quantity)
        //storing the user provided quantity for transcript    

        let tc_data = await Datastore.getInstance().gettranscript(stepContext.context.activity, process.env.bcr_name)
        let data1 = tc_data + provided_quantity

        payload.transcript.push(data1)
        await Datastore.getInstance().logTranscript(data, stepContext.context.activity.conversation.id)
        if (item_name == '') {
            return await stepContext.next()
        }
        else {

            let msg1 = "The quantity of the below item(s) is/are greater than the available quantity or quantity is zero:"
            let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
            await stepContext.context.sendActivity(msg + item_name)

            let time = await Datastore.getInstance().getTimestamp()
            let tc = "Bot (" + time + ") :" + msg
            payload.transcript.push(tc)
            let attempt = stepContext.options.attempt + 1
            LoggingUtil.log.info("Attempt in 3rd step:" + attempt)
            //If attempt is less than 3, reprompt the message
            if (attempt < 3) {
                return await stepContext.replaceDialog('GRProcess', { skipStep: true, attempt: attempt, language: stepContext.options.language, payload: stepContext.options.payload, edit_info_attempt: stepContext.options.edit_info_attempt })
            }
            //If attempt is greater than 3, end the convo
            else {

                let msg1 = " I am sorry! I cannot proceed further with the GR creation as you have exceeded the number of allowed tries."
                let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                await stepContext.context.sendActivity(msg)
                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                // await Datastore.getInstance().updateendtimestamp(stepContext.context.activity)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-LimExceed')
                return await stepContext.cancelAllDialogs();
            }

        }
    }

    async fourthStep(stepContext) {
        let data = stepContext.context.activity.text
        LoggingUtil.log.info("Dataaaaaaaaaaaaaaaaaaa:" + data)
        let po = stepContext.options.payload
        let edit_info = false
        if (stepContext.options.edit_info) {
            edit_info = true
        }

        if (po.po_number.startsWith("45")) {
            return await stepContext.beginDialog('getBolNumber', { language: stepContext.options.language, payload: po, attempt: 0, edit_info: edit_info, edit_info_attempt: stepContext.options.edit_info_attempt })

        }
        else {
            return await stepContext.beginDialog('getInvoiceReference', { language: stepContext.options.language, payload: po, attempt: 0, edit_info: edit_info, edit_info_attempt: stepContext.options.edit_info_attempt })
        }
    }

    async fifthStep(stepContext) {

        let payload = stepContext.context.activity.value
        LoggingUtil.log.info("Payload in 5th step:" + JSON.stringify(payload))
        stepContext.options.payload = payload
        let edit_info = false
        if (stepContext.options.edit_info) {
            edit_info = true
        }
        return await stepContext.beginDialog('getDescription', { language: stepContext.options.language, payload: payload, attempt: 0, edit_info: edit_info, edit_info_attempt: stepContext.options.edit_info_attempt })


    }
    async sixthStep(stepContext) {

        let payload = stepContext.context.activity.value
        stepContext.options.payload = payload
        LoggingUtil.log.info("Payload after branch:" + JSON.stringify(stepContext.options.payload))
        // await stepContext.context.sendActivity("TQ")
        return await stepContext.next()
    }

    async seventhStep(stepContext) {

        let input_item = ''
        // let data = stepContext.options.req_data
        let po = stepContext.options.payload
        let data = po.req_data
        for (let i = 0; i < data.length; i++) {



            if (data[i]["input_qty"] > 0) {
                let temp = data[i]['po_item'].replace(/^0+/, '') + "  " + data[i]["short_text"]
                input_item += temp
                input_item += " : " + data[i]["input_qty"] + "\n\n"
            }
        }

        let msg1
        let header_text = ''
        LoggingUtil.log.info("Desc-->" + po.header_text)
        if (po.header_text != '') {
            header_text = ", expense description " + po.header_text
        }

        if (po.po_number.startsWith("45") == false) {
            msg1 = "Please confirm the creation of GR for PO number " + po.po_number + ", invoice reference " + po.invoice_ref + header_text + " and receipt date as " + po.date + " for the following line items (line items with zero quantity were omitted):"
            //msg1 = "Please confirm, would you like to create a GR for PO number "+po.po_number+" and invoice reference "+po.invoice_ref+ " with the receipt date as "+po.date+ " for the following line items:"

        }
        else {
            msg1 = "Please confirm the creation of GR for PO number " + po.po_number + header_text + ", bill of landing number " + po.bol_number + header_text + " and receipt date as " + po.date + " for the following line items (line items with zero quantity were omitted):"
        }

        let msg = await TranslatorService.getInstance().translate(msg1, stepContext.options.language) + "\n\n" + input_item

        let time = await Datastore.getInstance().getTimestamp()
        let tc = "Bot (" + time + ") :" + msg

        po.transcript.push(tc)
        let opt1 = await TranslatorService.getInstance().translate("Confirm", stepContext.options.language)
        let opt2 = await TranslatorService.getInstance().translate("Edit Info", stepContext.options.language)
        stepContext.options.confirm = opt1
        stepContext.options.editinfo = opt2
        //    return await CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,msg,options);

        let payload = {
            msg: msg,
            Confirm: opt1,
            Edit_Info: opt2,
            submit_text: po.Form_submite_text
        }
        const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.AGREEMENT_CARD, payload)
        await stepContext.context.sendActivity(cardmsg)
        return Dialog.EndOfTurn


    }
    async eighthStep(stepContext) {


        let payload = stepContext.options.payload
        let res = stepContext.context.activity.value.agreement
        LoggingUtil.log.info("Result value:" + JSON.stringify(stepContext.context.activity.value))
        let tc_data = await Datastore.getInstance().gettranscript(stepContext.context.activity, process.env.bcr_name)
        let tc


        if (res == 'true') {
            tc = tc_data + stepContext.options.confirm
            payload.transcript.push(tc)
            return await stepContext.next()
        }

        else {
            let info_attempt = stepContext.options.edit_info_attempt
            tc = tc_data + stepContext.options.editinfo
            payload.transcript.push(tc)
            LoggingUtil.log.info("Attempt in 8th step:" + info_attempt)
            if (info_attempt <= 2) {

                return await stepContext.replaceDialog('GRProcess', { edit_info: true, language: stepContext.options.language, edit_info_attempt: info_attempt + 1, payload: stepContext.options.payload })
            }
            else {
                let msg1 = " I am sorry! I cannot proceed further with the GR creation as you have exceeded the number of allowed tries."
                let opt = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)
                await stepContext.context.sendActivity(opt)
                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-LimExceed')
                return await stepContext.cancelAllDialogs();

            }
        }


    }
    async ninthStep(stepContext) {
        let data = stepContext.options.payload
        console.log("payloaddddd", data)
        let req_data = data.req_data

        //sending the url and payload to create the GR
        let url
        if (stepContext.context.activity.channelId == "emulator") {
            url = 'zws_zrfc_post_po_gr?sap-client=400&saml2=disabled&spnego=disabled'

        }
        else {
            url = process.env.post_gr
        }

        var payload = '<soapenv:Envelope xmlns:soapenv="http://www.w3.org/2003/05/soap-envelope" xmlns:urn="urn:sap-com:document:sap:rfc:functions">'

        payload += '<soapenv:Header/><soapenv:Body>' +
            '<urn:ZRFC_POST_PO_GR><GOODSMVT_HEADER>' +
            '<PSTNG_DATE>' + data.date + '</PSTNG_DATE>' +
            '<REF_DOC_NO>' + data.invoice_ref + '</REF_DOC_NO>' +
            '<HEADER_TXT>' + data.header_text + '</HEADER_TXT>' +
            '</GOODSMVT_HEADER><GOODSMVT_ITEM>'

        for (let i = 0; i < req_data.length; i++) {
            payload += ' <item><PLANT>' + req_data[i]['plant'] + '</PLANT>' +
                '<MOVE_TYPE>101</MOVE_TYPE>' +
                '<VENDOR>' + data.vendor_number + '</VENDOR>' +
                '<ENTRY_QNT>' + req_data[i]['input_qty'] + '</ENTRY_QNT>' +
                '<ENTRY_UOM>' + req_data[i]['Entry_uom'] + '</ENTRY_UOM>' +
                '<ENTRY_UOM_ISO>' + req_data[i]['Entry_iso'] + '</ENTRY_UOM_ISO>' +
                '<PO_NUMBER>' + data.po_number + '</PO_NUMBER>' +
                '<PO_ITEM>' + req_data[i]['po_item'] + '</PO_ITEM>' +
                '<MVT_IND>B</MVT_IND></item>'
        }
        payload += '</GOODSMVT_ITEM><RETURN/></urn:ZRFC_POST_PO_GR></soapenv:Body></soapenv:Envelope>'

        LoggingUtil.log.info("Date=======: " + data.date)

        try {
            let res = await soapService.getInstance().getPODetails(payload, url)
            stepContext.options.api_response = res
            LoggingUtil.log.info("Value from soapservice  :::" + res)
            res = await soapService.getInstance().xmltojson(res)
            console.log("Result from pst gr-->" + JSON.stringify(res))
            let gr_id = res["env:Envelope"]["env:Body"][0]["n0:ZRFC_POST_PO_GRResponse"][0]['GOODSMVT_HEADRET'][0]['MAT_DOC'].toString()

            //Printing the error message
            if (gr_id == '') {
                let error = res["env:Envelope"]["env:Body"][0]["n0:ZRFC_POST_PO_GRResponse"][0]['RETURN'][0]['item'][0]['MESSAGE'][0]
                let email = await Find_email.getInstance().getEmail(data.comp_code)
                console.log("Email in error message:" + email)

                let msg1 = "Sorry, We were not able to generate the GR due to "
                let msg2 = "Please validate your PO is not locked and has enough available funds to process the GR before trying again. If you are unable to complete the GR after researching your PO please contact the A/P Help Desk (apnahelpdesk.im@Duracell.com) for assistance."
                msg1 = await TranslatorService.getInstance().translate(msg1, stepContext.options.language)


                if (email != '') {
                    msg2 = " Please validate your PO is not locked and has enough available funds to process the GR before trying again. If you are unable to complete the GR after researching your PO please contact the Help Desk (" + email + ")  for assistance."

                }
                msg2 = await TranslatorService.getInstance().translate(msg2, stepContext.options.language)
                let msg = msg1 + error + msg2
                await stepContext.context.sendActivity(msg)

                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(tqmsg)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-ErrorinGR')
                return await stepContext.endDialog()



            }
            //display doc id and store the values to db
            else {

                let text = "A GR has been created with the material movement document ID "
                let msg = await TranslatorService.getInstance().translate(text, stepContext.options.language) + " " + MessageFormattingHandler.getInstance().getBoldString(stepContext.context.activity, gr_id)
                let docId = gr_id
                await stepContext.context.sendActivity(msg)

                let time = await Datastore.getInstance().getTimestamp()
                let payload = stepContext.options.payload
                payload.docid_result = gr_id

                payload.transcript.push("Bot" + " (" + time + ") : " + msg)
                await Datastore.getInstance().Updatedb('gr_number', docId, stepContext.context.activity.conversation.id)

                // console.log("TC text:"+ payload.transcript)
                let userInput = payload.req_data
                let dbname = process.env.DatabaseName
                let tablename = process.env.TableName
                for (let i = 0; i < userInput.length; i++) {
                    this.logdatatodb(stepContext.context.activity, i, userInput, payload, dbname, tablename)
                }

            }
            await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-GRCreated')
            let line = stepContext.options.availlable_lineitem

            if (line == 1) {
                let text = "The goods receipt creation has been successful. There are no further actions required."
                let msg = await TranslatorService.getInstance().translate(text, stepContext.options.language)
                let tqmsg = await this.getThankyouMsg(stepContext.options.language)
                await stepContext.context.sendActivity(msg + " " + tqmsg)
                await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-GRCreated')
                return await stepContext.endDialog()
            }
            else {

                let text = "Would you like to process the GR for the remaining line items?"
                let msg = await TranslatorService.getInstance().translate(text, stepContext.options.language)

                //let msg = MessageUtils.getInstance().getMessage("continue_with_remaining_lineitem",stepContext.options.language) 
                let opt1 = await TranslatorService.getInstance().translate("Yes", stepContext.options.language)
                let opt2 = await TranslatorService.getInstance().translate("No", stepContext.options.language)
                let options = [opt1, opt2]
                return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, msg, options);
            }
        }

        catch (e) {
            console.log("##########ERROR####### in post gr:" + e.toString())
            let msg = "Error in the server. Please try later"
            let tt = await TranslatorService.getInstance().translate(msg, stepContext.options.language)
            await stepContext.context.sendActivity(tt)
            console.log("payload for error", data)

            let payload1 = await Find_email.getInstance().getPayload("GR creation API Failed", e, data, stepContext.options.api_response)
            LoggingUtil.log.info("ticket payload:" + JSON.stringify(payload1))

            let ticket = await servicenow.getInstance().CreateTicket(payload1)
            LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
            await Datastore.getInstance().updateStatus(stepContext.context.activity, 'Completed-ErrorinSAP')
            return await stepContext.endDialog()

        }

    }
    async tenthStep(stepContext) {
        let payload = stepContext.options.payload
        LoggingUtil.log.info("Transcript data in 10th step:" + payload.transcript)

        if (stepContext.result.index == 0) {
            payload.transcript = []
            payload.req_data = []
            payload.get_po_details = []
            payload.header_text = ''

            return await stepContext.beginDialog('PO.check', { language: stepContext.options.language, skip_firstStep: true, payload: stepContext.options.payload })
        }
        else {
            let text = "The goods receipt creation has been successful. There are no further actions required."
            let msg = await TranslatorService.getInstance().translate(text, stepContext.options.language)
            let tqmsg = await this.getThankyouMsg(stepContext.options.language)
            await stepContext.context.sendActivity(msg + " " + tqmsg)

            return await stepContext.endDialog()

        }
    }



    public async logdatatodb(activity: Partial<Activity>, index: number, req_data: any, payload: any, dbname: any, tablename: any) {

        console.log("Hello from function" + index)
        let domainCode = process.env.domainCode
        console.log("Req_data:   " + req_data + "payload::::::::" + JSON.stringify(payload))
        var Connection = require('tedious').Connection;
        LoggingUtil.log.info("Domain code:" + domainCode)

        var Request = require('tedious').Request;
        var config = {
            server: 'aznc-rpasqld001.corp.duracell.com',
            //process.env.sql_server,
            authentication: {
                type: 'default',
                options: {
                    // userName: await KeyVaultService.getInstance().getKey('SQLusername'),
                    // password: await KeyVaultService.getInstance().getKey('SqlToken')
                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {

                encrypt: true,
                database: dbname
                //'ipsoftaudit' 
            }
        };
        var connection = new Connection(config);
        connection.on('connect', function (err) {
            // If no error, then good to proceed.
            console.log("Connected" + index);
            console.log("Welcome to db connection" + index);
            executeStatement(index, dbname, tablename, domainCode)

        });


        connection.connect();

        var Request = require('tedious').Request
        var TYPES = require('tedious').TYPES;
        let POdata = payload
        let userInput = req_data
        let data = POdata.transcript
        let transcript = ''


        for (let i = 0; i < data.length; i++) {
            transcript += data[i] + "\n\n"

        }

        console.log("length of tc array:" + data.length + "Transcript in log:" + transcript)

        function executeStatement(i: number, database: any, tablename: any, domaincode: string) {
            var moment = require('moment-timezone')
            let m = moment().tz('America/Toronto').format()
            let time = m.substring(0, 10) + " " + m.substring(11, 19)

            console.log("Time in logdb:" + time)
            let id = activity.conversation.id
            let channel_name = "Web Channel"
            let process = 'grReceipt'


            let user_id = activity.from.id
            let time_Stamp = time
            let attribute1 = 'domainCode=' + domaincode
            let attribute2 = 'bpn_documentID=' + POdata.document_id
            let attribute3 = 'bpn_companyCode=' + POdata.comp_code
            let attribute4 = 'bpn_businessRule=' + POdata.business_rule
            let attribute5 = 'bpn_invoiceReference=' + POdata.invoice_ref
            let attribute6 = 'bpn_vendorNumber=' + POdata.vendor_number
            let attribute7 = 'bpn_invoiceAmount=' + POdata.invoice_amount
            let attribute8 = 'bpn_currency=' + POdata.po_currency
            let attribute9 = 'bpn_vendorName=' + POdata.vendor_name
            let attribute10 = 'bpn_purchaseOrder=' + POdata.po_number
            let attribute11 = 'po_line=' + userInput[i]['po_item']
            let attribute12 = 'po_line_item=' + userInput[i]['po_name']
            let attribute13 = 'quantity=' + userInput[i]['input_qty']
            let attribute14 = 'bpn_bolnumber=' + POdata.bol_number
            let attribute15 = 'gr_documentID=' + POdata.docid_result
            let attribute16 = transcript
            let attribute17 = 'header_text=' + POdata.header_text
            let attribute18 = 'Agreement_certified=Yes'

            LoggingUtil.log.info("Transcript:" + attribute16)
            console.log("po_line=" + attribute11 + " po_name=" + attribute12 + " input quantity=" + attribute13)
            console.log("Channel name:" + channel_name + "user_id: " + user_id)


            LoggingUtil.log.info("Query===" + 'INSERT INTO [' + database + '].[dbo].[' + tablename + '] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16,attribute17,attribute18) VALUES ("' + id + '","' + channel_name + '","' + process + '","' + user_id + '","' + time_Stamp + '","' + attribute1 + '","' + attribute2 + '","' + attribute3 + '","' + attribute4 + '","' + attribute5 + '","' + attribute6 + '","' + attribute7 + '","' + attribute8 + '","' + attribute9 + '","' + attribute10 + '","' + attribute11 + '","' + attribute12 + '","' + attribute13 + '","' + attribute14 + '","' + attribute15 + '","' + attribute16 + '","' + attribute17 + '","' + attribute18 + '");')
            var request = new Request("INSERT INTO [" + database + "].[dbo].[" + tablename + "] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16,attribute17,attribute18) VALUES ('" + id + "','" + channel_name + "','" + process + "','" + user_id + "','" + time_Stamp + "','" + attribute1 + "','" + attribute2 + "','" + attribute3 + "','" + attribute4 + "','" + attribute5 + "','" + attribute6 + "','" + attribute7 + "','" + attribute8 + "','" + attribute9 + "','" + attribute10 + "','" + attribute11 + "','" + attribute12 + "','" + attribute13 + "','" + attribute14 + "','" + attribute15 + "','" + attribute16 + "','" + attribute17 + "','" + attribute18 + "');",
                //var request = new Request('INSERT INTO [IPSOFTAudit].[dbo].[1DeskAudit] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16) VALUES ("'+id+'","'+channel_name+'","'+process+'","'+user_id+'","'+time_Stamp+'","'+attribute1+'","'+attribute2+'","'+attribute3+'","'+attribute4+'","'+attribute5+'","'+attribute6+'","'+attribute7+'","'+attribute8+'","'+attribute9+'","'+attribute10+'","'+attribute11+'","'+attribute12+'","'+attribute13+'","'+attribute14+'","'+attribute15+'","'+attribute16+'");',


                function (err) {
                    if (err) {
                        console.log(err);
                    }
                }
            );

            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            connection.execSql(request);
        }

    }



    public async getThankyouMsg(language: any) {
        let msg1 = "Thank you for using"
        let msg2 = "Virtual Assistant. Please close the browser tab as your session has ended. Have a great day."
        let msg3 = await TranslatorService.getInstance().translate(msg1, language)
        let msg4 = await TranslatorService.getInstance().translate(msg2, language)
        return msg3 + " Duracell " + msg4
    }




}

