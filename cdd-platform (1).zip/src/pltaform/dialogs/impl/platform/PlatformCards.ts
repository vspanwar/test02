import { MessageFactory } from 'botbuilder';
import { Attachment } from 'botframework-schema';
import { body } from 'express-validator/check';
import { JsonConfigDao } from '../../../../admin/dao/JsonConfigDao';
import { LoggingUtil } from '../../../../common/utils/log4js';
import { po_data } from '../../../model/PO_details';
import { AdminService } from '../../../service/AdminService';
import { TranslatorService } from '../../../service/TranslatorService';
import { DialogUtils } from '../DialogUtils';
import { MessageUtils } from '../MessageUtils';


export enum PlatFormCarType {
    CHANNEL_VIDEO_CARD = "CHANNEL_VIDEO_CARD",
    DATE_TIME_CARD_COGNIX = "DATE_TIME_CARD_COGNIX",
    LAST_FIVE_TICKET_STATUS_CARD = "LAST_FIVE_TICKET_STATUS_CARD",
    SINGLE_TICKET_STATUS_CARD = "SINGLE_TICKET_STATUS_CARD",
    FIRST_FIVE_TICKET_STATUS_CARD = "CARD_ITSM_SR_STATUS",
    CARD_LIVE_AGENT_PROMPT = "CARD_INFO_RA",
    // KB_CARD = "CARD_INFO_RA",
    KB_CARD = "CARD_INFO_RA",
    CREATE_INCIDENT_CARD = "CARD_ITSM_INC_NEW",
    CREATE_INCIDENT_CARD1 = "CARD_ITSM_INC_NEW1",
    CREATE_INCIDENT_CARD_2 = "CARD_ITSM_INC_NEW_2",
    CREATE_INCIDENT_CARD_LIVE_AGENT = "CARD_INFO_RA",
    WEATHER_CARD = "WEATHER_CARD",
    NEWS_CARD = "NEWS_CARD",
    //OUTAGES_CARD="CARD_ITSM_OUTAGE",
    OUTAGES_CARD = "DEMO_OUTAGE_CARD",
    GREETING_CARD = "GREETING_CARD",
    FORM_CARD = "FEEDBACK_FORM_CARD",
    RIGHT_ANSWER_RESPONSE = "CARD_INFO_RA",
    CONFIRM_PROMPT = 'confirmPrompt',
    CHOICE_PROMPT = 'CHOICE_PROMPT',
    NUMBER_PROMPT = 'NUMBER_PROMPT',
    TEXT_PROMPT = 'textPrompt',
    DATE_TIME_PROMPT = 'DATE_TIME_PROMPT',
    WATERFALL_DIALOG = 'waterfallDialog',
    PLATFORM_CREATE_TICKET_DIALOG = 'PlatformCreateTicketDialog',
    FEEDBACK_DIALOG = 'feedbackDialog',
    HELP_DIALOG = 'HelpDialog',
    OPEN_STATUS_DIALOG = 'platform.open',
    LIVE_AGENT = 'platformLiveAgent',
    TICKET_STATUS_CARD = "TICKET_STATUS_CARD",
    SINGLE_INCIDENT_CARD = "CARD_ITSM_INC_STATUS",
    OPEN_STATUS_CARD_FUTURE = "OPEN_STATUS_CARD_FUTURE",
    OPEN_STATUS_CARD_PAST = "OPEN_STATUS_CARD_PAST",
    CLOSE_STATUS_CARD = "CLOSE_STATUS_CARD",
    RESOLVED_CANCELLED_STATUS_CARD = " RESOLVED_CANCELLED_STATUS_CARD",
    LAST_FIVE_INCIDENT_STATUS_CARD = "LAST_FIVE_INCIDENT_STATUS_CARD",
    NEXT_LEVEL_DIALOG = 'nextLevelDialog',
    GET_FEEDBACK_CARD = 'GET_FEEDBACK_CARD',
    GET_VIDEO_CARD = 'GET_VIDEO_CARD',
    GET_CATALOG_CARD = 'GET_CATALOG_CARD',
    GET_USER_ON_BOARDING = 'GET_USER_ON_BOARDING',
    UPDATE_USER_ON_BOARDING = "UPDATE_USER_ON_BOARDING",
    DATE_TIME_CARD = "DATE_TIME_CARD",
    CONFIRM_MEETING_CARD = "CONFIRM_MEETING_CARD",
    BOOKING_SUCCESSFUL_CARD = "BOOKING_SUCCESSFUL_CARD",
    ItInfo = "ItInfo",
    It_MultipleInfo = "It_MultipleInfo",
    It_StorageInfo = "It_StorageInfo",

    po_cehck = "PO.check",
    GR_REQ = "gr.request",
    Podetails = "Podetails",
    check_user = 'checkuser',
    Get_Quantity_card = "getQtyCard",
    Greeting = "DC_Greeting",
    HrGreeting = "HR_Greeting",
    create_gr = 'create_gr',
    DC_GR_Process = "GRProcess",
    HR_IsThere = "HR_IsThere",
    Get_Invoice_Reference = "getInvoiceReference",
    getBolNumber = "getBolNumber",
    getDesctiption = "getDescription",
    AGREEMENT_CARD = 'AGREEMENT_CARD',
    HR_CARD = "HR_CARD",
    PDF_CONTENT_CARD = "pdfcontentcard",
    testCard ="testCard",
    Personnel_Card = "Personnel_Card",
    Office_Card = "Office_Card",
    Contact_Crad = "Contact_Crad",
    OnPremise_Crad = "OnPremise_Crad",
    pdfCard2 = 'pdfcard2',
    Manager_Card = 'managerCard',
    Hr_greeting1 = 'HrGreeting'

};

export class PlatformCards {

    static getCard(cardName: string,
        stepContext: any,
        options?: any,
        options1?: any,
        options2?: any,
        data?:string  ) {
        const card = (PlatFormCarType.GET_VIDEO_CARD === cardName)
            ? PlatformCards.getVideoCard(stepContext, options)
            : (PlatFormCarType.UPDATE_USER_ON_BOARDING === cardName)
                ? PlatformCards.updateUserOnBoarding(stepContext, options)
                : (PlatFormCarType.GET_USER_ON_BOARDING === cardName)
                    ? PlatformCards.getUserOnBoarding(stepContext, options)
                    : (PlatFormCarType.GET_FEEDBACK_CARD === cardName)
                        ? PlatformCards.getFeedback_card(stepContext, options)
                        : (PlatFormCarType.SINGLE_TICKET_STATUS_CARD === cardName)
                            ? PlatformCards.getSINGLE_TICKET_STATUS_CARD(stepContext, options)
                            : (PlatFormCarType.FIRST_FIVE_TICKET_STATUS_CARD === cardName)
                                ? PlatformCards.getFIRST_FIVE_TICKET_STATUS_CARD(stepContext, options)
                                : (PlatFormCarType.KB_CARD === cardName)
                                    ? PlatformCards.getKB_CARD(options)
                                    : (PlatFormCarType.CARD_LIVE_AGENT_PROMPT === cardName)
                                        ? PlatformCards.getLiveAgentPrompt_CARD(options)
                                        : (PlatFormCarType.CREATE_INCIDENT_CARD === cardName)
                                            ? PlatformCards.getCREATE_INCIDENT_CARD(stepContext, options)
                                            : (PlatFormCarType.CREATE_INCIDENT_CARD_2 === cardName)
                                                ? PlatformCards.getCREATE_INCIDENT_CARD_2(stepContext, options)
                                                : (PlatFormCarType.CREATE_INCIDENT_CARD1 === cardName)
                                                    ? PlatformCards.getCREATE_INCIDENT_CARD1(stepContext, options)
                                                    : (PlatFormCarType.CREATE_INCIDENT_CARD_LIVE_AGENT === cardName)
                                                        ? PlatformCards.getCREATE_INCIDENT_CARD_LIVE_AGENT(stepContext, options)
                                                        : (PlatFormCarType.WEATHER_CARD === cardName)
                                                            ? PlatformCards.getWEATHER_CARD(stepContext, options)
                                                            : (PlatFormCarType.NEWS_CARD === cardName)
                                                                ? PlatformCards.getNEWS_CARD(stepContext, options, options1, options2)
                                                                : (PlatFormCarType.OUTAGES_CARD === cardName)
                                                                    ? PlatformCards.OUTAGES_CARD(stepContext, options)
                                                                    : (PlatFormCarType.GREETING_CARD === cardName)
                                                                        ? PlatformCards.GREETING_CARD(stepContext)
                                                                        : (PlatFormCarType.TICKET_STATUS_CARD === cardName)
                                                                            ? PlatformCards.getTICKET_STATUS_CARD(stepContext, options)
                                                                            : (PlatFormCarType.FORM_CARD === cardName)
                                                                                ? PlatformCards.getFORM_CARD(options)
                                                                                : (PlatFormCarType.SINGLE_INCIDENT_CARD === cardName)
                                                                                    ? PlatformCards.getSINGLE_INCIDENT_CARD(stepContext, options)
                                                                                    : (PlatFormCarType.OPEN_STATUS_CARD_FUTURE === cardName)
                                                                                        ? PlatformCards.getOPEN_STATUS_CARD_FUTURE(stepContext, options)
                                                                                        : (PlatFormCarType.OPEN_STATUS_CARD_PAST === cardName)
                                                                                            ? PlatformCards.getOPEN_STATUS_CARD_PAST(stepContext, options)
                                                                                            : (PlatFormCarType.CLOSE_STATUS_CARD === cardName)
                                                                                                ? PlatformCards.getCLOSE_STATUS_CARD(stepContext, options)
                                                                                                : (PlatFormCarType.RESOLVED_CANCELLED_STATUS_CARD === cardName)
                                                                                                    ? PlatformCards.getRESOLVED_CANCELLED_STATUS_CARD(stepContext, options)
                                                                                                    : (PlatFormCarType.LAST_FIVE_INCIDENT_STATUS_CARD === cardName)
                                                                                                        ? PlatformCards.getFIRST_FIVE_TICKET_INCIDENT_CARD(stepContext, options)
                                                                                                        : (PlatFormCarType.CHANNEL_VIDEO_CARD === cardName)
                                                                                                            ? PlatformCards.getCHANNEL_VIDEO_CARD(stepContext, options)
                                                                                                            : (PlatFormCarType.DATE_TIME_CARD === cardName)
                                                                                                                ? PlatformCards.getDATE_TIME_CARD(stepContext, options)
                                                                                                                : (PlatFormCarType.DATE_TIME_CARD_COGNIX === cardName)
                                                                                                                    ? PlatformCards.getDATE_TIME_CARD_COGNIX(stepContext, options)
                                                                                                                    : (PlatFormCarType.CONFIRM_MEETING_CARD === cardName)
                                                                                                                        ? PlatformCards.getMeetingConfirmation(stepContext, options)
                                                                                                                        : (PlatFormCarType.BOOKING_SUCCESSFUL_CARD === cardName)
                                                                                                                            ? PlatformCards.getBookingSuccessful(stepContext, options)
                                                                                                                            : (PlatFormCarType.Podetails === cardName)
                                                                                                                                ? PlatformCards.getPodetails(stepContext, options, options1, options2)

                                                                                                                                : (PlatFormCarType.PDF_CONTENT_CARD === cardName)
                                                                                                                                        ? PlatformCards.getpdfcontentCard(stepContext,options)
                                                                                                                                        : (PlatFormCarType.pdfCard2 === cardName)
                                                                                                                                        ? PlatformCards.getpdfCard(stepContext,options)

                                                                                                                                : (PlatFormCarType.testCard === cardName)
                                                                                                                                        ? PlatformCards.testCard(stepContext,options)
                                                                                                                                
                                                                                                                                : (PlatFormCarType.Personnel_Card === cardName)
                                                                                                                                ? PlatformCards.getpersonnel_card(stepContext, options)
                                                                                                                                : (PlatFormCarType.Office_Card === cardName)
                                                                                                                                ? PlatformCards.getOffice_card(stepContext, options)
                                                                                                                                : (PlatFormCarType.Contact_Crad === cardName)
                                                                                                                                ? PlatformCards.getcontact_Info_Card(stepContext, options)
                                                                                                                                : (PlatFormCarType.OnPremise_Crad === cardName)
                                                                                                                                ? PlatformCards.getOnPremise_Card(stepContext, options)
                                                                                                                                : (PlatFormCarType.Manager_Card === cardName)
                                                                                                                                ? PlatformCards.getManagerCard(stepContext, options)

                                                                                                                                : (PlatFormCarType.HR_CARD === cardName)
                                                                                                                                ? PlatformCards.getHRCREATE_INCIDENT_CARD(stepContext,options)
                                                                                                                                : (PlatFormCarType.ItInfo === cardName)
                                                                                                                                    ? PlatformCards.getItInfo(stepContext,options)
                                                                                                                                : (PlatFormCarType.It_MultipleInfo === cardName)
                                                                                                                                    ? PlatformCards.getMultipleInfo(stepContext,options)
                                                                                                                                : (PlatFormCarType.It_StorageInfo === cardName)
                                                                                                                                    ? PlatformCards.getITStorageInfo(stepContext,options)
                                                                                                                                : (PlatFormCarType.AGREEMENT_CARD === cardName)
                                                                                                                                    ? PlatformCards.getAggrementCard(stepContext,options)
                                                                                                                                    : (PlatFormCarType.Get_Quantity_card === cardName)
                                                                                                                                        ? PlatformCards.getQuantitydetails(options)
                                                                                                                                        : {}
        return card
    }

    private static getAggrementCard(stepContext, req_data) {
        let submit_text = req_data.submit_text
        if(stepContext.context.activity.channelId == 'emulator'){
            submit_text =submit_text+'1'   //Throwing error if passing same id for 2 fields. So added dummy id for emulator
        }
        LoggingUtil.log.info("submit text::",submit_text)
        LoggingUtil.log.info("lannnnguage:",stepContext.options.language)
        //LoggingUtil.log.info("lannnnguage:",stepContext.options.languageCode)

        const msg = MessageUtils.getInstance().getMessage("bol_number", 'es')
        LoggingUtil.log.info("translator service::",msg)
        let payload = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type": "TextBlock",
                    "text": req_data.msg,
                    "wrap": true
                },
                //const msg = MessageUtils.getInstance().getMessage("Troubleshoot_msg", 'en')
                {
                    "type": "Input.Toggle",
                    "title": MessageUtils.getInstance().getMessage("I_Certified", stepContext.options.language),
                    "id": "agreement",
                    "isRequired": true,
                    "spacing": "Large",
                    "errorMessage": "Please certify the following to continue!"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": MessageUtils.getInstance().getMessage("true_accurate", stepContext.options.language)
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": MessageUtils.getInstance().getMessage("delivery", stepContext.options.language)
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": MessageUtils.getInstance().getMessage("proforma", stepContext.options.language)
                },
                {
                    "type": "TextBlock",
                    "text": MessageUtils.getInstance().getMessage("addition_details", stepContext.options.language),
                    "wrap": true
                }
            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": req_data.Confirm,
                    "id": req_data.submit_text,
                    "associatedInputs": "agreement"
                },
                {
                    "type": "Action.Submit",
                    "title": req_data.Edit_Info,
                    "id": submit_text,
                    "associatedInputs": "none"
                }
            ]
        }

        LoggingUtil.log.info("card payload:::::",JSON.stringify(payload))
        return payload
    }

    private static getQuantitydetails(req_data) {
        //let data = po_data.req_data
        let data = req_data
        console.log("data of req_data:" + data)
        // console.log("data:"+ JSON.stringify(data))

        let payload = {
            "type": "AdaptiveCard",
            "body": [
                {

                    "type": "Container",
                    "spacing": "Large",
                    "style": "emphasis",
                    // "attempt":po_data.details.qty_attempt,
                    "attempt1": "",

                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "weight": "Bolder",
                                            "wrap": true,
                                            "text": "Line",

                                        }
                                    ],
                                    "width": "60px"
                                },
                                {
                                    "type": "Column",
                                    "spacing": "Large",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "weight": "Bolder",
                                            "wrap": true,
                                            "text": "Description",
                                            "height": "stretch"
                                        }
                                    ],
                                    "width": "150px"
                                },
                                {
                                    "type": "Column",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "weight": "Bolder",
                                            "wrap": true,
                                            "text": "Available Qty"
                                        }
                                    ],
                                    "width": "150px"
                                }
                            ]
                        }
                    ],
                    "bleed": true
                },
                {
                    "type": "Container",
                    "items": this.getQuantity(data)

                }
            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Submit",
                    "style": "positive",
                    "id": data.Form_submite_text,
                    //data.browser_language,
                    //"language": po_data.details.browser_language,
                    "horizontalAlignment": "Center"

                }
            ],
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",

        }
        return payload
    }

    private static getPodetails(stepContext, data: any, url_details: any, dummy: any) {

        // console.log("Inside getpodetails:"+JSON.stringify(data))


        //let payload = po_data.details
        let payload = url_details
        let vendor_number = payload.vendor_number
        console.log("get po details url data:" + JSON.stringify(url_details))

        let po_details = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "type": "AdaptiveCard",

            "body": [
                {
                    "type": "Container",
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "size": "ExtraLarge",
                                            "wrap": true,
                                            "text": "PO Details",
                                            "horizontalAlignment": "Center",
                                        }
                                    ],
                                    "width": "stretch"
                                }
                            ]
                        },
                        {
                            "type": "FactSet",
                            "spacing": "Medium",
                            "facts": [
                                {
                                    "title": "PO Number: ",
                                    "value": payload.po_number

                                },
                                {
                                    "title": "PO Currency: ",
                                    "value": payload.po_currency
                                },
                                {
                                    "title": "Company Code: ",
                                    "value": payload.comp_code
                                },
                                {
                                    "title": "Vendor number: ",
                                    "value": vendor_number.replace(/^0+/, '')
                                },
                                {
                                    "title": "Vendor name: ",
                                    "value": payload.vendor_name
                                }
                            ]
                        }
                    ]
                },
                {
                    "type": "Container",
                    "spacing": "Large",
                    "style": "emphasis",
                    "bleed": true,
                    "items": [
                        {
                            "type": "ColumnSet",
                            "columns": [
                                {
                                    "type": "Column",
                                    "width": "50px",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "wrap": true,
                                            "text": "Line",
                                            "horizontalAlignment": "Center",
                                            "weight": "Bolder"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "150px",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "wrap": true,
                                            "text": "Description",
                                            // "separator": true,
                                            "horizontalAlignment": "Center",
                                            "weight": "Bolder"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "70px",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "wrap": true,
                                            "text": "PO Qty",
                                            // "separator": true,
                                            "horizontalAlignment": "Center",
                                            "weight": "Bolder"
                                        }
                                    ],
                                    "horizontalAlignment": "Center"
                                },
                                {
                                    "type": "Column",
                                    "width": "60px",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "wrap": true,
                                            "text": "Received Qty",
                                            // "separator": true,
                                            "horizontalAlignment": "Center",
                                            "weight": "Bolder"
                                        }
                                    ]
                                },
                                {
                                    "type": "Column",
                                    "width": "70px",
                                    "items": [
                                        {
                                            "type": "TextBlock",
                                            "wrap": true,
                                            "text": "Available Qty",
                                            //"separator": true,
                                            "horizontalAlignment": "Center",
                                            "weight": "Bolder"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                },
                {
                    "type": "Container",
                    "items": this.Columnvalue(data)

                },


            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Submit",
                    "style": "positive",
                    "id": url_details.Form_submite_text,
                    //url_details.browser_language,
                   // "language": url_details.browser_language,
                    "horizontalAlignment": "Center"

                }
            ],

        }
        return po_details

    }
    private static Columnvalue(value) {
        //let data = po_data.get_po_details
        let data = value
        let len = data.length
        // console.log("Length in column value:"+len)
        let column = []
        for (let i = 0; i < len; i++) {
            if (data[i]["avail_qty"] != 0.00 && data[i]["deleted_item"] == "") {

                // let temp = data[i]['po_item']
                // let line = temp.slice(3,temp.length+1)
                let line = data[i]['po_item'].replace(/^0+/, '')
                let des = data[i]["short_text"]
                let po_qty = data[i]["quantity"]
                let received_qty = data[i]["received_qty"].toString()
                let avail = data[i]["avail_qty"].toString()
                //console.log("available qty in colum:"+avail)
                //console.log("received qty in colum:"+received_qty)

                column[i] =
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "10px",
                            "items": [
                                {
                                    "type": "Input.Toggle",
                                    "id": "val" + i,
                                    "title": " ",
                                    "separator": true,
                                    "wrap": true
                                }
                            ],
                            "separator": true,
                            "verticalContentAlignment": "Center",
                            "style": "default",
                            "horizontalAlignment": "Right"
                        },
                        {
                            "type": "Column",
                            "width": "50px",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "wrap": true,
                                    "text": line,
                                    "horizontalAlignment": "Center"
                                }
                            ],

                            "horizontalAlignment": "Center",
                            "separator": true
                        },
                        {
                            "type": "Column",
                            "width": "150px",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": des,
                                    "wrap": true,
                                    "horizontalAlignment": "Center"
                                }
                            ],
                            "horizontalAlignment": "Center",
                            "separator": true
                        },
                        {
                            "type": "Column",
                            "width": "70px",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "wrap": true,
                                    "text": po_qty,
                                    "horizontalAlignment": "Center"
                                }
                            ],
                            "horizontalAlignment": "Center",
                            "separator": true
                        },
                        {
                            "type": "Column",
                            "width": "60px",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "wrap": true,
                                    "text": received_qty,
                                    "horizontalAlignment": "Center"
                                }
                            ],
                            "horizontalAlignment": "Center",
                            "separator": true
                        },
                        {
                            "type": "Column",
                            "width": "70px",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "wrap": true,
                                    "text": avail,
                                    "horizontalAlignment": "Center"
                                }
                            ],
                            "horizontalAlignment": "Center",
                            "separator": true
                        }
                    ],
                    "separator": true
                }
            }
        }
        return column
    }
    private static getQuantity(data1) {
        let data = data1
        let column = []
        console.log("Length value in get quantity:" + data.length)
        for (let i = 0; i < data.length; i++) {
            // let temp =  data[i]["po_item"] 
            // let line = temp.slice(3,temp.length+1)
            let line = data[i]['po_item'].replace(/^0+/, '')
            let des = data[i]["short_text"]
            let avail = data[i]["avail_qty"].toString()
            console.log("available qty in podetails:" + avail)


            column[i] = {
                "type": "ColumnSet",
                "columns": [


                    {
                        "type": "Column",
                        "width": "60px",
                        "items": [
                            {
                                "type": "TextBlock",
                                "wrap": true,
                                "text": line
                            }
                        ],
                        "separator": true
                    },
                    {
                        "type": "Column",
                        "width": "150px",
                        "separator": true,
                        "items": [
                            {
                                "type": "TextBlock",
                                "wrap": true,
                                "text": des
                            }
                        ],

                    },
                    {
                        "type": "Column",
                        "width": "150px",
                        "separator": true,
                        "items": [
                            {
                                "type": "Input.Number",
                                "placeholder": avail,
                                "id": 'qty' + i,
                                "min": 0
                            }
                        ]
                    }
                ],
                "separator": true
            }

        }
        // let submit =      {
        //     "type": "ActionSet",
        //     "actions": [
        //         {
        //             "type": "Action.Submit",
        //             "title": "Submit",
        //             "style": "positive"
        //         }
        //     ],
        //     "horizontalAlignment": "Center",
        //     "spacing": "Small",
        //     "height": "stretch"
        // }
        // column.push(submit)
        return column
    }
    private static ColumnElement(text: any,
        length: number,
        field: string) {
        console.log("Inside column elmenet:" + length + field)
        let column = []
        for (let i = 0; i < length; i++) {
            let text1 = text[i][field]
            column[i] = {
                "type": "TextBlock",
                "text": text1,
                "wrap": true,
                "horizontalAlignment": "Left"
            }
        }

        return column
    }



    private static getVideoCard(stepContext, data) {
        let adaptive_card = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.2",
            "fallbackText": "This card requires Media to be viewed. Ask your platform to update to Adaptive Cards v1.1 for this and more!",
            "body": [
                {
                    "type": "Media",
                    "poster": "https://adaptivecards.io/content/poster-video.png",
                    "sources": [
                        {
                            "mimeType": "video/mp4",
                            "url": "https://adaptivecardsblob.blob.core.windows.net/assets/AdaptiveCardsOverviewVideo.mp4"
                        }
                    ]
                }
            ]
        }

        return adaptive_card
    }

    private static getBookingSuccessful(stepContext, data) {

        let adaptive_card = {
            "type": "AdaptiveCard",
            "body": [
                {
                    "type": "TextBlock",
                    "size": "Large",
                    "text": "Booking Successful",
                    "horizontalAlignment": "left",
                    "height": "stretch",
                    "fontType": "Default",
                    "color": "Good",
                    "weight": "Bolder"
                },
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "Image",
                                    "url": "https://dwsstorageaccount1.blob.core.windows.net/storage/final-image.jpg",
                                    "width": "166px",
                                    "height": "165px"
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Booking ID:",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.result1}`,
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Location :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.ConfirmLocation}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Date :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.FINALDATEOFCONFIRMATION}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Seats :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.Seats}`,
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ],
                            "width": "auto"
                        },
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Timezone :"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.data2.Timezone}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Room Name :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.confirmRoom}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Time Slot :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.StartAndEndTime}`,
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ],
                            "width": "auto"
                        }
                    ]
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Thank you for using Smart Room Booking.",
                    "weight": "Bolder",
                    "size": "Medium",
                    "color": "Accent",
                    "horizontalAlignment": "Center",
                    "spacing": "Small",
                    "fontType": "Default"
                }
            ],
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2"
        }
        return adaptive_card
    }
    private static getMeetingConfirmation(stepContext, data) {
        LoggingUtil.log.debug("10000000000000000000000", data)

        LoggingUtil.log.debug("10000000000000000000000", data.payload10.data2.Timezone)
        let adaptiveCard = {

            "type": "AdaptiveCard",
            "actions": [
                {
                    "type": "Action.Submit",
                    "id": "Cancelling",
                    "title": "Cancel Booking",
                    // "data":"Cancel",
                    "data":
                    {
                        "msteams": {
                            "type": "imBack",
                            "value": "Cancel Booking"
                        }
                    },
                    "style": "destructive"
                },
                {
                    "type": "Action.Submit",
                    "id": "boooking",
                    "title": "Proceed Booking",
                    // "data":"Proceed",
                    "data":
                    {
                        "msteams": {
                            "type": "imBack",
                            "value": "Proceed"
                        }
                    },
                    "style": "positive"
                }
            ],
            "body": [
                {
                    "type": "TextBlock",
                    "size": "Large",
                    "weight": "Bolder",
                    "text": "Confirm Booking",
                    "horizontalAlignment": "left",
                    "height": "stretch",
                    "fontType": "Default"
                },
                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "Image",
                                    "url": "https://dwsstorageaccount1.blob.core.windows.net/storage/final-image.jpg",
                                    "width": "166px",
                                    "height": "165px"
                                }
                            ]
                        },
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Location :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.ConfirmLocation}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Date :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.FINALDATEOFCONFIRMATION}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Seats :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.Seats}`,
                                    "isSubtle": true,
                                    "wrap": true
                                }
                            ],
                            "width": "auto"
                        },
                        {
                            "type": "Column",
                            // "horizontalAlignment": "Center",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Timezone :",
                                    // "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.data2.Timezone}`,
                                    "isSubtle": true,
                                    "wrap": true,
                                    // "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Room Name :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.confirmRoom}`,
                                    "isSubtle": true,
                                    "wrap": true,
                                    // "spacing": "Padding"
                                },

                                {
                                    "type": "TextBlock",
                                    "size": "Medium",
                                    "weight": "Bolder",
                                    "text": "Time Slot :",
                                    "spacing": "Padding"
                                },
                                {
                                    "type": "TextBlock",
                                    "spacing": "Small",
                                    "text": `${data.payload10.StartAndEndTime}`,
                                    "isSubtle": true,
                                    "wrap": true
                                },
                                // {
                                //     "type": "TextBlock",
                                //     "size": "Medium",
                                //     "weight": "Bolder",
                                //     "text": "Country Time :"
                                // },
                                // {
                                //     "type": "TextBlock",
                                //     "spacing": "Small",
                                //     "text": "IST(INDIA)",
                                //     "isSubtle": true,
                                //     "wrap": true
                                // },

                            ],
                            "width": "auto"
                        }
                    ]
                }
            ],
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2"
        }

        return adaptiveCard

    }
    private static getRESOLVED_CANCELLED_STATUS_CARD(stepContext, data) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `I see that the ticket is resolved` +
                        "Ticket:" + data.result[0].number + "**\n\n" +
                        "Status:" + data.result[0].state + "\n\n",

                    "wrap": true

                }
            ]
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),

    }
    private static getCHANNEL_VIDEO_CARD(stepContext, data) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "Media",
                    "sources": [
                        {
                            "mimeType": "video/mp4",
                            "url": "https://cddv4storageaccount.blob.core.windows.net/cdd-v4-container/Create_and_use_private_channels.mp4"
                        }
                    ]
                }
            ],

        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),

    }
    private static getDATE_TIME_CARD_COGNIX(stepContext, data) {
        let adaptivecard = {

            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Please enter  the date and time :",
                    "height": "stretch",
                    "weight": "Bolder",
                    "color": "Accent"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Date :",
                    "color": "Accent"
                },
                {
                    "type": "Input.Date",
                    "id": "Date"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Time :",
                    "color": "Accent"
                },
                {
                    "type": "Input.Time",
                    "id": "Time"
                }
            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Submit",
                    "style": "positive"
                }
            ]
        }
        return adaptivecard
    }
    private static getCLOSE_STATUS_CARD(stepContext, date) {

        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `I see that the ticket is closed on the ${date}.
                        For any other details on this ticket,please click on the 'My Tickets Page' if you had like to
                       *View detailed status notes
                       *Contact Service Desk`,


                    "wrap": true

                }
            ]
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),
    }
    private static getLAST_FIVE_INCIDENT_STATUS_CARD(stepContext) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "SR STATUS\n\n" +
                        "Inc#: RITM0154806 \n\n" +
                        "Issue Description: ALTERAÇÃO PERFIL ACESSO SKYPE - DESABILITAR CONTATOS EXTERNOS \n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "Inc#: RITM0154657\n\n" +
                        "Issue Description: Create a record to request something not defined in the Catalog.\n\n" +
                        "Status: Work in Progress\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "Inc#: RITM0154606\n\n" +
                        "Issue Description: Share folder access to Katarzyna Adrianna\n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "Inc#: RITM0154520\n\n" +
                        "Issue Description: MT User Ammendment 050220 Capital code.pdf\n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "Inc#: RITM0154491\n\n" +
                        "Issue Description: UKmiling Desktop\n\n" +
                        "Status: Pending\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------",

                    "wrap": true
                }
            ]
        }
        return adaptiveCard

    }

    private static getOPEN_STATUS_CARD_FUTURE(stepContext, date) {

        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `I see that the ticket is in OPEN status
                    with the Support team.It is expected to be resolved on ${date}.
                    No action is required from you at this time.The respective team will work and fix the issue`,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),

    }

    private static getOPEN_STATUS_CARD_PAST(stepContext, date) {

        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `I see that the ticket is in OPEN state
                    with the Support team.We realise that the  resolution date was ${date}.
                    Support team is working on the ticket.I will make sure to follow up with them 
                    and they will connect with you`,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),

    }
    public static resolveTktState(state: number): string {
        let resolvedState: string
        switch (state) {
            case 1:
                resolvedState = "New";
                break;
            case 2:
                resolvedState = "In Progress";
                break;
            case 3:
                resolvedState = "On Hold";
                break;
            case 6:
                resolvedState = "Resolved";
                break;
            case 7:
                resolvedState = "Closed";
                break;
            default:
                resolvedState = "Unidentified";
                break;
        }
        return resolvedState;
    }


    private static getSINGLE_INCIDENT_CARD(stepContext, data) {


        let bodyData = []
        if (stepContext.context.activity.channelId == "emulator") {
            console.log("DATA:" + data)
            bodyData = [{
                "type": "TextBlock",
                "text":
                    "**Incident Number :** " + data.number + " \n\n" +
                    "**Short description :** " + data.short_description + " \n\n" +
                    "**Assignment Group :** " + data.assignment_group["display_value"] + " \n\n " +
                    "**Last updated on :** " + data.sys_updated_on + " \n\n " +
                    "**Status :** " + data.state + " \n\n ",//+
                // "**Last customer visible notes :** " + data.result[0].comments,




                "wrap": true

            }]
        }
        else {
            bodyData = [

                {
                    "text": "Ticket Status",
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "ExtraLarge",
                    "color": "Good",
                    "fontType": "Default",
                    "weight": "Bolder",
                    "horizontalAlignment": "Center"

                },
                {
                    "text": data.number,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Large",
                    "color": "Accent",
                    "fontType": "Default",
                    "weight": "Bolder"


                },
                {
                    "text": "❑ **Short description** : " + data.short_description,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "❑ **Assignment Group** : " + data.assignment_group["display_value"],
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "❑ **Date & Time** : " + data.sys_updated_on,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "❑ **Status** : " + data.state,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": data.comments,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Large",
                    "color": "Accent",
                    "fontType": "Default",
                    "weight": "Bolder"

                }
            ]
        }
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyData
        }

        return adaptiveCard

    }


    private static getTICKET_STATUS_CARD(stepContext, { msg, data }) {

        //console.log(data,"ticket status card")

        if (msg == "Ticket Status") {
            msg = MessageUtils.getInstance().getMessage("View_status", stepContext.options.language) + " :"
        }
        else {
            msg = MessageUtils.getInstance().getMessage("SRStatus", stepContext.options.language) + " :"
        }

        let bodyCard = []
        bodyCard.push({
            "type": "TextBlock",
            "wrap": true,
            "text": msg,
            "size": "Large",
            "weight": "Bolder"
        })
        let res = data.map(value => {
            console.log("value", value.number, value.short_description, value.sys_updated_on, value.state)
            bodyCard.push({
                "type": "TextBlock",
                "text": value.number,
                "wrap": true,
                "weight": "Bolder"
            },
                {
                    "type": "TextBlock",
                    "text": MessageUtils.getInstance().getMessage("Summary", stepContext.options.language) + " :" + value.short_description,
                    "wrap": true
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": value.sys_updated_on
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": MessageUtils.getInstance().getMessage("Status_main", stepContext.options.language) + " :" + value.state
                },
                {
                    "type": "TextBlock",
                    "text": "-----------------------------------------------",
                    "wrap": true,
                    "weight": "Bolder"
                })
        })

        console.log(res, "res log")

        let adaptive_card = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.0",
            "body": bodyCard
        }

        return adaptive_card
    }

    private static getUserOnBoarding(stepContext, data) {

        var adaptiveCard = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Onboarding Start Date *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Date",
                    "id": "onboarding_start_date",
                    "min": "2021-03-10"
                },
                {
                    "type": "TextBlock",
                    "text": "First Name *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "id": "first_name",
                    "placeholder": "First Name",
                },
                {
                    "type": "TextBlock",
                    "text": "Last Name *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "id": "last_name",
                    "placeholder": "Last Name",
                },
                {
                    "type": "TextBlock",
                    "text": "Department *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Department",
                    "id": "department",
                },
                {
                    "type": "TextBlock",
                    "text": "Manager *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "id": "manager",
                    "placeholder": "Manager",
                },
                {
                    "type": "TextBlock",
                    "text": "Email *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "id": "email",
                    "placeholder": "Email",
                    "style": "Email",
                },
                {
                    "type": "TextBlock",
                    "text": "Designation *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Designation",
                    "id": "designation",
                },
                {
                    "type": "TextBlock",
                    "text": "Deputed Location *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Deputed Location",
                    "id": "deputed_location",
                },
                {
                    "type": "TextBlock",
                    "text": "Mobile No. *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Mobile No.",
                    "id": "mobile_number",
                    "maxLength": 10,
                    "style": "Tel",
                },
                {
                    "type": "TextBlock",
                    "text": "Account Expires *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "End of",
                            "value": "End of"
                        },
                        {
                            "title": "Never",
                            "value": "Never"
                        }
                    ],
                    "placeholder": "Account Expires",
                    "id": "account_expires",
                },
                {
                    "type": "TextBlock",
                    "text": "User Type *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "Internal",
                            "value": "Internal"
                        },
                        {
                            "title": "External",
                            "value": "External"
                        }
                    ],
                    "placeholder": "User Type",
                    "id": "user_type",

                },
                {
                    "type": "TextBlock",
                    "text": "Computer Type *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "Laptop",
                            "value": "Laptop"
                        },
                        {
                            "title": "Desktop",
                            "value": "Desktop"
                        }
                    ],
                    "placeholder": "Computer Type",
                    "id": "computer_type",

                },
                {
                    "type": "TextBlock",
                    "text": "Mobility *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "Yes",
                            "value": "Yes"
                        },
                        {
                            "title": "No",
                            "value": "No"
                        }
                    ],
                    "placeholder": "Mobility",
                    "id": "mobility",

                },
                {
                    "type": "TextBlock",
                    "text": "Modal After ID *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Modal after ID ",
                    "id": "model_after_id",

                },
                {
                    "type": "TextBlock",
                    "text": "Personna *",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "VIP",
                            "value": "VIP"
                        },
                        {
                            "title": "Office Worker",
                            "value": "Office Worker"
                        },
                        {
                            "title": "Mobile/Nomad worker",
                            "value": "Mobile/Nomad worker"
                        },
                        {
                            "title": "Remote Site Worker",
                            "value": "Remote Site Worker"
                        },
                        {
                            "title": "Industrial Site Worker",
                            "value": "Industrial Site Worker"
                        },
                        {
                            "title": "External Access Worker",
                            "value": "External Access Worker"
                        }
                    ],
                    "placeholder": "Personna",
                    "id": "personna",

                },
                {
                    "type": "TextBlock",
                    "text": "Comments",
                    "weight": "Bolder",
                    "wrap": true
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Comments",
                    "id": "comments",
                    "isMultiline": true,
                },

                {
                    "type": "ActionSet",
                    "actions": [
                        {
                            "type": "Action.Submit",
                            "id": "submit",
                            "title": "Submit",
                            "style": "positive"
                        }
                    ]
                }
            ]
        }
        return adaptiveCard
    }
    private static getDATE_TIME_CARD(stepContext, data) {
        const somedte = new Date().toLocaleDateString().replace(/\//g, '-');

        const month = somedte.toString().substring(0, somedte.length - 8)
        const days = somedte.toString().substring(2, somedte.length - 5)
        const year = somedte.toString().substring(5, somedte.length)
        LoggingUtil.log.debug("CARDDDDD", days, "jdhvsdc", month, "jdhcvdcds", year)
        var finaldateofcard = ""
        if (month !== "10" && month !== "11" && month !== "12") {
            finaldateofcard = year + "-0" + month + "-" + days
            LoggingUtil.log.debug("finalDte", finaldateofcard);
        }
        else {
            finaldateofcard = year + "-" + month + "-" + days
            LoggingUtil.log.debug("finalDte", finaldateofcard);
        }
        //   const somevalue =JSON.stringify(finaldateofcard);
        let adaptiveCard =
        {
            "type": "AdaptiveCard",
            "actions": [
                {
                    "type": "Action.Submit",
                    "id": "submit",
                    "title": "See Availability"
                }
            ],
            "body": [

                {
                    "type": "ColumnSet",
                    "columns":
                        [
                            {
                                "type": "Column",
                                "items": [
                                    {
                                        "type": "TextBlock",
                                        "text": "Date:",
                                    },
                                    {
                                        "type": "Input.Date",
                                        "id": "date",
                                        "title": "New Input.Toggle",
                                        "spacing": "small",
                                        "isRequired": true,
                                        "placeholder": "Enter a date",
                                        "value": `${finaldateofcard}`,
                                        "errorMessage": "Please Select All the Fields"

                                    },
                                ],
                                "width": "auto"
                            },
                            {
                                "type": "Column",
                                "items": [

                                    {
                                        "type": "TextBlock",
                                        "text": "Timezone:",

                                    },
                                    {
                                        "type": "Input.ChoiceSet",
                                        "title": "New Input.Toggle",
                                        "id": "Timezone",
                                        "spacing": "small",
                                        "style": "compact",
                                        "size": "small",
                                        "choices": [
                                            {
                                                "title": "(GMT + 05:30) Asia/Kolkata",
                                                "value": "(GMT + 05:30) Asia/Kolkata"
                                            },
                                            {
                                                "title": "(GMT - 12:00) Etc/GMT+12",
                                                "value": "(GMT - 12:00) Etc/GMT+12"
                                            },
                                            {
                                                "title": "(GMT - 11:00) Etc/GMT+11",
                                                "value": "(GMT - 11:00) Etc/GMT+11"
                                            },
                                            {
                                                "title": "(GMT - 11:00) Pacific/Midway",
                                                "value": "(GMT - 11:00) Pacific/Midway"
                                            },
                                            {
                                                "title": "(GMT - 11:00) Pacific/Niue",
                                                "value": "(GMT - 11:00) Pacific/Niue"
                                            },
                                            {
                                                "title": "(GMT - 11:00) Pacific/Pago_Pago",
                                                "value": "(GMT - 11:00) Pacific/Pago_Pago"
                                            },
                                            {
                                                "title": "(GMT - 11:00) Pacific/Samoa",
                                                "value": "(GMT - 11:00) Pacific/Samoa"
                                            },
                                            {
                                                "title": "(GMT - 11:00) US/Samoa",
                                                "value": "(GMT - 11:00) US/Samoa"
                                            },
                                            {
                                                "title": "(GMT - 10:00) Etc/GMT+10",
                                                "value": "(GMT - 10:00) Etc/GMT+10"
                                            },
                                            {
                                                "title": "(GMT - 10:00) HST",
                                                "value": "(GMT - 10:00) HST"
                                            },
                                            {
                                                "title": "(GMT - 10:00) Pacific/Honolulu",
                                                "value": "(GMT - 10:00) Pacific/Honolulu"
                                            },
                                            {
                                                "title": "(GMT - 10:00) Pacific/Johnston",
                                                "value": "(GMT - 10:00) Pacific/Jhonston"
                                            },
                                            {
                                                "title": "(GMT - 10:00) Pacific/Rarotonga",
                                                "value": "(GMT - 10:00) Pacific/Rarotonga"
                                            },
                                            {
                                                "title": "(GMT - 10:00) Pacific/Tahiti",
                                                "value": "(GMT - 10:00) Pacific/Tahiti"
                                            },
                                            {
                                                "title": "(GMT - 10:00) US/Hawaii",
                                                "value": "(GMT - 10:00) US/Hawaii"
                                            },
                                            {
                                                "title": "(GMT - 09:30) Pacific/Marquesas",
                                                "value": "(GMT - 09:30) Pacific/Marquesas"
                                            },
                                            {
                                                "title": "(GMT - 09:00) America/Adak",
                                                "value": "(GMT - 09:00) America/Adak"
                                            },
                                            {
                                                "title": "(GMT - 09:00) America/Atka",
                                                "value": "(GMT - 09:00) America/Atka"
                                            },
                                            {
                                                "title": "(GMT - 09:00) Etc/GMT+9",
                                                "value": "(GMT - 09:00) Etc/GMT+9"
                                            },
                                            {
                                                "title": "(GMT - 09:00) Pacific/Gambier",
                                                "value": "(GMT - 09:00) Pacific/Gambier"
                                            },
                                            {
                                                "title": "(GMT - 09:00) US/Aleutian",
                                                "value": "(GMT - 09:00) US/Aleutian"
                                            },

                                        ],
                                        "isRequired": true,
                                        "value": "(GMT + 5:00) Asia/Kolkata",
                                        "placeholder": "Select the timezone",
                                        "errorMessage": "Please Select All the Fields",

                                    }
                                ],
                                "width": "auto"
                            },

                        ]
                },



                {
                    "type": "ColumnSet",
                    "columns": [
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "Start time:",

                                },
                                {
                                    "type": "Input.ChoiceSet",
                                    "title": "New Input.Toggle",
                                    "id": "start_time",
                                    "choices": [
                                        {
                                            "title": "00:00 AM",
                                            "value": "00:00 AM"
                                        },
                                        {
                                            "title": "12:15 AM",
                                            "value": "12:15 AM"
                                        },
                                        {
                                            "title": "12:30 AM",
                                            "value": "12:30 AM"
                                        },
                                        {
                                            "title": "12:45 AM",
                                            "value": "12:45 AM"
                                        },
                                        {
                                            "title": "01:00 AM",
                                            "value": "01:00 AM"
                                        },
                                        {
                                            "title": "01:15 AM",
                                            "value": "01:15 AM"
                                        },
                                        {
                                            "title": "01:30 AM",
                                            "value": "01:30 AM"
                                        },
                                        {
                                            "title": "01:45 AM",
                                            "value": "01:45 AM"
                                        },
                                        {
                                            "title": "02:00 AM",
                                            "value": "02:00 AM"
                                        },
                                        {
                                            "title": "02:15 AM",
                                            "value": "02:15 AM"
                                        },
                                        {
                                            "title": "02:30 AM",
                                            "value": "02:30 AM"
                                        },
                                        {
                                            "title": "02:45 AM",
                                            "value": "02:45 AM"
                                        },
                                        {
                                            "title": "03:00 AM",
                                            "value": "03:00 AM"
                                        },
                                        {
                                            "title": "03:15 AM",
                                            "value": "03:15 AM"
                                        },
                                        {
                                            "title": "03:30 AM",
                                            "value": "03:30 AM"
                                        },
                                        {
                                            "title": "03:45 AM",
                                            "value": "03:45 AM"
                                        },
                                        {
                                            "title": "04:00 AM",
                                            "value": "04:00 AM"
                                        },
                                        {
                                            "title": "04:15 AM",
                                            "value": "04:15 AM"
                                        },
                                        {
                                            "title": "04:30 AM",
                                            "value": "04:30 AM"
                                        },
                                        {
                                            "title": "04:45 AM",
                                            "value": "04:45 AM"
                                        },
                                        {
                                            "title": "05:00 AM",
                                            "value": "05:00 AM"
                                        },
                                        {
                                            "title": "05:15 AM",
                                            "value": "05:15 AM"
                                        },
                                        {
                                            "title": "05:30 AM",
                                            "value": "05:30 AM"
                                        },
                                        {
                                            "title": "05:45 AM",
                                            "value": "05:45 AM"
                                        },
                                        {
                                            "title": "06:00 AM",
                                            "value": "06:00 AM"
                                        },
                                        {
                                            "title": "06:15 AM",
                                            "value": "06:15 AM"
                                        },
                                        {
                                            "title": "06:30 AM",
                                            "value": "06:30 AM"
                                        },
                                        {
                                            "title": "06:45 AM",
                                            "value": "06:45 AM"
                                        },
                                        {
                                            "title": "07:00 AM",
                                            "value": "07:00 AM"
                                        },
                                        {
                                            "title": "07:15 AM",
                                            "value": "07:15 AM"
                                        },
                                        {
                                            "title": "07:30 AM",
                                            "value": "07:30 AM"
                                        },
                                        {
                                            "title": "07:45 AM",
                                            "value": "07:45 AM"
                                        },
                                        {
                                            "title": "08:00 AM",
                                            "value": "08:00 AM"
                                        },
                                        {
                                            "title": "08:15 AM",
                                            "value": "08:15 AM"
                                        },
                                        {
                                            "title": "08:30 AM",
                                            "value": "08:30 AM"
                                        },
                                        {
                                            "title": "08:45 AM",
                                            "value": "08:45 AM"
                                        },
                                        {
                                            "title": "09:00 AM",
                                            "value": "09:00 AM"
                                        },
                                        {
                                            "title": "09:15 AM",
                                            "value": "09:15 AM"
                                        },
                                        {
                                            "title": "09:30 AM",
                                            "value": "09:30 AM"
                                        },
                                        {
                                            "title": "09:45 AM",
                                            "value": "09:45 AM"
                                        },
                                        {
                                            "title": "10:00 AM",
                                            "value": "10:00 AM"
                                        },
                                        {
                                            "title": "10:15 AM",
                                            "value": "10:15 AM"
                                        },
                                        {
                                            "title": "10:30 AM",
                                            "value": "10:30 AM"
                                        },
                                        {
                                            "title": "10:45 AM",
                                            "value": "10:45 AM"
                                        },
                                        {
                                            "title": "11:00 AM",
                                            "value": "11:00 AM"
                                        },
                                        {
                                            "title": "11:15 AM",
                                            "value": "11:15 AM"
                                        },
                                        {
                                            "title": "11:30 AM",
                                            "value": "11:30 AM"
                                        },
                                        {
                                            "title": "11:45 AM",
                                            "value": "11:45 AM"
                                        },
                                        {
                                            "title": "12:00 PM",
                                            "value": "12:00 PM"
                                        },
                                        {
                                            "title": "12:15 PM",
                                            "value": "12:15 PM"
                                        },
                                        {
                                            "title": "12:30 PM",
                                            "value": "12:30 PM"
                                        },
                                        {
                                            "title": "12:45 PM",
                                            "value": "12:45 PM"
                                        },
                                        {
                                            "title": "13:00 PM",
                                            "value": "13:00 PM"
                                        },
                                        {
                                            "title": "13:15 PM",
                                            "value": "13:15 PM"
                                        },
                                        {
                                            "title": "13:30 PM",
                                            "value": "13:30 PM"
                                        },
                                        {
                                            "title": "13:45 PM",
                                            "value": "13:45 PM"
                                        },
                                        {
                                            "title": "14:00 PM",
                                            "value": "14:00 PM"
                                        },
                                        {
                                            "title": "14:15 PM",
                                            "value": "14:15 PM"
                                        },
                                        {
                                            "title": "14:30 PM",
                                            "value": "14:30 PM"
                                        },
                                        {
                                            "title": "14:45 PM",
                                            "value": "14:45 PM"
                                        },
                                        {
                                            "title": "15:00 PM",
                                            "value": "15:00 PM"
                                        },
                                        {
                                            "title": "15:15 PM",
                                            "value": "15:15 PM"
                                        },
                                        {
                                            "title": "15:30 PM",
                                            "value": "15:30 PM"
                                        },
                                        {
                                            "title": "15:45 PM",
                                            "value": "15:45 PM"
                                        },
                                        {
                                            "title": "16:00 PM",
                                            "value": "16:00 PM"
                                        },
                                        {
                                            "title": "16:15 PM",
                                            "value": "16:15 PM"
                                        },
                                        {
                                            "title": "16:30 PM",
                                            "value": "16:30 PM"
                                        },
                                        {
                                            "title": "16:45 PM",
                                            "value": "16:45 PM"
                                        },
                                        {
                                            "title": "17:00 PM",
                                            "value": "17:00 PM"
                                        },
                                        {
                                            "title": "17:15 PM",
                                            "value": "17:15 PM"
                                        },
                                        {
                                            "title": "17:30 PM",
                                            "value": "17:30 PM"
                                        },
                                        {
                                            "title": "17:45 PM",
                                            "value": "17:45 PM"
                                        },
                                        {
                                            "title": "18:00 PM",
                                            "value": "18:00 PM"
                                        },
                                        {
                                            "title": "18:15 PM",
                                            "value": "18:15 PM"
                                        },
                                        {
                                            "title": "18:30 PM",
                                            "value": "18:30 PM"
                                        },
                                        {
                                            "title": "18:45 PM",
                                            "value": "18:45 PM"
                                        },
                                        {
                                            "title": "19:00 PM",
                                            "value": "19:00 PM"
                                        },
                                        {
                                            "title": "19:15 PM",
                                            "value": "19:15 PM"
                                        },
                                        {
                                            "title": "19:30 PM",
                                            "value": "19:30 PM"
                                        },
                                        {
                                            "title": "19:45 PM",
                                            "value": "19:45 PM"
                                        },
                                        {
                                            "title": "20:00 PM",
                                            "value": "20:00 PM"
                                        },
                                        {
                                            "title": "20:15 PM",
                                            "value": "20:15 PM"
                                        },
                                        {
                                            "title": "20:30 PM",
                                            "value": "20:30 PM"
                                        },
                                        {
                                            "title": "20:45 PM",
                                            "value": "20:45 PM"
                                        },
                                        {
                                            "title": "21:00 PM",
                                            "value": "21:00 PM"
                                        },
                                        {
                                            "title": "21:15 PM",
                                            "value": "21:15 PM"
                                        },
                                        {
                                            "title": "21:30 PM",
                                            "value": "21:30 PM"
                                        },
                                        {
                                            "title": "21:45 PM",
                                            "value": "21:45 PM"
                                        },
                                        {
                                            "title": "22:00 PM",
                                            "value": "22:00 PM"
                                        },
                                        {
                                            "title": "22:15 PM",
                                            "value": "22:15 PM"
                                        },
                                        {
                                            "title": "22:30 PM",
                                            "value": "22:30 PM"
                                        },
                                        {
                                            "title": "22:45 PM",
                                            "value": "22:45 PM"
                                        },
                                        {
                                            "title": "23:00 PM",
                                            "value": "23:00 PM"
                                        },
                                        {
                                            "title": "23:15 PM",
                                            "value": "23:15 PM"
                                        },
                                        {
                                            "title": "23:30 PM",
                                            "value": "23:30 PM"
                                        },
                                        {
                                            "title": "23:45 PM",
                                            "value": "23:45 PM"
                                        }
                                    ],
                                    "placeholder": "Select Start Time",
                                    "value": "10:15 AM",
                                    "isRequired": true,
                                    "errorMessage": "Please Select All the Fields"
                                },
                            ],
                            "width": "10"
                        },
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "End time:",

                                },
                                {
                                    "type": "Input.ChoiceSet",
                                    "id": "end_time",
                                    "title": "New Input.Toggle",
                                    "choices": [
                                        {
                                            "title": "00:00 AM",
                                            "value": "00:00 AM"
                                        },
                                        {
                                            "title": "12:15 AM",
                                            "value": "12:15 AM"
                                        },
                                        {
                                            "title": "12:30 AM",
                                            "value": "12:30 AM"
                                        },
                                        {
                                            "title": "12:45 AM",
                                            "value": "12:45 AM"
                                        },
                                        {
                                            "title": "01:00 AM",
                                            "value": "01:00 AM"
                                        },
                                        {
                                            "title": "01:15 AM",
                                            "value": "01:15 AM"
                                        },
                                        {
                                            "title": "01:30 AM",
                                            "value": "01:30 AM"
                                        },
                                        {
                                            "title": "01:45 AM",
                                            "value": "01:45 AM"
                                        },
                                        {
                                            "title": "02:00 AM",
                                            "value": "02:00 AM"
                                        },
                                        {
                                            "title": "02:15 AM",
                                            "value": "02:15 AM"
                                        },
                                        {
                                            "title": "02:30 AM",
                                            "value": "02:30 AM"
                                        },
                                        {
                                            "title": "02:45 AM",
                                            "value": "02:45 AM"
                                        },
                                        {
                                            "title": "03:00 AM",
                                            "value": "03:00 AM"
                                        },
                                        {
                                            "title": "03:15 AM",
                                            "value": "03:15 AM"
                                        },
                                        {
                                            "title": "03:30 AM",
                                            "value": "03:30 AM"
                                        },
                                        {
                                            "title": "03:45 AM",
                                            "value": "03:45 AM"
                                        },
                                        {
                                            "title": "04:00 AM",
                                            "value": "04:00 AM"
                                        },
                                        {
                                            "title": "04:15 AM",
                                            "value": "04:15 AM"
                                        },
                                        {
                                            "title": "04:30 AM",
                                            "value": "04:30 AM"
                                        },
                                        {
                                            "title": "04:45 AM",
                                            "value": "04:45 AM"
                                        },
                                        {
                                            "title": "05:00 AM",
                                            "value": "05:00 AM"
                                        },
                                        {
                                            "title": "05:15 AM",
                                            "value": "05:15 AM"
                                        },
                                        {
                                            "title": "05:30 AM",
                                            "value": "05:30 AM"
                                        },
                                        {
                                            "title": "05:45 AM",
                                            "value": "05:45 AM"
                                        },
                                        {
                                            "title": "06:00 AM",
                                            "value": "06:00 AM"
                                        },
                                        {
                                            "title": "06:15 AM",
                                            "value": "06:15 AM"
                                        },
                                        {
                                            "title": "06:30 AM",
                                            "value": "06:30 AM"
                                        },
                                        {
                                            "title": "06:45 AM",
                                            "value": "06:45 AM"
                                        },
                                        {
                                            "title": "07:00 AM",
                                            "value": "07:00 AM"
                                        },
                                        {
                                            "title": "07:15 AM",
                                            "value": "07:15 AM"
                                        },
                                        {
                                            "title": "07:30 AM",
                                            "value": "07:30 AM"
                                        },
                                        {
                                            "title": "07:45 AM",
                                            "value": "07:45 AM"
                                        },
                                        {
                                            "title": "08:00 AM",
                                            "value": "08:00 AM"
                                        },
                                        {
                                            "title": "08:15 AM",
                                            "value": "08:15 AM"
                                        },
                                        {
                                            "title": "08:30 AM",
                                            "value": "08:30 AM"
                                        },
                                        {
                                            "title": "08:45 AM",
                                            "value": "08:45 AM"
                                        },
                                        {
                                            "title": "09:00 AM",
                                            "value": "09:00 AM"
                                        },
                                        {
                                            "title": "09:15 AM",
                                            "value": "09:15 AM"
                                        },
                                        {
                                            "title": "09:30 AM",
                                            "value": "09:30 AM"
                                        },
                                        {
                                            "title": "09:45 AM",
                                            "value": "09:45 AM"
                                        },
                                        {
                                            "title": "10:00 AM",
                                            "value": "10:00 AM"
                                        },
                                        {
                                            "title": "10:15 AM",
                                            "value": "10:15 AM"
                                        },
                                        {
                                            "title": "10:30 AM",
                                            "value": "10:30 AM"
                                        },
                                        {
                                            "title": "10:45 AM",
                                            "value": "10:45 AM"
                                        },
                                        {
                                            "title": "11:00 AM",
                                            "value": "11:00 AM"
                                        },
                                        {
                                            "title": "11:15 AM",
                                            "value": "11:15 AM"
                                        },
                                        {
                                            "title": "11:30 AM",
                                            "value": "11:30 AM"
                                        },
                                        {
                                            "title": "11:45 AM",
                                            "value": "11:45 AM"
                                        },
                                        {
                                            "title": "12:00 PM",
                                            "value": "12:00 PM"
                                        },
                                        {
                                            "title": "12:15 PM",
                                            "value": "12:15 PM"
                                        },
                                        {
                                            "title": "12:30 PM",
                                            "value": "12:30 PM"
                                        },
                                        {
                                            "title": "12:45 PM",
                                            "value": "12:45 PM"
                                        },
                                        {
                                            "title": "13:00 PM",
                                            "value": "13:00 PM"
                                        },
                                        {
                                            "title": "13:15 PM",
                                            "value": "13:15 PM"
                                        },
                                        {
                                            "title": "13:30 PM",
                                            "value": "13:30 PM"
                                        },
                                        {
                                            "title": "13:45 PM",
                                            "value": "13:45 PM"
                                        },
                                        {
                                            "title": "14:00 PM",
                                            "value": "14:00 PM"
                                        },
                                        {
                                            "title": "14:15 PM",
                                            "value": "14:15 PM"
                                        },
                                        {
                                            "title": "14:30 PM",
                                            "value": "14:30 PM"
                                        },
                                        {
                                            "title": "14:45 PM",
                                            "value": "14:45 PM"
                                        },
                                        {
                                            "title": "15:00 PM",
                                            "value": "15:00 PM"
                                        },
                                        {
                                            "title": "15:15 PM",
                                            "value": "15:15 PM"
                                        },
                                        {
                                            "title": "15:30 PM",
                                            "value": "15:30 PM"
                                        },
                                        {
                                            "title": "15:45 PM",
                                            "value": "15:45 PM"
                                        },
                                        {
                                            "title": "16:00 PM",
                                            "value": "16:00 PM"
                                        },
                                        {
                                            "title": "16:15 PM",
                                            "value": "16:15 PM"
                                        },
                                        {
                                            "title": "16:30 PM",
                                            "value": "16:30 PM"
                                        },
                                        {
                                            "title": "16:45 PM",
                                            "value": "16:45 PM"
                                        },
                                        {
                                            "title": "17:00 PM",
                                            "value": "17:00 PM"
                                        },
                                        {
                                            "title": "17:15 PM",
                                            "value": "17:15 PM"
                                        },
                                        {
                                            "title": "17:30 PM",
                                            "value": "17:30 PM"
                                        },
                                        {
                                            "title": "17:45 PM",
                                            "value": "17:45 PM"
                                        },
                                        {
                                            "title": "18:00 PM",
                                            "value": "18:00 PM"
                                        },
                                        {
                                            "title": "18:15 PM",
                                            "value": "18:15 PM"
                                        },
                                        {
                                            "title": "18:30 PM",
                                            "value": "18:30 PM"
                                        },
                                        {
                                            "title": "18:45 PM",
                                            "value": "18:45 PM"
                                        },
                                        {
                                            "title": "19:00 PM",
                                            "value": "19:00 PM"
                                        },
                                        {
                                            "title": "19:15 PM",
                                            "value": "19:15 PM"
                                        },
                                        {
                                            "title": "19:30 PM",
                                            "value": "19:30 PM"
                                        },
                                        {
                                            "title": "19:45 PM",
                                            "value": "19:45 PM"
                                        },
                                        {
                                            "title": "20:00 PM",
                                            "value": "20:00 PM"
                                        },
                                        {
                                            "title": "20:15 PM",
                                            "value": "20:15 PM"
                                        },
                                        {
                                            "title": "20:30 PM",
                                            "value": "20:30 PM"
                                        },
                                        {
                                            "title": "20:45 PM",
                                            "value": "20:45 PM"
                                        },
                                        {
                                            "title": "21:00 PM",
                                            "value": "21:00 PM"
                                        },
                                        {
                                            "title": "21:15 PM",
                                            "value": "21:15 PM"
                                        },
                                        {
                                            "title": "21:30 PM",
                                            "value": "21:30 PM"
                                        },
                                        {
                                            "title": "21:45 PM",
                                            "value": "21:45 PM"
                                        },
                                        {
                                            "title": "22:00 PM",
                                            "value": "22:00 PM"
                                        },
                                        {
                                            "title": "22:15 PM",
                                            "value": "22:15 PM"
                                        },
                                        {
                                            "title": "22:30 PM",
                                            "value": "22:30 PM"
                                        },
                                        {
                                            "title": "22:45 PM",
                                            "value": "22:45 PM"
                                        },
                                        {
                                            "title": "23:00 PM",
                                            "value": "23:00 PM"
                                        },
                                        {
                                            "title": "23:15 PM",
                                            "value": "23:15 PM"
                                        },
                                        {
                                            "title": "23:30 PM",
                                            "value": "23:30 PM"
                                        },
                                        {
                                            "title": "23:45 PM",
                                            "value": "23:45 PM"
                                        }
                                    ],
                                    "placeholder": "Select End Time",
                                    "value": "10:30 AM",
                                    "isRequired": true,
                                    "errorMessage": "Please Select All the Fields"
                                },
                            ],
                            "width": "10"
                        },
                        {
                            "type": "Column",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "Participants:",

                                },
                                {
                                    "id": "participants",
                                    "title": "New Input.Toggle",
                                    "type": "Input.ChoiceSet",
                                    "choices": [
                                        {
                                            "title": "2",
                                            "value": "2"
                                        },
                                        {
                                            "title": "3",
                                            "value": "3"
                                        },
                                        {
                                            "title": "4",
                                            "value": "4"
                                        },
                                        {
                                            "title": "5",
                                            "value": "5"
                                        },
                                        {
                                            "title": "6",
                                            "value": "6"
                                        },
                                        {
                                            "title": "7",
                                            "value": "7"
                                        },
                                        {
                                            "title": "8",
                                            "value": "8"
                                        },
                                        {
                                            "title": "9",
                                            "value": "9"
                                        },
                                        {
                                            "title": "10",
                                            "value": "10"
                                        },
                                        {
                                            "title": "20",
                                            "value": "20"
                                        },
                                        {
                                            "title": "30",
                                            "value": "30"
                                        },
                                        {
                                            "title": "40",
                                            "value": "40"
                                        },
                                        {
                                            "title": "50",
                                            "value": "50"
                                        },
                                        {
                                            "title": "60",
                                            "value": "60"
                                        },
                                        {
                                            "title": "70",
                                            "value": "70"
                                        },
                                        {
                                            "title": "80",
                                            "value": "80"
                                        },
                                        {
                                            "title": "90",
                                            "value": "90"
                                        },
                                        {
                                            "title": "100",
                                            "value": "100"
                                        }

                                    ],
                                    "placeholder": "Select number of participants",
                                    "value": "10",
                                    "isRequired": true,
                                    "errorMessage": "Please Select All the Fields"
                                },
                            ],
                            "width": "10"
                        }

                    ]
                },
                // {
                //     "type": "TextBlock",
                //     "text": "Add Meeting Title:"
                // },
                // {
                //     "type": "Input.Text",
                //     "id": "meeting_title",
                //     "placeholder": "Enter meeting title ",
                //     "maxLength": 200
                // },
                // {
                //     "type": "TextBlock",
                //     "text": "Add Meeting Description :"
                // },
                // {
                //     "type": "Input.Text",
                //     "id": "meeting_description",
                //     "placeholder": "What is this meeting about ?",
                //     "maxLength": 500,
                //     "isMultiline": true
                // }
            ],
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2"
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),
    }


    private static updateUserOnBoarding(stepContext, data) {

        let error_show = {
            "type": "TextBlock",
            "text": 'Field is Required',
            "wrap": true,
            "spacing": "None",
            "size": "Small",
            "weight": "Bolder",
            "color": "Attention"
        }


        let bodyData = []

        if (data.success_msg) {
            bodyData.push({
                "type": "TextBlock",
                "text": data.success_msg,
                "wrap": true,
                "weight": "Bolder",
                "color": "Good",
                "size": "Small"
            })
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Onboarding Start Date *",
            "weight": "Bolder",
            "wrap": true,

        },
            {
                "type": "Input.Date",
                "id": "onboarding_start_date",
                "min": "2021-03-10",
                "value": data.onboarding_start_date,
                "max": "2021-07-15"
            })
        if (!data.onboarding_start_date) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "First Name *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "id": "first_name",
                "placeholder": "First Name",
                "value": data.first_name,
            })
        if (!data.first_name) {
            bodyData.push(error_show)
        }

        bodyData.push(
            {
                "type": "TextBlock",
                "text": "Last Name *",
                "weight": "Bolder",

                "wrap": true
            },
            {
                "type": "Input.Text",
                "id": "last_name",
                "placeholder": "Last Name",
                "value": data.last_name,
            }
        )
        if (!data.last_name) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Department *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "placeholder": "Department",
                "id": "department",
                "value": data.department
            })
        if (!data.department) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Manager *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "id": "manager",
                "placeholder": "Manager",
                "value": data.manager
            })

        if (!data.manager) {
            bodyData.push(error_show)
        }


        bodyData.push({
            "type": "TextBlock",
            "text": "Email *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "id": "email",
                "placeholder": "Email",
                "style": "Email",
                "value": data.email
            })
        if (!data.email) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Designation *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "placeholder": "Designation",
                "id": "designation",
                "value": data.designation
            })
        if (!data.designation) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Deputed Location *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "placeholder": "Deputed Location",
                "id": "deputed_location",
                "value": data.deputed_location
            })
        if (!data.deputed_location) {
            bodyData.push(error_show)
        }


        bodyData.push({
            "type": "TextBlock",
            "text": "Mobile No. *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Number",
                "placeholder": "Mobile No.",
                "id": "mobile_number",
                "maxLength": 10,
                "style": "Tel",
                "value": data.mobile_number
            })
        if (!data.mobile_number) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Account Expires *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.ChoiceSet",
                "choices": [
                    {
                        "title": "End of",
                        "value": "End of"
                    },
                    {
                        "title": "Never",
                        "value": "Never"
                    }
                ],
                "placeholder": "Account Expires",
                "id": "account_expires",
                "value": data.account_expires
            })
        if (!data.account_expires) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "User Type *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.ChoiceSet",
                "choices": [
                    {
                        "title": "Internal",
                        "value": "Internal"
                    },
                    {
                        "title": "External",
                        "value": "External"
                    }
                ],
                "placeholder": "User Type",
                "id": "user_type",
                "value": data.user_type
            })

        if (!data.user_type) {
            bodyData.push(error_show)
        }


        bodyData.push({
            "type": "TextBlock",
            "text": "Computer Type *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.ChoiceSet",
                "choices": [
                    {
                        "title": "Laptop",
                        "value": "Laptop"
                    },
                    {
                        "title": "Desktop",
                        "value": "Desktop"
                    }
                ],
                "placeholder": "Computer Type",
                "id": "computer_type",
                "value": data.computer_type
            })
        if (!data.computer_type) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Mobility *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.ChoiceSet",
                "choices": [
                    {
                        "title": "Yes",
                        "value": "Yes"
                    },
                    {
                        "title": "No",
                        "value": "No"
                    }
                ],
                "placeholder": "Mobility",
                "id": "mobility",
                "value": data.mobility
            })
        if (!data.mobility) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Modal After ID *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.Text",
                "placeholder": "Modal after ID ",
                "id": "model_after_id",
                "value": data.model_after_id
            })
        if (!data.model_after_id) {
            bodyData.push(error_show)
        }

        bodyData.push({
            "type": "TextBlock",
            "text": "Personna *",
            "weight": "Bolder",
            "wrap": true
        },
            {
                "type": "Input.ChoiceSet",
                "choices": [
                    {
                        "title": "VIP",
                        "value": "VIP"
                    },
                    {
                        "title": "Office Worker",
                        "value": "Office Worker"
                    },
                    {
                        "title": "Mobile/Nomad worker",
                        "value": "Mobile/Nomad worker"
                    },
                    {
                        "title": "Remote Site Worker",
                        "value": "Remote Site Worker"
                    },
                    {
                        "title": "Industrial Site Worker",
                        "value": "Industrial Site Worker"
                    },
                    {
                        "title": "External Access Worker",
                        "value": "External Access Worker"
                    }
                ],
                "placeholder": "Personna",
                "id": "personna",
                "value": data.personna
            })

        if (!data.personna) {
            bodyData.push(error_show)
        }


        bodyData.push(
            {
                "type": "TextBlock",
                "text": "Comments",
                "weight": "Bolder",
                "wrap": true
            },
            {
                "type": "Input.Text",
                "placeholder": "Comments",
                "id": "comments",
                "isMultiline": true,
                "value": data.comments
            }
        )

        if (!data.success_msg) {
            bodyData.push({
                "type": "ActionSet",
                "actions": [
                    {
                        "type": "Action.Submit",
                        "id": "submit",
                        "title": "Submit",
                        "style": "positive"
                    }
                ]
            })
        }




        var adaptiveCard = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": bodyData
        }
        return adaptiveCard
    }

    private static getFeedback_card(stepContext, data) {
        let res = data.options.map(val => {
            return {
                "type": "Action.Submit",
                "title": val,
                "data": {
                    "msteams": {
                        "type": "imBack",
                        "value": val
                    }
                }
            }
        })

        var adaptiveCard = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": data.message
                }
            ],
            "actions": res
        }
        return adaptiveCard
    }

    private static getWEATHER_CARD(stepContext, data) {
        var adaptiveCard = {

            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",

            "body": [



                {
                    "type": "ColumnSet",
                    "columns": [

                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": data.city + ",",
                                    "size": "medium",
                                    "spacing": "none",
                                    "weight": "Bolder",
                                }


                            ]
                        },

                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [

                                {
                                    "type": "TextBlock",
                                    "text": data.country,
                                    "size": "medium",
                                    "spacing": "none"
                                }

                            ]
                        }
                    ]
                },
                {
                    "type": "TextBlock",
                    "text": data.weather,
                    "size": "medium",
                    "spacing": "none",
                    "weight": "Bolder"

                },
                {
                    "type": "ColumnSet",
                    "columns": [

                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [
                                {
                                    "type": "TextBlock",
                                    "text": "Temperature:",
                                    "size": "medium",
                                    "spacing": "none"
                                }


                            ]
                        },

                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [

                                {
                                    "type": "TextBlock",
                                    "text": " " + data.temp,
                                    "size": "medium",
                                    "spacing": "none",
                                    "weight": "Bolder"
                                },

                            ]
                        },

                        {
                            "type": "Column",
                            "width": "auto",
                            "items": [

                                {
                                    "type": "TextBlock",
                                    "text": "C",
                                    "size": "medium",
                                    "spacing": "none"

                                }

                            ]
                        }
                    ]
                },
                {
                    "type": "TextBlock",
                    "text": "Min: " + data.minTemp + "C" + " | " + "Max: " + data.maxTemp + "C",
                    "horizontalAlignment": "left",
                    "size": "small",
                    "isSubtle": true
                }

            ]

        };
        return adaptiveCard;
    }

    private static getNEWS_CARD(stepContext, title: string, imgUrl: string, extUrl: string) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "Image",
                    "url": imgUrl,
                    "size": "small"
                },
                {
                    "type": "TextBlock",
                    "text": title,
                    "wrap": true
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "Click here",
                    "url": extUrl
                }
            ]
        }


        return adaptiveCard
    }

    private static getCREATE_INCIDENT_CARD_LIVE_AGENT(stepContext, data) {

        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        "Incident #" + data.number + "**\n\n" +
                        "Issue Description : " + data.description + "\n\n" +
                        "Category:" + data.category + "\n\n" +
                        "Priority : " + data.priority + "\n\n" +
                        "Email: " + "\n\n" +
                        "Phone no.: " + "\n\n" +
                        "Click for more option (Add attachment & Add notes)" + "\n\n" +
                        "In case the issue is not resolved, please let me know, I will help engaging the experts for the same." + "\n\n" +
                        " [Chat with Agent](http://inside.adm.com/inside/en-US/IT/ITSupport/Pages/default.aspx)      " + "[Call Agent](http://inside.adm.com/inside/en-US/IT/ITSupport/Pages/default.aspx)     " + "[Exit](http://inside.adm.com/inside/en-US/IT/ITSupport/Pages/default.aspx)",
                    "wrap": true
                    //Chat with Agent   - Call Agent  - Exit
                }
            ]
        }
        return adaptiveCard

    }
    private static getCATALOG_CARD(stepContext, data) {

        let adaptiveCard = {
            "type": "AdaptiveCard",
            "body": [
                {
                    "type": "Input.Text",
                    "label": "Department",
                    "isRequired": true,
                    "placeholder": "department",
                    "errorMessage": "Department is Required"
                },
                {
                    "type": "Input.Text",
                    "label": "Manager",
                    "placeholder": "Manager",
                    "isRequired": true,
                    "errorMessage": "Manager is Required"
                },
                {
                    "type": "Input.Text",
                    "label": "Email",
                    "placeholder": "Email",
                    "style": "Email",
                    "isRequired": true,
                    "errorMessage": "Email is Required"
                },
                {
                    "type": "Input.Text",
                    "placeholder": "Mobile Number",
                    "label": "Mobile Number",
                    "style": "Tel",
                    "maxLength": 10,
                    "isRequired": true,
                    "errorMessage": "Mobile Number is Required"
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "One",
                            "value": "One "
                        },
                        {
                            "title": "two",
                            "value": "two"
                        },
                        {
                            "title": "three",
                            "value": "three"
                        }
                    ],
                    "placeholder": "dropdown",
                    "label": "dropdown",
                    "style": "expanded",
                    "isRequired": true,
                    "wrap": true
                }
            ],
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.4"
        }
        return adaptiveCard

    }



    private static getCREATE_INCIDENT_CARD(stepContext, data) {
        let s = ''
        if (data.state == 1) {
            s = "New"
        }
        else if (data.state == 2) {
            s = "In Progress"
        }
        else if (data.state == 3) {
            s = "On Hold"
        }
        else if (data.state == 6) {
            s = "Resolved"
        }
        else if (data.state == 7) {
            s = "Closed"
        }
        else if (data.state == 8) {
            s = "Cancelled"
        }
        else {
            s = data.state
        }

        console.log(stepContext.options.language + "lang_check")
        console.log(data + "checking data")
        let bodyData = []
        if (stepContext.context.activity.channelId == "webchat" || stepContext.context.activity.channelId == "directline") {
            bodyData = [{
                "text": "Ticket ",
                "type": "TextBlock",
                "wrap": true,
                "horizontalAlignment": "Center",
                "height": "stretch",
                "size": "ExtraLarge",
                "color": "Good",
                "fontType": "Default",
                "weight": "Bolder"

            },
            {
                "text": "**Ticket Number** : " + data.number,
                "type": "TextBlock",
                "wrap": true,
                "size": "Large",
                "color": "Accent",
                "fontType": "Default",
                "weight": "Bolder"


            },
            {
                "text": "❑ **Status** : " + data.state,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "❑ **Short description** : " + data.short_description,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "❑ **Category** : " + data.category,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "❑ **Priority** : " + data.priority,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            }
                //     {
                //     "type": "TextBlock",
                //     "text":
                //          MessageUtils.getInstance().getMessage("IncidentNumber",stepContext.options.language)+ " : " + data.number + " \n\n" +
                //          MessageUtils.getInstance().getMessage("Status1",stepContext.options.language)+ " : "+ s  + " \n\n " +
                //          MessageUtils.getInstance().getMessage("Short_Description",stepContext.options.language)+ " : "+ data.short_description + " \n\n" +
                //          MessageUtils.getInstance().getMessage("Category",stepContext.options.language)+ " : " + data.category+ " \n\n " +
                //          MessageUtils.getInstance().getMessage("Priority1",stepContext.options.language)+ " : " + data.priority + " \n\n " +
                //        // "**Contact Number :** " + data.description.Contact  + " \n\n " +
                //         MessageUtils.getInstance().getMessage("Assignment_Group",stepContext.options.language) +" \n\n " ,//+
                //        // "**Last customer visible notes :** " + data.result[0].comments,

                //     "wrap": true

                // }
            ]
        }
        else {






            bodyData = [

                // {
                //     "text":  "Ticket " ,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "horizontalAlignment":"Center",
                //     "height":"stretch",
                //     "size": "ExtraLarge",
                //     "color": "Good",
                //     "fontType": "Default",
                //     "weight": "Bolder"

                // },  
                {
                    "text": MessageUtils.getInstance().getMessage("IncidentNumber", stepContext.options.language) + " : " + data.number,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Large",
                    "color": "Accent",
                    "fontType": "Default",
                    "weight": "Bolder"


                },
                {
                    "text": '❑' + MessageUtils.getInstance().getMessage("Status1", stepContext.options.language) + " : " + s,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": '❑' + MessageUtils.getInstance().getMessage("Short_Description", stepContext.options.language) + " : " + data.short_description,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": '❑' + MessageUtils.getInstance().getMessage("Category", stepContext.options.language) + " : " + data.category,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": '❑' + MessageUtils.getInstance().getMessage("Priority1", stepContext.options.language) + " : " + data.priority,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                }
                // {
                //     "text": "Assignment Group : "+data.assignment_group ,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "size": "Medium",
                //     "color": "default",
                //     "fontType": "Default"
                // }
            ]
        }
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyData
        }

        return adaptiveCard

    }
    private static getCREATE_INCIDENT_CARD1(stepContext, data) {
        console.log(stepContext.options.language + "lang_check1")
        let status = data.description
        let updatedStatus = status.split('|')[1]
        let bodyData = []
        if (stepContext.context.activity.channelId == "webchat" || stepContext.context.activity.channelId == "directline") {
            bodyData = [{

                "text": "Ticket Status",
                "type": "TextBlock",
                "wrap": true,
                "size": "Large",
                "color": "Accent",
                "fontType": "Default",
                "weight": "Bolder"

            },
            {
                "text": "Ticket Number :" + data.number,
                "type": "TextBlock",
                "wrap": true,
                "size": "Large",
                "color": "Accent",
                "fontType": "Default",
                "weight": "Bolder"

            },
            {
                "text": "Status :" + data.state,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Short description :" + data.short_description,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Category :" + data.category,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Priority :" + data.priority,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Assignment Group : DDP Service Desk",
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            }
            ]
        }
        else {
            bodyData = [

                {
                    "text": data.number,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Large",
                    "color": "Accent",
                    "fontType": "Default",
                    "weight": "Bolder"

                },
                // {
                //     "text": "Ticket Number :" + data.number ,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "size": "Large",
                //     "color": "Accent",
                //     "fontType": "Default",
                //     "weight": "Bolder"

                // },                
                // {
                //     "text": "Status :" + data.state,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "size": "Medium",
                //     "color": "default",
                //     "fontType": "Default"
                // },
                {
                    "text": "Category :    " + data.category,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Short description : " + data.short_description,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Status : " + "New",
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Created :    " + data.sys_updated_on,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "**Work Note** : " + "\n\n" + "\n\n" + " **•** " + "Outlook OST problem :Launched fix outlook_crash_with_snow | " + updatedStatus,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                }
            ]

        }
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyData
        }

        return adaptiveCard

    }

    private static getCREATE_INCIDENT_CARD_2(stepContext, data) {
        console.log(stepContext.options.language + "lang_check1")
        let status = data.description
        let updatedStatus = status.split('|')[1]



        let bodyData = []
        if (stepContext.context.activity.channelId == "webchat" || stepContext.context.activity.channelId == "directline") {
            bodyData = [{

                "text": "Ticket Status",
                "type": "TextBlock",
                "wrap": true,
                "size": "Large",
                "color": "Accent",
                "fontType": "Default",
                "weight": "Bolder"

            },
            {
                "text": "Ticket Number :" + data.number,
                "type": "TextBlock",
                "wrap": true,
                "size": "Large",
                "color": "Accent",
                "fontType": "Default",
                "weight": "Bolder"

            },
            {
                "text": "Status :" + data.state,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Short description :" + data.short_description,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Category :" + data.category,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Priority :" + data.priority,
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            },
            {
                "text": "Assignment Group : DDP Service Desk",
                "type": "TextBlock",
                "wrap": true,
                "size": "Medium",
                "color": "default",
                "fontType": "Default"
            }
            ]
        }
        else {
            bodyData = [

                {
                    "text": data.number,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Large",
                    "color": "Accent",
                    "fontType": "Default",
                    "weight": "Bolder"

                },
                // {
                //     "text": "Ticket Number :" + data.number ,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "size": "Large",
                //     "color": "Accent",
                //     "fontType": "Default",
                //     "weight": "Bolder"

                // },                
                // {
                //     "text": "Status :" + data.state,
                //     "type": "TextBlock",
                //     "wrap": true,
                //     "size": "Medium",
                //     "color": "default",
                //     "fontType": "Default"
                // },
                {
                    "text": "Category :    " + data.category,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Short description : " + data.short_description,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Status : " + "New",
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "Created :    " + data.sys_updated_on,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                },
                {
                    "text": "**Work Note** : " + "\n\n" + "\n\n" + " **•** " + "Device Health Checkup : Storage Disk Cleanup | " + updatedStatus,
                    "type": "TextBlock",
                    "wrap": true,
                    "size": "Medium",
                    "color": "default",
                    "fontType": "Default"
                }
            ]

        }
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyData
        }

        return adaptiveCard

    }

    private static getFORM_CARD(data) {
        var bodyElementsItemsArr: any = new Array();

        // bodyElementsItemsArr.push(
        //     this.bodyElementsItemsTextBox(
        //         "",
        //         "bolder",
        //         "small",
        //         "none",
        //         "light",
        //         "large", false)
        // )
        for (let i = 0; i < data.length; i++) {

            if (data[i].choices) {
                bodyElementsItemsArr.push(
                    this.bodyElementsItemsTextBox(
                        data[i].label,
                        "bolder",
                        "small",
                        "none",
                        "light",
                        "large", false)
                )

                let options = []
                for (let j = 0; j < data[i].choices.length; j++) {
                    options.push(
                        {
                            'title': data[i].choices[j].label,
                            'value': data[i].choices[j].value
                        })
                }
                //LoggingUtil.log.debug("options: "+JSON.stringify(options)+":choices:"+JSON.stringify(data[i].choices))
                bodyElementsItemsArr.push(
                    this.bodyElementsItemsChoiceSet('UseCaseQue1', 'compact', false, options)
                )

            } else {
                bodyElementsItemsArr.push(
                    this.bodyElementsItemsTextBox(
                        data[i].label,
                        "bolder",
                        "small",
                        "none",
                        "light",
                        "large", false)
                )
                bodyElementsItemsArr.push(
                    this.bodyElementsFormFields('id1', '')
                )
            }

        }



        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyElementsItemsArr,
            "wrap": true,
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Send",
                    "data": {
                        "type": "Submit"
                    }
                }
            ]
        }
        return adaptiveCard;
    }

    public static getLiveAgentPrompt_CARD(stepContext) {
        let contextPath = "https://csd-core-1.azurewebsites.net";
        var textCard = "Relevant Information:\n\n";
        textCard = textCard + " \n\n";
        textCard = textCard + "**Title**  "
        textCard = textCard + "  link:" + contextPath

        var adaptiveCard = {
            'contentType': 'application/vnd.microsoft.card.adaptive',
            'content': {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.0",
                "body": [
                    {
                        "type": "TextBlock",
                        "text": MessageUtils.getInstance().getMessage("Connect1", stepContext.options.language),
                        "wrap": true
                    }
                ],
                "actions": [
                    {
                        "type": "Action.OpenUrl",
                        "title": MessageUtils.getInstance().getMessage("LiveChat", stepContext.options.language),
                        "url": "chat",

                    },
                    {
                        "type": "Action.OpenUrl",
                        "title": MessageUtils.getInstance().getMessage("CallMe", stepContext.options.language),
                        "url": "call",

                    }
                ]
            }
        }
        var card: any = {};
        card.adaptiveCard = adaptiveCard;
        card.textCard = textCard;
        console.log("**************111111111111111111111111111111", adaptiveCard)
        let message = MessageFactory.attachment(adaptiveCard)
        return message;
    }
    public static getLiveAgentPrompt_CARDFR(stepContext) {
        let contextPath = "https://csd-core-1.azurewebsites.net";
        var textCard = 'Relevant Information:\n\n';
        textCard = textCard + '\n\n';
        textCard = textCard + "**Title**"
        textCard = textCard + "link:" + contextPath

        var adaptiveCard = {
            'contentType': 'application/vnd.microsoft.card.adaptive',
            'content': {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.2",
                "body": [
                    {
                        "type": "TextBlock",
                        "text": MessageUtils.getInstance().getMessage("Connect1", stepContext.options.language),
                        "wrap": true
                    }
                ],
                "actions": [
                    {
                        "type": "Action.Submit",
                        "id": "Cancelling",
                        "title": MessageUtils.getInstance().getMessage("LiveChat", stepContext.options.language),
                        "data": "Chat",
                        // "data":
                        // {
                        //     "msteams": {
                        //         "type": "imBack",
                        //         "value": "Chat"
                        //     }
                        // }
                    },
                    {
                        "type": "Action.Submit",
                        "id": "boooking",
                        "title": MessageUtils.getInstance().getMessage("CallMe", stepContext.options.language),
                        "data": "Call",
                        // "data":
                        //  {
                        //     "msteams": {
                        //         "type": "imBack",
                        //         "value": "Call Me"
                        //     }
                        // }
                    }
                ]
            }
        }
        var card: any = {};
        card.adaptiveCard = adaptiveCard;
        card.textCard = textCard;
        console.log("**************111111111111111111111111111111", adaptiveCard)
        let message = MessageFactory.attachment(adaptiveCard)
        return message;
    }

    private static getKB_CARD(data) {

        let adaptiveCard = {

            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "",
                    "wrap": true

                },
                {
                    "type": "TextBlock",
                    "text": "📰 " + data.number + " \n\n" +
                        data.short_description,
                    "wrap": true

                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "title": "Click here",
                    "url": "https://tcsesbx.service-now.com/tcscognix?id=kb_article&sys_id=" + data.sys_id + "&table=kb_knowledge"
                }
            ]
        }

        return adaptiveCard
    }


    private static getLAST_FIVE_TICKET_STATUS_CARD(stepContext) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "SR STATUS\n\n" +
                        "SR Number: RITM0154806 \n\n" +
                        "Summary: ALTERAÇÃO PERFIL ACESSO SKYPE - DESABILITAR CONTATOS EXTERNOS \n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "SR Number: RITM0154657\n\n" +
                        "Summary: Create a record to request something not defined in the Catalog.\n\n" +
                        "Status: Work in Progress\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "SR Number: RITM0154606\n\n" +
                        "Summary: Share folder access to Katarzyna Adrianna\n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "SR Number: RITM0154520\n\n" +
                        "Summary: MT User Ammendment 050220 Capital code.pdf\n\n" +
                        "Status: Open\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------\n\n" +
                        "SR Number: RITM0154491\n\n" +
                        "Summary: UKmiling Desktop\n\n" +
                        "Status: Pending\n\n" +
                        `Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        "--------------------------------------------------------------------------",

                    "wrap": true
                }
            ]
        }
        return adaptiveCard

    }


    private static getSINGLE_TICKET_STATUS_CARD(stepContext, data) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "NUMBER AS INC***\n\n" +
                        `INC #: ${data.number} \n\n` +
                        `Status: ${data.state}\n\n` +
                        `Due Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        `Approval: ${data.approval}\n\n` +
                        "Requested For:1429813\n\n" +
                        "Assignment Group:Service Desk\n\n" +
                        "Assigned to:Service Desk\n\n" +
                        "Affected CI:*********\n\n" +
                        `Due Date :  ${stepContext.context.activity.channelData.clientTimestamp}\n\n ` +
                        `Priority:${data.priority}\n\n` +
                        `Short Description: ${data.short_description} \n\n` +
                        `Description:${data.short_description}\n\n` +
                        "Add Attachment\t\t\t\tAdd Note",

                    "wrap": true
                }
            ]
        }
        return adaptiveCard

    }


    private static getFIRST_FIVE_TICKET_STATUS_CARD(stepContext, data: any): any {

        console.log(data, "data")

        var bodyElementsItemsArr: any = new Array();

        bodyElementsItemsArr.push(
            this.bodyElementsItemsTextBox(
                MessageUtils.getInstance().getMessage("SRStatus", stepContext.options.language) + " :",
                "bolder",
                "small",
                "none",
                "default",
                "large", false)
        )

        for (let i = 0; i < data.length; i++) {

            if (i === 5) {
                break;
            }

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    data[i].number,
                    "bolder",
                    "small",
                    null, "default", null, false)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    MessageUtils.getInstance().getMessage("Summary", stepContext.options.language) + " :" + data[i].short_description,
                    "none",
                    "small",
                    null, "default", null, true)
            );


            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    data[i].sys_updated_on,
                    "none",
                    "small",
                    null, "default", null, true)
            );
            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    MessageUtils.getInstance().getMessage("Status_main", stepContext.options.language) + " :" + data[i].state,
                    "none",
                    "small",
                    null, "default", null, true)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "-----------------------------------------------",
                    "bolder",
                    "small",
                    null, "default", null, false)
            );

        }



        return this.bodyAdaptiveCardBody(bodyElementsItemsArr);

    }
    private static getFIRST_FIVE_TICKET_INCIDENT_CARD(stepContext, data: any): any {


        var bodyElementsItemsArr: any = new Array();

        bodyElementsItemsArr.push(
            this.bodyElementsItemsTextBox(
                MessageUtils.getInstance().getMessage("Incident_Status", stepContext.options.language) + " :",
                "bolder",
                "small",
                "none",
                "default",
                "large", false)
        )

        for (let i = 0; i < data.length; i++) {

            if (i === 5) {
                break;
            }

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    data[i].number,
                    "bolder",
                    "small",
                    null, "default", null, false)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    MessageUtils.getInstance().getMessage("Summary", stepContext.options.language) + " :" + data[i].short_description,
                    "none",
                    "small",
                    null, "default", null, true)
            );


            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    data[i].sys_updated_on,
                    "none",
                    "small",
                    null, "default", null, true)
            );
            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    MessageUtils.getInstance().getMessage("Status_main", stepContext.options.language) + " :" + data[i].state,
                    "none",
                    "small",
                    null, "default", null, true)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "-----------------------------------------------",
                    "bolder",
                    "small",
                    null, "default", null, false)
            );

        }



        return this.bodyAdaptiveCardBody(bodyElementsItemsArr);

    }
    
    private static bodyElementsItemsTextBox(text: string,
        weight: string,
        spacing: string,
        horizontalAlignment: string,
        color: string,
        size: string,
        wrap: boolean) {
        return {
            "type": "TextBlock",
            "text": text,
            "weight": weight,
            "spacing": spacing,
            "horizontalAlignment": horizontalAlignment,
            "color": color,
            "size": size,
            "wrap": wrap
        }
    }

    private static bodyElementsItemsChoiceSet(
        id: string,
        style: string,
        isMultiSelect: boolean,
        choices: any[]) {
        return {
            "type": "Input.ChoiceSet",
            "id": id,
            "style": style,
            "isMultiSelect": isMultiSelect,
            "value": 1,
            "choices": choices,
        }
    }

    private static bodyElementsFormFields(
        id: string,
        placeholder: string) {
        return {
            "type": "Input.Text",
            "id": id,
            'placeholder': placeholder
        }
    }

    private static bodyAdaptiveCardBody(bodyData: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyData,
            "wrap": true
        }
        return adaptiveCard;
    }
    private static GREETING_CARD(stepContext) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Important!",
                    "size": "large"
                },
                {
                    "type": "TextBlock",
                    "text": "Please be informed that there is an outage of 5 applications that you use!"
                }
            ],
            "actions": [
                {
                    "type": "Action.OpenUrl",
                    "url": "http://adaptivecards.io",
                    "title": "Show Outages"
                }
            ]
        }

        return adaptiveCard;
    }
    public static OUTAGES_CARD(stepContext, data): any {

        var bodyElementsItemsArr: any = new Array();

        bodyElementsItemsArr.push(
            this.bodyElementsItemsTextBox(
                "Outages Card",
                "bolder",
                "small",
                "none",
                "light",
                "large", false)
        )

        for (let i = 0; i < data.length; i++) {

            if (i === 5) {
                break;
            }

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    data[i].cmdb_ci.display_value,
                    "bolder",
                    "small",
                    null, null, null, false)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "Type: " + data[i].type,
                    "none",
                    "small",
                    null, null, null, true)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "Start: " + data[i].begin,
                    "none",
                    "small",
                    null, null, null, true)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "End: " + data[i].end,
                    "none",
                    "small",
                    null, null, null, true)
            );

            bodyElementsItemsArr.push(
                this.bodyElementsItemsTextBox(
                    "Duration: " + data[i].duration,
                    "none",
                    "small",
                    null, null, null, true)
            );

            if (i !== 4) {
                bodyElementsItemsArr.push(
                    this.bodyElementsItemsTextBox(
                        "-----------------------------------------------",
                        "bolder",
                        "small",
                        null, null, null, false)
                );
            }


        }
        var adaptiveCard = {

            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": bodyElementsItemsArr,
            "wrap": true
        }
        return adaptiveCard;
        //return  this.bodyAdaptiveCardBody(bodyElementsItemsArr);
        //return this.insertChannelDataWithCard(session,
        // data, 'CARD_ITSM_OUTAGE',
        //this.cardObject("", this.bodyAdaptiveCardBody(bodyElementsItemsArr)))

    }


    private static getHRCREATE_INCIDENT_CARD(stepContext, data) {
        let short_description_string = MessageUtils.getInstance().getMessage("short_description",stepContext.context.activity.locale) 
        
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",

                    "text":
                        `Sorry I'm still learning! Meanwhile, I have raised a ticket in ServiceNow related to your request. Here are the details :\n\n`+
                        `**INC** : ${data.INC_Number} \n\n` +
                        `**Status** : Open \n\n` +
                        "**Requested-For** : 1429813\n\n" +
                        "**Assignment-Group** : APP-FLS-BotFramework\n\n" +
                        "**Affected-CI** : *********\n\n" +
                        `**Priority** : Normal\n\n` +
                        `**Short-Description** : Intent not found\n\n` +
                        `**Description** : User was searching for "${data.utterance}" \n\n`,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard

    }


    public static getpdfcontentCard(stepContext:any,data: any){
        let bodydata = []

        for(let i=0;i<data.length;i++){
            let container_items = []
            let action_set = []
            let column_set = []
            action_set.push(
                {
                    "type": "Action.OpenUrl",
                    "title": "More",
                    "url":data[i]["metadata_spo_item_weburi"]
                }
            )
    
    
            if(i!=0){
            column_set.push(
                {
                    "type": "Column",
                    "width": "stretch",
                    "items": [
                        {
                            "type": "ActionSet",
                            "actions": [
                                {
                                    "type": "Action.ToggleVisibility",
                                    "title": "Previous Result",
                                    "targetElements": [
                                        "container"+i,"container"+(i-1)
                                        ]
                                    }
                            ]
                        }
                    ]
                }
            )
            }
    
            if(i!=data.length-1){
                column_set.push(
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {
                                "type": "ActionSet",
                                "actions": [
                                    {
                                        "type": "Action.ToggleVisibility",
                                        "title": "Next Result",
                                        "targetElements": [
                                            "container"+i,"container"+(i+1)
                                            ]
                                        }
                                ]
                            }
                        ]
                    }
                )
            }
            let filename = data[i]["metadata_spo_item_name"].split(".")
            let name = filename[0]
            container_items.push(
                {
                    "type": "TextBlock",
                    "text": (i+1)+"." +name,
                    //"text": data[i]["metadata_spo_item_name"] + "\n\n"+i+". "+data[i]["@search.captions"][0][ "text"] + "\n\n"+" For More Click On below Link",//"\n\n" +data[i]["content"].slice(0,500),//data[i]["content"],
                    "wrap": true,
                    "size": "medium",
                    "weight": "bolder",
                    "id": "metadata"+i,
                },
                {
                    "type": "TextBlock",
                    "text": data[i]["@search.captions"][0][ "text"],
                    "wrap": true,
                },
                {
                    "type": "TextBlock",
                    "text": "For more details click on '**More**' option below.",
                    "color": "accent",
                }
            )

    
            container_items.push(
                {
                    "type": "ActionSet",
                    "actions":action_set
                }
            )
    
            container_items.push(
                {
                    "type": "ColumnSet",
                    "columns": column_set
                }
            )
    
            bodydata.push(
            {
                "type": "Container",
                "items": container_items,
                "id": "container"+i,
                "isVisible": i==0 ? true : false
            }
            )
    
        }
      
            let adaptiveCard = {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "msTeams": {
                  "width": "full"
                },
                "version": "1.2",
                "body": bodydata
            }
           
        return adaptiveCard

    }
    public static testCard(stepContext:any,data: any){



        let bodydata = []
        for(let i =0; i<data.length ; i++){
            let container_items = []
            let action_set = []

            action_set.push(
                {
                    "type": "Action.OpenUrl",
                    "title": "More",
                    "url":data[i]["metadata_spo_item_weburi"],
                    "style": "Positive",

                }
            )


            container_items.push(
                {
                    "type": "TextBlock",
                    "text": data[i]["metadata_spo_item_name"] + "\n\n"+i+". "+data[i]["@search.captions"][0][ "text"] + "\n\n"+" For More Click On below Link",//"\n\n" +data[i]["content"].slice(0,500),//data[i]["content"],
                    "wrap": true,
                    "id": "metadata"+i,
                }
            )

    
            container_items.push(
                {
                    "type": "ActionSet",
                    "actions":action_set
                }
            )

            
            bodydata.push(
                {
                    "type": "Container",
                    "items": container_items,
                    "id": "container"+i,
                    "isVisible": i==0 ? true : false
                }
            )

        }
        
        let adaptiveCard = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "msTeams": {
                "width": "full"
            },
            "body": bodydata
        }
    return adaptiveCard
    }


    public static getpdfCard(stepContext: any, data: any){
        let filename = data["metadata_spo_item_name"].split(".")
        let name = filename[0]
        let text = data["@search.captions"][0][ "text"]
        if(text.includes(".pdf") || text.includes(".docx") || text.includes(".doc") || text.includes(".pptx") || text.includes(".ppt") || text.includes(".xlsx") || text.includes(".xls")){
            console.log("***description includes file path***")
            text= data["content"].slice(0,100)
        }

        let adaptiveCard = {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type": "RichTextBlock",
                    "inlines": [
                        {
                          "type": "TextRun",
                          "text": name+"\n\n",
                          "wrap": true,
                          "size": "medium",
                          "weight": "bolder",
                        },
                        {
                            "type": "TextRun",
                            "text": text+"\n\n",//"\n\n" +data[i]["content"].slice(0,500),//data[i]["content"],
                            "wrap": true,
                        },
                          {
                            "type": "TextRun",
                            "text": "For more details click on '",  
                            "color": "accent",
                          },
                          {
                            "type": "TextRun",
                            "text": "More",
                            "color": "accent",
                            "weight": "bolder",
                          },
                          {
                            "type": "TextRun",
                            "text": "' option below.",
                            "color": "accent",
                          }
                    ],
                    "spacing": "Large",
                    "horizontalAlignment": "Left",
                    "height": "stretch",
                    "wrap": true,

                }
            ] ,

                "actions": [
                    {
                        "type": "Action.OpenUrl",
                            "title": "More",
                            "url":data.metadata_spo_item_weburi,
                            "style": "Positive",
                    }
                ]
            
        }
        return adaptiveCard
    
    }

    public static getOnPremise_Card(stepContext: any, data: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Here are your '**On-Premise Information**':\n\n   " +
                        `**On-premises sync enabled** : ${data["onPremisesSyncEnabled"]} \n\n` +
                        `**On-premises domain name** : ${data["onPremisesDomainName"]}\n\n` +
                        `**On-premises user principal name** : ${data["onPremisesUserPrincipalName"]}\n\n` +
                        `**On-premises SAM account name** : ${data["onPremisesSamAccountName"]}\n\n` +
                        `**On-premises last sync date time** : ${data["onPremisesLastSyncDateTime"]}\n\n`,
                    "wrap": true
                }
            ]
        }
        return adaptiveCard


    }
    public static getpersonnel_card(stepContext: any, data: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Here are your '**Personal Information**':\n\n" +
                        `**Name** : ${data["displayName"]} \n\n` +
                       // `**First Name** : ${data["givenName"]} \n\n` +
                       // `**Last Name** : ${data["surname"]} \n\n` +
                        `**User-Type** : ${data["userType"]} \n\n` +
                        `**Account-Enabled** : ${data["accountEnabled"]}\n\n` +
                        //`**Mail-Nickname** : ${data["mailNickname"]}\n\n` +
                        `**Mail-ID** : ${data["mail"]}\n\n`+
                        `**Alternate Mail-ID** : ${data["otherMails"][0]}`,
                    "wrap": true
                }
            ]
        }
        return adaptiveCard


    }
    public static getOffice_card(stepContext: any, data: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Here are your '**Job Information**':   \n\n" +
                        `**Job title** : ${data["jobTitle"]} \n\n` +
                        `**Company name** : ${data["companyName"]}\n\n` +
                        `**Department** : ${data["department"]}\n\n` +
                        `**Employee-ID** : ${data["employeeId"]}\n\n` +
                        `**Office-Location** : ${data["officeLocation"]}\n\n` ,
                    "wrap": true
                }
            ]
        }
        return adaptiveCard


    }
    public static getcontact_Info_Card(stepContext: any, data: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text": "Here are your '**Contact Information**':\n\n" +
                        `**Street-Address** : ${data["streetAddress"]} \n\n` +
                        `**City** : ${data["city"]}\n\n` +
                        `**State/Province** : ${data["state"]}\n\n` +
                        `**Country** : ${data["usageLocation"]}\n\n`+
                        `**ZIP/Postal-Code** : ${data["postalCode"]}\n\n` +
                        `**Mobile-Phone** : ${data["mobilePhone"]}\n\n` +
                        `**Business-Phone** : ${data["businessPhones"][0]}\n\n` +
                        `**Mail-ID** : ${data["mail"]}\n\n`,
                    "wrap": true
                }
            ]
        }
        return adaptiveCard


    }
    public static getManagerCard(stepContext: any, data: any) {
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                { "type": "TextBlock",
                "text": "Here are your '**Manager's Information**':\n\n" +
                    `**Display Name** : ${data["displayName"]} \n\n` +
                    `**User-Type** : ${data["userType"]} \n\n` +
                    //`**Account-Enabled** : ${data["accountEnabled"]}\n\n` +
                    `**Mail-ID** : ${data["mail"]}\n\n`+
                    `**Street-Address** : ${data["streetAddress"]} \n\n` +
                    `**City** : ${data["city"]}\n\n` +
                    `**State/Province** : ${data["state"]}\n\n` +
                    //`**Country** : ${data["usageLocation"]}\n\n`+
                    `**Department** : ${data["department"]}\n\n` +
                    `**Employee-ID** : ${data["employeeId"]}\n\n` +
                    `**Office-Location** : ${data["officeLocation"]}\n\n` ,


                  "wrap": true
                }
            ]
        }
        return adaptiveCard


    }

    private static getMultipleInfo(stepContext, value: any) {
        console.log("data-->",value)
        //console.log("here is the data-->", value.data)
       // console.log("here is the data1-->",value.data1['ITContact'])
        let data = value.data
        let data1 = value.data1
        let contact, owner, Vendor, process, backup
        let itemail=' ' 
        let owneremail=' '
        let itcontactvalue, ownervalue
        
        if(data1['ITContact'] !=undefined){
            contact = data1['ITContact'][0]['Title']
            itemail = data1['ITContact'][0]['EMail']
            //console.log("here is the data-->", contact)
        }
        else {
            contact = ' '
            itemail = ' '
        }
        if(data1['BusinessOwnerKeyUser'] !=undefined){
            owner = data1['BusinessOwnerKeyUser'][0]['Title']
            owneremail = data1['BusinessOwnerKeyUser'][0]['EMail']
            //console.log("here is the data-->", owner)
        }
        else {
            owner = ' '
            owneremail = ' '
        }
        // if(data1['BackupOwner'][0]!=undefined){
        //     backup = data1['BackupOwner'][0]['Title']
        //     console.log("here is the data-->", backup)
        // }
        // else backup = ' '
        if(data1['BusinessProcess'] != null){
            process = data1['BusinessProcess']
        }
        else process = ' '
        if(data1['Vendor'] != null){
            Vendor =  data1['Vendor']
        }
        else Vendor = ' '

        let itemail_link;
        let owneremail_link;

        if(itemail != ' ' && owneremail != ' '){
            itemail_link =  contact+ " [[email](mailto:"+itemail+")" + " or [chat](https://teams.microsoft.com/l/chat/0/0?users="+itemail+")]"
            owneremail_link = owner+ " [[email](mailto:"+owneremail+")" + " or [chat](https://teams.microsoft.com/l/chat/0/0?users="+owneremail+")]"
        }else{
            itemail_link = contact
            owneremail_link = owner
        }
            
       
        /*let itemail_link = itemail.link("https://www.google.com");
        let owneremail_link = owneremail.link("https://www.google.com");
        if(itemail==' '){
            itcontactvalue = contact
        }else itcontactvalue = contact + " (" + itemail_link + ")"

        if(owneremail==' '){
            ownervalue = owner
        }else ownervalue = owner + " (" + owneremail_link + ")"*/

        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `Please find below some important information related to **${data}**: \n\n`+
                        "**IT Contact** :" + itemail_link+ "\n\n" +
                        "**Business Owner** :" + owneremail_link+ "\n\n" +
                        // `**Backup Owner** : ${backup}\n\n` +
                        `**Business Process** : ${process}\n\n`+
                        `**Vendor** : ${Vendor} \n\n`,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard

    }

    private static getITStorageInfo(stepContext, value: any) {
        console.log("data-->",value)
        //console.log("here is the data-->", value.data)
       // console.log("here is the data1-->",value.data1['ITContact'])
        let data = value.data
        let data1 = value.data1
        let contact, owner, Vendor, process, backup, ITcontactmail, Businessownermail
        let itcontactvalue, ownervalue
        
        if(data1[0].ITContact !="null"){
            contact = data1[0].ITContact
            //console.log("here is the data-->", contact)
        }
        else contact = ' '
        if(data1[0].Businessowner !="null"){
            owner = data1[0].Businessowner
            //console.log("here is the data-->", owner)
        }
        else owner = ' '
        if(data1[0].Businessprocess != "null"){
            process = data1[0].Businessprocess
        }
        else process = ' '
        if(data1[0].Vendor != "null"){
            Vendor =  data1[0].Vendor
        }
        else Vendor = ' '

        if(data1[0].ITContactEmail != "null"){
            ITcontactmail =  data1[0].ITContactEmail
        }
        else ITcontactmail = ' '

        if(data1[0].BusinessownerEmail != "null"){
            Businessownermail =  data1[0].BusinessownerEmail
        }
        else Businessownermail = ' '

        /*let itemail_link = ITcontactmail.link("https://www.google.com");
        let owneremail_link = Businessownermail.link("https://www.google.com");

        if(ITcontactmail==' '){
            itcontactvalue = contact
        }else itcontactvalue = contact + " (" + itemail_link + ")"

        if(Businessownermail==' '){
            ownervalue = owner
        }else ownervalue = owner + " (" + owneremail_link + ")"*/

        let itemail_link;
        let owneremail_link;
        
        if(ITcontactmail != ' ' && Businessownermail != ' '){
            itemail_link =  contact+ " [[email](mailto:"+ITcontactmail+")" + " or [chat](https://teams.microsoft.com/l/chat/0/0?users="+ITcontactmail+")]"
            owneremail_link = owner+ " [[email](mailto:"+Businessownermail+")" + " or [chat](https://teams.microsoft.com/l/chat/0/0?users="+Businessownermail+")]"
        }else{
            itemail_link = contact
            owneremail_link = owner
        }
       
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `Please find below some important information related to **${data}**: \n\n`+
                        "**IT Contact** :" +itemail_link+ "\n\n" +
                        "**Business Owner** :" +owneremail_link+ "\n\n" +
                        // `**Backup Owner** : ${backup}\n\n` +
                        `**Business Process** : ${process}\n\n`+
                        `**Vendor** : ${Vendor} \n\n`,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard

    }

    private static getItInfo(stepContext, data) {
       
        let data1
        if(data==true){
            data1 ='Yes'
        }
        else if(data==false){
            data1 = 'No'
        }
        else {
            data1 = data
        }
        
        let adaptiveCard = {
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "type": "AdaptiveCard",
            "version": "1.0",
            "body": [
                {
                    "type": "TextBlock",
                    "text":
                        `Please find below the answer to your requested query:\n\n  **${data1}** `,

                    "wrap": true

                }
            ]
        }
        return adaptiveCard
        //this.resolveTktState(parseInt(dataSnow.state)),

    }
}



