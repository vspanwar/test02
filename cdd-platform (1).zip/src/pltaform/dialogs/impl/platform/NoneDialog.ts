import { BaseComponentDialog } from '../../BaseComponentDialog';
import { PromptValidatorContext, DateTimeResolution, DateTimePrompt, WaterfallDialog, WaterfallStepContext, DialogTurnResult, TextPrompt , ChoicePrompt,ChoiceFactory} from 'botbuilder-dialogs';
import { InputHints, MessageFactory } from 'botbuilder';
import { TimexProperty } from '@microsoft/recognizers-text-data-types-timex-expression';

import {PlatFormCarType} from './PlatformCards'
import { CardHandler } from '../CardHandler';

export class NoneDialog extends BaseComponentDialog {
    
    public getNewInstance(bot:any) {
        const instance = new NoneDialog(this.name);
        instance.bot = bot;
        return instance;
    }

    private static async dateTimePromptValidator(promptContext: PromptValidatorContext<DateTimeResolution>): Promise<boolean> {
        if (promptContext.recognized.succeeded) {
            // This value will be a TIMEX. And we are only interested in a Date so grab the first result and drop the Time part.
            // TIMEX is a format that represents DateTime expressions that include some ambiguity. e.g. missing a Year.
            const timex = promptContext.recognized.value[0].timex.split('T')[0];

            // If this is a definite Date including year, month and day we are good otherwise reprompt.
            // A better solution might be to let the user know what part is actually missing.
            // return new TimexProperty(timex).types.has('definite');
            return true;
        }
        return false;
    }

    constructor(id: string) {
        super(id || 'None');
        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            //.addDialog(new PlatformCreateTicketDialog(PlatFormCarType.PLATFORM_CREATE_TICKET_DIALOG))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.initialStep.bind(this),
                this.actualStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    private async initialStep(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {

        let msg= "Apologies, I couldn't understand, I can help you with following options:";
        let options = ['Report an issue','Raise Service Request','View Status of incident','View Status of SR','Update Incident','Connect Live Agent', 'Exit']

        return CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,msg,options)
      
        }
    
        private async actualStep(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {
            const optIdx = stepContext.result.index;
            const CreateTicketDetails={}
            switch(optIdx) {
                case 0:

                        return await stepContext.beginDialog('platform.incident.create');   
                                
                case 1:                    
                        return await stepContext.beginDialog('platform.sr.create');

                case 2:
                        return await stepContext.beginDialog('platform.ticket.status');
                       
                case 3:
                        return await stepContext.replaceDialog('platform.sr.status');

                case 4:
                        return await stepContext.replaceDialog('platform.ticket.status');
                       
                case 5:
                        return await stepContext.replaceDialog('platform.connecttoagent');
                
                case 6:
                        await stepContext.context.sendActivity('Thank you for contacting IVA. Have a nice day')
                        return await stepContext.endDialog();
            }
            return await stepContext.next();
        }



    private async finalStep(stepContext: WaterfallStepContext): Promise<DialogTurnResult> {
        // const timex = stepContext.result[0].timex;
        // await stepContext.endDialog(timex);
        return await stepContext.endDialog();
   }

}

//sure,i will help you with the status.Would you like to check the status for:incident service request