import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from '../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Datastore } from '../Datastore';
import { DialogUtils } from '../DialogUtils';
import { NLP } from '../../../../common/enums/PlatformEnums';
import { SharepointSearch } from '../../../service/SharepointSearch';



export class hrgreetings extends BaseComponentDialog {
   
    public getNewInstance(bot: any) {
        const instance = new hrgreetings(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'HrGreeting');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))


            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.showGreeting.bind(this),
                this.secondStep.bind(this)

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async showGreeting(stepContext){

        let username = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
        stepContext.options.userName =username 
        
        if(stepContext.options.second_attempt){
            console.log("**second attempt")
        }
        else{
            console.log("msg in greetings",stepContext.context.activity.text)
        
                let payload1 = await Datastore.getInstance().gethrPayload(process.env.domainCode);
                payload1.User_conversation_id = stepContext.context.activity.conversation.id,
                payload1.User_name = username
                payload1.User_email = await DialogUtils.getInstance().getemail(stepContext.context)
                LoggingUtil.log.info("Payload for db:" + JSON.stringify(payload1))
                await Datastore.getInstance().loghrdatatodb(payload1)
            
            let session_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
            console.log("session id-->", session_id)
            stepContext.options.session_id = session_id
            await Datastore.getInstance().logTranscriptHR(stepContext.context.activity.text,session_id,username)       

            let welcome_text = "Hi" +username+"! This is your Duracell Virtual assistant."
            await stepContext.context.sendActivity(welcome_text);
            await Datastore.getInstance().logTranscriptHR(welcome_text,session_id,"BOT")
        }
            
        let msg = "I can help with the topics listed below just click on a button to get started."
        await stepContext.context.sendActivity(msg);
        await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")
        

        //let msg = "Please select from the below options:"
        //await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")
        let options = ["IT Application" , "Sharepoint topic search"]
        return await CardHandler.textPromptWithChoice(stepContext,PlatFormCarType.TEXT_PROMPT," ",options)
    }
    
    async secondStep(stepContext){

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value hrgreeting secondstep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */
        let res = stepContext.context.activity.text

        if(res == 'IT Application'||res == '1'){
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.userName)
            return await stepContext.replaceDialog("ItApplication",{session_id: stepContext.options.session_id});
        }
        else if(res == 'Sharepoint topic search'||res == '2'){

            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.userName)

            //////////////////////////////***************VALIDATE USER AD GROUP MEMBERSHIP*******************************//////////////

            let user_mail = await DialogUtils.getInstance().getemail(stepContext.context)
            //let user_mail = "flores.jd.1@duracell.com"
            let userid = await SharepointSearch.getInstance().GetUserID(user_mail)
            console.log("AD USER ID - ",userid);

            let group = ["DURG-Location-APJ","DURG-Location-LatinAmerica","DURG-Location-NorthAmerica","DURG-Location-EIMEA","US-Users"]
            let apjid,laid,naid,eaid,usid;
            apjid = await SharepointSearch.getInstance().GetGroupID(group[0]);
            laid = await SharepointSearch.getInstance().GetGroupID(group[1]);
            naid = await SharepointSearch.getInstance().GetGroupID(group[2]);
            eaid = await SharepointSearch.getInstance().GetGroupID(group[3]);
            usid = await SharepointSearch.getInstance().GetGroupID(group[4]);
            console.log("APJ GROUP ID - ",apjid);
            console.log("LA GROUP ID - ",laid);
            console.log("NA GROUP ID - ",naid);
            console.log("EIMEA GROUP ID - ",eaid);
            console.log("US GROUP ID - ",usid);

            let apj_members=[],la_members=[],na_members=[],ea_members=[];
            let list_length;
            let apj_list = await SharepointSearch.getInstance().GetGroupMembers(apjid);
            list_length = apj_list.length;
            apj_members.push(apjid);
            for(var i=0;i<list_length;i++){
                apj_members.push(apj_list[i].id);
            }
            let la_list = await SharepointSearch.getInstance().GetGroupMembers(laid);
            list_length = la_list.length;
            la_members.push(laid)
            for(var i=0;i<list_length;i++){
                la_members.push(la_list[i].id);
            }
            let na_list = await SharepointSearch.getInstance().GetGroupMembers(naid);
            list_length = na_list.length;
            na_members.push(naid)
            for(var i=0;i<list_length;i++){
                na_members.push(na_list[i].id);
            }
            let ea_list = await SharepointSearch.getInstance().GetGroupMembers(eaid);
            list_length = ea_list.length;
            ea_members.push(eaid)
            for(var i=0;i<list_length;i++){
                ea_members.push(ea_list[i].id);
            }

            let user_group = await SharepointSearch.getInstance().GetUserGroupList(userid);
            let user_gl = user_group.length
            let user_grouplist= []
            for(var i=0;i<user_gl;i++){
                user_grouplist.push(user_group[i].id)
            }

            console.log("APJ Members - ",apj_members);
            console.log("LA Members - ",la_members);
            console.log("NA Members - ",na_members);
            console.log("EIMEA Members - ",ea_members);
            console.log("US Members - ",usid);
            console.log("User group list - ",user_grouplist);

            let apj_flag,la_flag,na_flag,ea_flag;
            let apj_len,la_len,na_len,ea_len,usergroup_len;
            apj_len=apj_members.length;
            la_len=la_members.length;
            na_len=na_members.length;
            ea_len=ea_members.length;
            usergroup_len=user_grouplist.length;

            for(var i = 0;i < apj_len;i++){
                for(var j=0;j<usergroup_len;j++){
                    if(user_grouplist[j]==apj_members[i]){
                        apj_flag=true;
                        break;
                    }else apj_flag = false;
                }
                if(apj_flag==true || apj_flag===true){
                    break;
                }
            }

            for(var i = 0;i < la_len;i++){
                for(var j=0;j<usergroup_len;j++){
                    if(user_grouplist[j]==la_members[i]){
                        la_flag=true;
                        break;
                    }else la_flag=false;
                }
                if(la_flag==true || la_flag===true){
                    break;
                }
            }

            for(var i = 0;i < na_len;i++){
                for(var j=0;j<usergroup_len;j++){
                    if(user_grouplist[j]==na_members[i]){
                        na_flag=true;
                        break;
                    }else na_flag=false;
                }
                if(na_flag==true || na_flag===true){
                    break;
                }
            }

            for(var i = 0;i < ea_len;i++){
                for(var j=0;j<usergroup_len;j++){
                    if(user_grouplist[j]==ea_members[i]){
                        ea_flag=true;
                        break;
                    }else ea_flag=false;
                }
                if(ea_flag==true || ea_flag===true){
                    break;
                }
            }

            for(var i=0;i<usergroup_len;i++){
                if(user_grouplist[i]==usid){
                    na_flag=true;
                    break;
                }
            }

            let excludedfolder = []
            if(apj_flag==false){
                excludedfolder.push("asia")
            }
            if(la_flag==false){
                excludedfolder.push("latin america")
            }
            if(na_flag==false){
                excludedfolder.push("north america")
            }
            if(ea_flag==false){
                excludedfolder.push("europe")
                excludedfolder.push("africa")
            }

            console.log("Folders to be excluded - ",excludedfolder)
            stepContext.options.excludedfolder = excludedfolder

             //////////////////////////////***************VALIDATE USER AD GROUP MEMBERSHIP*******************************//////////////

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder});
        }
        else{
        this.nlpService.type = NLP.LUIS
        let intentResult = await this.nlpService.onRecognize(stepContext.context)

        if (intentResult.topIntent == "HR.Greeting" && intentResult.topScore > 0.80) {
            return await stepContext.replaceDialog("HrGreeting");  
            //handle timeout issue       
        }
        else if (intentResult.topIntent == "HR.IsThere" && intentResult.topScore > 0.84) {
            return await stepContext.replaceDialog('HR_IsThere',{session_id: stepContext.options.session_id,username:stepContext.options.username})
        }
        
    }      

    }
 
   
}