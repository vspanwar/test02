export class DataAzure {
    public Data: any [];
}
