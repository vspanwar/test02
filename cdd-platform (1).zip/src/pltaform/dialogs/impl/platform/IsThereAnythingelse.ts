import { ItsmRequestType } from './../../../../common/enums/PlatformEnums';
import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
import { CddCardFactory } from '../CddCardFactory';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import {} from '../CardHandler';
import { DialogUtils } from '../DialogUtils';
import { MessageUtils } from '../MessageUtils';
import { TranslatorService } from '../../../service/TranslatorService';
import { UsecaseData } from '../../../model/UsecaseData';
import { AdminService } from '../../../service/AdminService';
import {FeedbackDialog} from './FeedbackDialog';
import {FeedbackDetails} from './FeedbackDetails';
import { NLP } from '../../../../common/enums/PlatformEnums';


export class IsThereAnythingElse extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new IsThereAnythingElse(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'platform.isthere.anything');
        let feedbackDialog = new FeedbackDialog('feedbackDialog');;
    
        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(feedbackDialog)
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.startStep.bind(this),
                this.secondStep.bind(this),
                this.thirdStep.bind(this)
    
            ]));
    
        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }
    
    
    async startStep(stepContext) {
        
       // let userName=await DialogUtils.getInstance().getUserName(stepContext.context.activity)
       // let useCasePayload= await UsecaseData.getInstance().setData(userName, "IsThereAnythingElse", stepContext.context.activity.conversation.id)
        // console.log("this is usecasePayload" + JSON.stringify(useCasePayload))
        // let result= AdminService.getInstance().logUseCaseData(useCasePayload)
        
        LoggingUtil.log.debug("Use case name: " + stepContext.options.useCase)
        console.log(stepContext.options.language+"IVA1 BOT ")
        let messageText
        if (stepContext.options.language){
            stepContext.context.activity.locale=stepContext.options.language
        }
         messageText = MessageUtils.getInstance().getMessage("IsThereAnythingElse_askHelp",stepContext.context.activity.locale);
        let options = [MessageUtils.getInstance().getMessage("Yes",stepContext.context.activity.locale),MessageUtils.getInstance().getMessage("No",stepContext.context.activity.locale)];
    
        return await CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,messageText,options)
    
    
    }
    
    async secondStep(stepContext){
        LoggingUtil.log.debug("answer + " + JSON.stringify(stepContext.result))
    
        if(stepContext.result.index==1){
            let feedbackDetails = new FeedbackDetails();
            return await stepContext.replaceDialog('feedbackDialog', {language:stepContext.options.language});
        }
        else{
            let msg = MessageUtils.getInstance().getMessage("IsThereAnythingElse_giveOptions",stepContext.options.language)
            let options=[MessageUtils.getInstance().getMessage("Report_an_issue",stepContext.options.language), 
            MessageUtils.getInstance().getMessage("View_status_incident_request",stepContext.options.language),MessageUtils.getInstance().getMessage("SRStatus",stepContext.options.language),MessageUtils.getInstance().getMessage("Raise_service_request",stepContext.options.language), MessageUtils.getInstance().getMessage("connect_live_agent",stepContext.options.language),MessageUtils.getInstance().getMessage("Exit",stepContext.options.language)]
            //let options=[MessageUtils.getInstance().getMessage("Report_an_issue",stepContext.options.language),  MessageUtils.getInstance().getMessage("View_status_incident_request",stepContext.options.language), MessageUtils.getInstance().getMessage("connect_live_agent",stepContext.options.language),MessageUtils.getInstance().getMessage("Exit",stepContext.options.language)]
            
            return await CardHandler.textPromptWithChoice(stepContext,PlatFormCarType.TEXT_PROMPT,msg,options);       
               
        }
    }

    
    
    async thirdStep(stepContext){
        if(stepContext.result==MessageUtils.getInstance().getMessage("Report_an_issue",stepContext.options.language))
            {
                return await stepContext.replaceDialog('platform.incident.create',{language:stepContext.options.language})
            }
            else if(stepContext.result==MessageUtils.getInstance().getMessage("View_status_incident_request",stepContext.options.language))
            {
                return await stepContext.replaceDialog('platform.ticket.status',{language:stepContext.options.language})
            }
            else if(stepContext.result == MessageUtils.getInstance().getMessage("SRStatus",stepContext.options.language))
            {
                return await stepContext.replaceDialog('platform.sr.status',{language:stepContext.options.language})
            }
            else if(stepContext.result == MessageUtils.getInstance().getMessage("Raise_service_request",stepContext.options.language))
            {
                return await stepContext.replaceDialog('platform.sr.create',{language:stepContext.options.language})
            }
            
            else if(stepContext.result ==  MessageUtils.getInstance().getMessage("connect_live_agent",stepContext.options.language))
            {
                return await stepContext.replaceDialog('platform.connecttoagent',{language:stepContext.options.language})
            }
            else if(stepContext.result == MessageUtils.getInstance().getMessage("Exit",stepContext.options.language))
            {
                return await stepContext.replaceDialog('feedbackDialog',{language:stepContext.options.language})
            }
            else {
                this.nlpService.type=NLP.LUIS
                //console.log(this.nlpService,"nlpservice")
                //**THIS IS ADDED JUST TO DETECT LANGUAGE */
                let language_code=await TranslatorService.getInstance().detect(stepContext.context.activity.text)
                console.log('languageDETECT',language_code[0].language)

                
                if (language_code[0].language=='hu'){
                    stepContext.options.language='hu'
                }
                if(language_code[0].language=='tr'){
                    stepContext.options.language='tr'
                }
                let converted_text =await TranslatorService.getInstance().translate(stepContext.context.activity.text, 'en','')
                LoggingUtil.log.debug("Translated response " + JSON.stringify(converted_text))
                stepContext.context.activity['text'] = converted_text
                let result = await this.nlpService.onRecognize(stepContext.context);
                
                console.log("result luis",result,result.topIntent)
                if(result.entities.cognitive_sentiment_analysis){
                    let ent=result.entities['cognitive_sentiment_analysis']
                    console.log(ent+"checkingentities")
                    
                    if(ent=="Expedite"){
                        console.log("entitiesres",ent)
                        await stepContext.context.sendActivity("Surely i will help to connect with our solution expert.")
                        return await stepContext.replaceDialog("sentiment",{language:stepContext.options.language})

                    }
                    else{
                        console.log("entitiesres",ent)
                        await stepContext.context.sendActivity("Apologies for the inconvenience faced. We strive to serve you better. Request to please stay connected, I will help you to connect with our Solution Expert")
                        return await stepContext.replaceDialog("sentiment",{language:stepContext.options.language})
                        
                    }

                }
                console.log("result luis",result,result.topIntent)
                return await stepContext.replaceDialog(result.topIntent,{language:stepContext.options.language})
            }
    }
    }