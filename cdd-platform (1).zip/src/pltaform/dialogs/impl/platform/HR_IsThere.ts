import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Datastore } from '../Datastore';
import { NLP } from '../../../../common/enums/PlatformEnums';




export class HR_IsThere extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new HR_IsThere(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'HR_IsThere');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))


            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                // this.thirdStep.bind(this),
                // this.fourthStep.bind(this),
                this.firstStep.bind(this),
                this.secondStep.bind(this),
                this.fifthStep.bind(this),

            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

 
    // async thirdStep(stepContext){
    //     let msg = 'Is there anything else I can help you with?'

    //     let options = ['Yes','No']
    //     return CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,msg,options)

    // }
    // async fourthStep(stepContext){

    //     if(stepContext.result.index == "0")
    //     {
    //         return await stepContext.replaceDialog('HR_Greeting',{skip_create_session:false})
    //      }
    //     else {
    //         return await stepContext.next();
    //     //    // await stepContext.context.sendActivity('Thank you for contacting us!!!')
    //      }

    // }
    async firstStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        //if(stepContext.context.activity.channelId == 'msteams'||stepContext.context.activity.channelId == 'emulator'){
        if(stepContext.context.activity.channelId == 'msteams'){
            let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
            let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
            console.log("timeout value feedback firststep - ",timeoutvalue)
            if(timeoutvalue=="Completed-Timeout"){
                return await stepContext.replaceDialog("HrGreeting");
            }
        }

        //*******************************************TIMEOUT CHANGE************************************************* */

        console.log("session id in feedback",stepContext.options.session_id)
        
            let msg = 'Your feedback is important to us. Please take this short survey. How would you rate the service you just received from Duracell Bot?';
            await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")
            let options = ['Extremely Satisfied ★★★★★','Satisfied ★★★★','Neutral ★★★','Dissatisfied ★★','Extremely Dissatisfied ★'];
            //return CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,msg,options)
            return await CardHandler.textPromptWithChoice(stepContext,PlatFormCarType.TEXT_PROMPT,msg,options)
    }

    async secondStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        //if(stepContext.context.activity.channelId == 'msteams'||stepContext.context.activity.channelId == 'emulator'){
        if(stepContext.context.activity.channelId == 'msteams'){
            let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
            let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
            console.log("timeout value feedback secondstep - ",timeoutvalue)
            if(timeoutvalue=="Completed-Timeout"){
                return await stepContext.replaceDialog("HrGreeting");
            }
        }

        //*******************************************TIMEOUT CHANGE************************************************* */
    
        let feedback = stepContext.context.activity.text
        console.log("text in feedback",feedback)
        
        if(feedback.includes('Extremely Satisfied')||feedback.includes('Satisfied')||feedback.includes('Neutral')||feedback == '0' || feedback == '1' || feedback == '2')
        {   
            await Datastore.getInstance().logTranscriptHR(feedback,stepContext.options.session_id,stepContext.options.username)
            await Datastore.getInstance().UpdatedbHR('feedback_value',feedback ,stepContext.options.session_id)
            await Datastore.getInstance().updateStatusHR(stepContext.context.activity, 'Completed')
            
            let msg = 'Thanks for sharing your valuable feedback.\n\n'+'Thank you for chatting with me. Your session has ended. Have a great day!'
            await stepContext.context.sendActivity(msg);
            await Datastore.getInstance().logTranscriptHR('Thanks for sharing your valuable feedback. Thank you for chatting with me. Your session has ended. Have a great day!',stepContext.options.session_id,"BOT")
            await stepContext.cancelAllDialogs();
            return await stepContext.endDialog()
        }
        else if(feedback.includes('Dissatisfied')||feedback.includes('Extremely Dissatisfied')||feedback == '3' || feedback == '4'){
            await Datastore.getInstance().logTranscriptHR(feedback,stepContext.options.session_id,stepContext.options.username)
            await Datastore.getInstance().UpdatedbHR('feedback_value',feedback ,stepContext.options.session_id)
            await Datastore.getInstance().updateStatusHR(stepContext.context.activity, 'Completed')
            
            const messageText = `My sincerest apologies. Please provide us the details of what went wrong during our conversation.`;
            await Datastore.getInstance().logTranscriptHR(messageText,stepContext.options.session_id,"BOT")
            const msg = MessageFactory.text(messageText, messageText, InputHints.ExpectingInput);
            return await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, { prompt: msg });
        }
        else{
            console.log("feedback else", this.nlpService)
            this.nlpService.type = NLP.LUIS
            let intentResult = await this.nlpService.onRecognize(stepContext.context)
            
            if (intentResult.topIntent == "HR.Greeting" && intentResult.topScore > 0.80) {
                return await stepContext.replaceDialog("HrGreeting",{session_id:stepContext.options.session_id  });  
                //handle timeout issue
            }
            else if (intentResult.topIntent == "HR.IsThere" && intentResult.topScore > 0.84) {
                return await stepContext.replaceDialog('HR_IsThere',{feedback: true,session_id: stepContext.options.session_id,username:stepContext.options.username})
            }
        }
    }

    async fifthStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        //if(stepContext.context.activity.channelId == 'msteams'||stepContext.context.activity.channelId == 'emulator'){
        if(stepContext.context.activity.channelId == 'msteams'){
            let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
            let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
            console.log("timeout value feedback fifthstep - ",timeoutvalue)
            if(timeoutvalue=="Completed-Timeout"){
                return await stepContext.replaceDialog("HrGreeting");
            }
        }

        //*******************************************TIMEOUT CHANGE************************************************* */
        await Datastore.getInstance().logTranscriptHR(stepContext.result,stepContext.options.session_id,stepContext.options.username)
        await Datastore.getInstance().UpdatedbHR('feedback_comments',stepContext.result ,stepContext.options.session_id)
        
        let msg = 'Thanks for sharing your valuable feedback.\n\n'+'Thank you for chatting with me. Your session has ended. Have a great day!'
        await Datastore.getInstance().logTranscriptHR('Thanks for sharing your valuable feedback. Thank you for chatting with me. Your session has ended. Have a great day!',stepContext.options.session_id,"BOT")
        await Datastore.getInstance().updateStatusHR(stepContext.context.activity, 'Completed')
        await stepContext.context.sendActivity(msg);
        await stepContext.cancelAllDialogs();
        return await stepContext.endDialog()
    }

    
}

