import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog, Dialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { Datastore } from '../Datastore';
import { NLP } from '../../../../common/enums/PlatformEnums';
import { DialogUtils } from '../DialogUtils';
import { SharepointSearch } from '../../../service/SharepointSearch';
import { servicenow } from '../../../service/servicenow';
const tableStore = require('azure-storage');
const tableName = "ITsharepoint";

export class ItApplication extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new ItApplication(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'ItApplication');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.queryStep.bind(this),
                this.firstStep.bind(this),
                this.mailsend.bind(this),
                //this.createticket.bind(this),
                //this.lastStep.bind(this),
            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async queryStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value itappln querystep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */

        let username = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
        stepContext.options.username = username
        console.log("session is in IT App",stepContext.options.session_id, stepContext.options.username)
        stepContext.options.userinput='yes';
        console.log("stepContext.options.userinput in querystep - ",stepContext.options.userinput);
        
        if(stepContext.options.retry) {
            let msg1 = "Please type an another application name to search.\n\nIf you'd like to go back to the main menu, click the below button."
             let options = ['Go Back']
             await Datastore.getInstance().logTranscriptHR("Please type an another application name to search. If you would like to go back to the main menu, click the below button.",stepContext.options.session_id,"BOT")
             await CardHandler.textPromptWithChoice(stepContext,PlatFormCarType.TEXT_PROMPT,msg1,options)
             return Dialog.EndOfTurn
        }
        else{
            let msg = "I am able to lookup information about Duracell applications."
            await stepContext.context.sendActivity(msg);
            await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")

            let msg1 = 'Please type an application name to search.'
            await Datastore.getInstance().logTranscriptHR(msg1,stepContext.options.session_id,"BOT")
            await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, { prompt: msg1 });
            return Dialog.EndOfTurn
        }    
    }

    async firstStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value itappln firststep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */
        let res = stepContext.context.activity.text
        stepContext.options.utterance = res
        console.log("stepContext.options.userinput in firststep - ",stepContext.options.userinput);
        
        if(res == 'Go Back'||res == '1'){
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            return await stepContext.replaceDialog("HrGreeting",{second_attempt: true, session_id:stepContext.options.session_id  });
        }
       
        //to extract the entity
        this.nlpService.type = NLP.LUIS
        let intentResult = await this.nlpService.onRecognize(stepContext.context)
        
        if (intentResult.topIntent == "HR.Greeting" && intentResult.topScore > 0.80) {
            return await stepContext.replaceDialog("HrGreeting");  
            //handle timeout issue
        }
        else if (intentResult.topIntent == "HR.IsThere" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            return await stepContext.replaceDialog('HR_IsThere',{session_id: stepContext.options.session_id,username:stepContext.options.username})
        }
        else{
            //console.log("instance name =======", intentResult.entities)
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            
            if(intentResult.entities['App_name'] != undefined){
                console.log('app name-->', intentResult.entities['App_name'][0][0])
                
            // if(intentResult.entities['Item'] != undefined){
                    //console.log('column value-->', intentResult.entities['Item'][0][0])
                    
                // if (intentResult.entities['Item'][0][0].includes('Contact') || intentResult.entities['Item'][0][0].includes('BusinessOwner') || intentResult.entities['Item'][0][0].includes('location')||intentResult.entities['Item'][0][0].includes('BackupOwner')) {
                //     try{
                //         let appresult = await SharepointSearch.getInstance().ExpandedItData(intentResult.entities['App_name'][0][0], intentResult.entities['Item'][0][0])
                //         console.log("here is the app result for expand---> "+ JSON.stringify(appresult))
                        
                //         if(appresult[0][`${intentResult.entities['Item'][0][0]}`] == null){
                //             await stepContext.context.sendActivity("It seems that there is no record available for the requested field.")
                //         }
                //         else{
                //         //const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.ItInfo.toString(), appresult['data']['value'][0][`${intentResult.entities['Item'][0][0]}`][0]['Title'])
                //         const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.ItInfo.toString(), appresult[0][`${intentResult.entities['Item'][0][0]}`][0]['Title'])
                //         await stepContext.context.sendActivity(cardmsgg)
                //         }
                //         await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);
                //         return await stepContext.replaceDialog('ItApplication', { skip_create_session: true , retry: true})
                        
                //     }
                //     catch(error){
                //        let msg = "Sorry the requested field does exist. Try again!"
                //        await stepContext.context.sendActivity(msg)
        
                //        await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);
                //        return await stepContext.replaceDialog('ItApplication', { skip_create_session: true , retry: true})
                    
                //     }
                    
                // }
                // else {
        
                //     try{
                //         let appresult = await SharepointSearch.getInstance().ItData(intentResult.entities['App_name'][0][0], intentResult.entities['Item'][0][0])
                //         console.log("here is the app result---> "+ JSON.stringify(appresult))
                //         if(appresult == null){
                //             await stepContext.context.sendActivity("It seems that there is no record available for the requested field.")
                //         }
                //         else{
                //         //const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.ItInfo.toString(), appresult['data']['value'][0][`${intentResult.entities['Item'][0][0]}`])
                //         const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.ItInfo.toString(), appresult)
                //         await stepContext.context.sendActivity(cardmsgg)
                //         }
                //         await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);
                //         return await stepContext.replaceDialog('ItApplication', { skip_create_session: true , retry: true})
                        
                //     }
                //     catch(error){
                //        let msg = "Sorry the requested field does exist. Try again!"
                //        await stepContext.context.sendActivity(msg)
        
                //        await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);
                //        return await stepContext.replaceDialog('ItApplication', { skip_create_session: true , retry: true})
                    
        
                //     }
        
                // }
                // } 
            // else{
                    //await stepContext.context.sendActivity("Sorry, I am unable to understand your query.")

                let ent_len = intentResult.entities['App_name'][0].length;
                if(ent_len == 1){
                    console.log("One application found");
                    let tableresult: any = await this.Table_Data(intentResult.entities['App_name'][0][0],stepContext);
                    //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                    //tableresult=stepContext.options.tabledata
                    console.log("tableresult - ",tableresult);
                    if(tableresult!="failed"){
                        if(tableresult.length==0){
                            let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][0])
                            if(appresult=="failed" || appresult==undefined || appresult===undefined){
                                console.log("No data found in sharepoint site");
                                return await stepContext.next();
                            }
                            //console.log("here is the result---> "+ JSON.stringify(appresult))
                            let option ={
                                data: intentResult.entities['App_name'][0][0],
                                data1: appresult
                            }
                            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                            await stepContext.context.sendActivity(cardmsgg)
                            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                        }else{
                            let option ={
                                data: intentResult.entities['App_name'][0][0],
                                data1: tableresult
                            }
                            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_StorageInfo.toString(),option )
                            await stepContext.context.sendActivity(cardmsgg)
                            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                        }
                    }else{
                        let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][0])
                        if(appresult=="failed" || appresult==undefined || appresult===undefined){
                            console.log("No data found in sharepoint site");
                            return await stepContext.next();
                        }
                        //console.log("here is the result---> "+ JSON.stringify(appresult))
                        let option ={
                            data: intentResult.entities['App_name'][0][0],
                            data1: appresult
                        }
                        const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                        await stepContext.context.sendActivity(cardmsgg)
                        await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                    }
                    /*let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][0])
                    //console.log("here is the result---> "+ JSON.stringify(appresult))
                    let option ={
                        data: intentResult.entities['App_name'][0][0],
                        data1: appresult
                    }
                    const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                    await stepContext.context.sendActivity(cardmsgg)
                    await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")*/
                }else{
                    try{
                        let msg1 = "More than one Application results found.\n Top 3 results for your query **\""+stepContext.options.utterance+"\"** are as follows:"
                        await Datastore.getInstance().logTranscriptHR(msg1,stepContext.options.session_id,"BOT")
                        await stepContext.context.sendActivity(msg1);
                        //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                    }catch(err){
                        console.log("err in catch - ",err)
                    }
                    if(ent_len<3){
                        console.log("entities length less than 3 greater than 1");
                        for(var i=0;i<ent_len;i++){
                            let tableresult: any = await this.Table_Data(intentResult.entities['App_name'][0][i],stepContext);
                            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                            //tableresult=stepContext.options.tabledata
                            console.log("tableresult - ",tableresult);
                            if(tableresult!="failed"){
                                if(tableresult.length==0){
                                    let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                                    if(appresult=="failed" || appresult==undefined || appresult===undefined){
                                        console.log("No data found in sharepoint site");
                                        //return await stepContext.next();
                                        let msgs = "Bot unable to retrieve info from sharepoint - "+intentResult.entities['App_name'][0][i];
                                        await Datastore.getInstance().logTranscriptHR(msgs,stepContext.options.session_id,"BOT")
                                        await stepContext.context.sendActivity(msgs);
                                        //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                                        
                                    }else{
                                        //console.log("here is the result---> "+ JSON.stringify(appresult))
                                        let option ={
                                            data: intentResult.entities['App_name'][0][i],
                                            data1: appresult
                                        }
                                        const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                                        await stepContext.context.sendActivity(cardmsgg)
                                        await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                    }
                                }else{
                                    let option ={
                                        data: intentResult.entities['App_name'][0][i],
                                        data1: tableresult
                                    }
                                    const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_StorageInfo.toString(),option )
                                    await stepContext.context.sendActivity(cardmsgg)
                                    await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                }
                            }else{
                                let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                                if(appresult=="failed" || appresult==undefined || appresult===undefined){
                                    console.log("No data found in sharepoint site");
                                    let msgs = "Bot unable to retrieve info from sharepoint - "+intentResult.entities['App_name'][0][i];
                                    await Datastore.getInstance().logTranscriptHR(msgs,stepContext.options.session_id,"BOT")
                                    await stepContext.context.sendActivity(msgs);
                                    //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                                    
                                }else{
                                    //console.log("here is the result---> "+ JSON.stringify(appresult))
                                    let option ={
                                        data: intentResult.entities['App_name'][0][i],
                                        data1: appresult
                                    }
                                    const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                                    await stepContext.context.sendActivity(cardmsgg)
                                    await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                }
                            }
                            /*let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                            //console.log("here is the result---> "+ JSON.stringify(appresult))
                            let option ={
                                data: intentResult.entities['App_name'][0][i],
                                data1: appresult
                            }
                            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                            await stepContext.context.sendActivity(cardmsgg)
                            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")*/
                        }
                    }else{
                        console.log("entities length greater than 3");
                        for(var i=0;i<3;i++){
                            let tableresult: any = await this.Table_Data(intentResult.entities['App_name'][0][i],stepContext);
                            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                            //tableresult=stepContext.options.tabledata
                            console.log("tableresult - ",tableresult);
                            if(tableresult!="failed"){
                                if(tableresult.length==0){
                                    let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                                    if(appresult=="failed" || appresult==undefined || appresult===undefined){
                                        console.log("No data found in sharepoint site");
                                        let msgs = "Bot unable to retrieve info from sharepoint - "+intentResult.entities['App_name'][0][i];
                                        await Datastore.getInstance().logTranscriptHR(msgs,stepContext.options.session_id,"BOT")
                                        await stepContext.context.sendActivity(msgs);
                                        //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                                        
                                    }else{
                                        //console.log("here is the result---> "+ JSON.stringify(appresult))
                                        let option ={
                                            data: intentResult.entities['App_name'][0][i],
                                            data1: appresult
                                        }
                                        const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                                        await stepContext.context.sendActivity(cardmsgg)
                                        await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                    }
                                }else{
                                    let option ={
                                        data: intentResult.entities['App_name'][0][i],
                                        data1: tableresult
                                    }
                                    const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_StorageInfo.toString(),option )
                                    await stepContext.context.sendActivity(cardmsgg)
                                    await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                }
                            }else{
                                let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                                if(appresult=="failed" || appresult==undefined || appresult===undefined){
                                    console.log("No data found in sharepoint site");
                                    let msgs = "Bot unable to retrieve info from sharepoint - "+intentResult.entities['App_name'][0][i];
                                    await Datastore.getInstance().logTranscriptHR(msgs,stepContext.options.session_id,"BOT")
                                    await stepContext.context.sendActivity(msgs);
                                    //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 2 }]);
                                    
                                }else{
                                    //console.log("here is the result---> "+ JSON.stringify(appresult))
                                    let option ={
                                        data: intentResult.entities['App_name'][0][i],
                                        data1: appresult
                                    }
                                    const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                                    await stepContext.context.sendActivity(cardmsgg)
                                    await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                                }
                            }
                            /*let appresult = await SharepointSearch.getInstance().Multiple_Data(intentResult.entities['App_name'][0][i])
                            //console.log("here is the result---> "+ JSON.stringify(appresult))
                            let option ={
                                data: intentResult.entities['App_name'][0][i],
                                data1: appresult
                            }
                            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.It_MultipleInfo.toString(),option )
                            await stepContext.context.sendActivity(cardmsgg)
                            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")*/
                        }
                    }
                }
                        //await stepContext.context.sendActivity("Click [here](https://duracell.sharepoint.com/sites/External/itsolutions/Lists/ApplicationPortfolioManagement/All%20Items%20View.aspx) to view further details on the **Application Portfolio Management** page.")
                        return await stepContext.replaceDialog('ItApplication', { session_id:stepContext.options.session_id, retry: true})               
                        
                    //}
            
            }else{
                console.log("No app found in luis")
                return await stepContext.next() 

            }

        }
        
    }
    async mailsend(stepContext){

        let msg = "Sorry I'm still learning! I am unable to find the requested application."
        // \n\nPlease click [here](https://duracell.sharepoint.com/sites/External/itsolutions/Lists/ApplicationPortfolioManagement/All%20Items%20View.aspx) to view the details on the **Application Portfolio Management** page."
        await stepContext.context.sendActivity(msg)
        await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")
        
        let mailsend;

        //********************************SEND EMAIL******************************************************* */
       try{
           let emailpayload = {                                                            //payload for history_hr db
               User_name: await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity),
               User_email: await DialogUtils.getInstance().getemail(stepContext.context),
               utterance: stepContext.options.utterance
           }
           if(stepContext.options.userinput=='yes'){
            let sendemail = await this.sendEmail(emailpayload);
           }
       }catch(err){
           console.log("error while sending email - ",err);
           mailsend='failed';
           stepContext.options.mailsend=mailsend;
       }
       //********************************SEND EMAIL******************************************************* */
       //return await stepContext.next() 
       return await stepContext.replaceDialog('ItApplication', { session_id:stepContext.options.session_id, retry: true}) 

    }

    async createticket(stepContext){
        
        let msg = "I am unable to find the requested application."
        // \n\nPlease click [here](https://duracell.sharepoint.com/sites/External/itsolutions/Lists/ApplicationPortfolioManagement/All%20Items%20View.aspx) to view the details on the **Application Portfolio Management** page."
        await stepContext.context.sendActivity(msg)
        await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")

        let payload1 = {                                                         //payload for incident
            // userName: userName ,
            short_description: "IT Application not found",
            description: "User Utterance - "+ stepContext.options.utterance,
            assignment_group: "APP-FLS-BotFramework",
            category: "Applications",
            subcategory: "Chatbot",
            contact_type: "chat",
            u_preferred_contact_method_caller: "chat",
            u_preferred_contact_method_impacted_user: "chat",
            impact: "2"
        }
        if(stepContext.options.userinput=='yes'){
            let ticket = await servicenow.getInstance().CreateTicket(payload1)
            LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
            let ticket_number = ticket.result.number
            stepContext.options.ticket_number = ticket_number
            console.log("data type of ticket number", typeof (ticket_number))
        }
        return await stepContext.next() 
    }

    async lastStep(stepContext) {
        
        let payload = {
            User_conversation_id: stepContext.context.activity.conversation.id,
            User_name: stepContext.options.username,
            User_email: await DialogUtils.getInstance().getemail(stepContext.context),
            utterance: stepContext.options.utterance,
            usecase_name: 'IT Application',
            INC_Number: stepContext.options.ticket_number
        }
        if(stepContext.options.mailsend=='failed'){
            payload.usecase_name = "Unrecognized-Intent IT Application failed to send mail"
        }else{
            payload.usecase_name = "Unrecognized-Intent IT Application"
        }

        if(stepContext.options.userinput== 'yes'){
            const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.HR_CARD.toString(), payload)
            console.log("cardmsg " + JSON.stringify(cardmsg))
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            await stepContext.context.sendActivity(cardmsg);

            await Datastore.getInstance().logutterancedatatodb(payload,stepContext.options.session_id)
           
        }
            
        return await stepContext.replaceDialog('ItApplication', { session_id:stepContext.options.session_id, retry: true}) 
    }

    public Table_Data(Application: any,stepcontext) {
        // try{
            const tableClient = tableStore.createTableService("cddduracellstorage", "GwmavWBLRoNWB1aT1ry2d6qU9LEf5O3va78MaqS3RoGFYc56v40HzWz3coZSoe7zTimfPnNYJVXF+AStFx5YWQ==");
            var query = new tableStore.TableQuery()
                        .where('Appln_name eq ?',Application);
            return new Promise((resolve, reject) => {tableClient.queryEntities(tableName, query, null, (error, result, resp) => {
                if (error) {
                    console.log(`Error Occured in table creation ${error.message}`);
                    stepcontext.options.tabledata="failed";
                    reject("failed");
                } else {
                    console.log("table response --- ",resp.body );
                    stepcontext.options.tabledata=resp.body.value;
                    resolve(resp.body.value);
                }})
            });
            
        // }catch(err){
        //     console.log("Not able to access storage account - ",err);
        //     stepcontext.options.tabledata="failed";
        //     return "failed";
        // }
    }

    public async sendEmail(payload: any) {
        let utterance = payload.utterance;
        let username = payload.User_name;
        let usermail = payload.User_email;
        var nodemailer = require('nodemailer');
        let res
        try {
            var moment = require('moment-timezone')
            let m = moment().tz('America/Toronto').format()
            let time = m.substring(0, 10) + " " + m.substring(11, 19)

            let transporter = await nodemailer.createTransport({
                host: "smtp.duracell.com",
                port: 25,
                secure: false, // true for 465, false for other ports

            });

            console.log("Message sent: inside nodemailer");

            await transporter.verify(function (error, success) {
                if (error) {
                    LoggingUtil.log.info("Error in verify")
                    console.log(error);
                } else {
                    res = true
                    console.log("Server is ready to take our messages");
                }
            });
            LoggingUtil.log.info("After transporter verify")

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: 'duracmbf@duracell.com', // sender address
                to: 'n.k@duracell.com',
                subject: "Unrecognized-Intent IT Application", // Subject line
                text: "test mail", // plain text body
                html: "<html> <head></head>" +
                "<body>" +
                "<p>" +
                "User queried for below utterance which is not able to recognized by the automated bot: </br>"+
                "</br>"+
                "<b>Username</b>: " + username + " </br>" +
                "<b>User Email</b>: " + usermail + " </br>" +
                "<b>User utterance</b>: " + utterance + " </br>" +
                "<b>Timestamp</b>: " + time + "</br>" +
                "</br>"+
                "</br>"+
                "This is an automated mail please do not reply.</br>" +
                "</p>" +
                "</body>" +
                "</html>",
            });
            LoggingUtil.log.info("After sendmail ")

        }
        catch (e) {
            LoggingUtil.log.error("Error in send mail=" + e)
        }

        return res

    }

}

