import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { TranslatorService } from '../../../service/TranslatorService';
import { DialogUtils } from '../DialogUtils';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { MSSQLConfig } from '../../../../common/repository/MSSQLConfig'
import { DC_PO_check } from './DC_PO_check';
import { Datastore } from '../Datastore';
var parseString = require('xml2js').parseString;
var moment = require('moment-timezone')



export class DC_Greetings extends BaseComponentDialog {
    public getNewInstance(bot: any) {
        const instance = new DC_Greetings(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'DC_Greeting');

        
        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new DC_PO_check(PlatFormCarType.po_cehck))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.InitialStep.bind(this),
                this.startStep.bind(this),
                this.secondStep.bind(this),
                this.finalstep.bind(this),


            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }
    async InitialStep(stepContext) {


        let username = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
        stepContext.options.username = username

        let lang_code
        let language = ''
        let payload = stepContext.options.payload

        if (stepContext.context.activity.channelId == 'emulator') {
            lang_code = 'en-US'
        }
        else {

            lang_code = payload.browser_language
            console.log("Language from browser:" + lang_code)

        }
        switch (lang_code) {
            case 'en-US': language = 'English'
                break
            case 'es': language = 'Spanish'
                break
            case 'nl': language = 'Dutch'
                break
            case 'pt': language = 'Portuguese'
                break
            case 'zh-CN': language = 'Chinese'
                break

            default:
                language = 'not supported'

        }
        stepContext.options.language = language
        stepContext.options.flag = false
        console.log("Language in greeting: " + stepContext.options.language)


        
        let time =await Datastore.getInstance().getTimestamp()

        if (language == 'not supported') {
            let msg = "Hi " + MessageFormattingHandler.getInstance().getBoldString(stepContext.context.activity, username) + " this is CDD bot, your digital assistant. I see that your language is not English."

            let tc = "Bot (" + time + ") :" + msg
            payload.transcript.push(tc)

            await stepContext.context.sendActivity(msg)

        }
        else {
            stepContext.options.flag = true
            // let email = await Find_email.getInstance().sendEmail(payload,"Testing from webclient")
            // LoggingUtil.log.info("Testing the mail ===>"+email)

            let welcome_text = "Hi " + MessageFormattingHandler.getInstance().getBoldString(stepContext.context.activity, username) + " this is your Duracell virtual assistant. I see that your language is " + language + ". Would you like to change the language?"
            let options = ['Yes, Change Language', 'No, Continue With Current Language']

            let tc = "Bot (" + time + ") :" + welcome_text
            payload.transcript.push(tc)

            return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, welcome_text, options);
        }


    }
    async startStep(stepContext) {
        if (stepContext.options.flag) {
            let payload = stepContext.options.payload

            
            let time = await Datastore.getInstance().getTimestamp()
            let tc = stepContext.options.username + " (" + time + ") :" + stepContext.result.value
            payload.transcript.push(tc)

            if (stepContext.result.index == 1) {
                console.log("tc in supported:" + payload.transcript)
                let languageCode = DialogUtils.getInstance().getLanguageCode(stepContext.options.language)
                let text = await TranslatorService.getInstance().translate(payload.Form_submite_text, languageCode)
                LoggingUtil.log.debug("Translated text :" + text + " " + payload.Form_submite_text + " " + languageCode)
                payload.Form_submite_text = text
                return await stepContext.replaceDialog('PO.check', { language: languageCode, payload: stepContext.options.payload })

            }
            else {

                return await stepContext.next()
            }
        }
        else {
            return await stepContext.next()

        }
    }

    //get the language from user if they wish to change the language
    async secondStep(stepContext) {
        console.log("Inside else in greet")

        let payload = stepContext.options.payload
      
        let time =await Datastore.getInstance().getTimestamp()

        let msg1 = " Please select the any one of the languages from the list below."
        let options1 = ['English', 'Dutch', 'Spanish', 'Portuguese', 'Chinese']

        let tc1 = "Bot (" + time + ") :" + msg1
        payload.transcript.push(tc1)
        return await CardHandler.sendPrompt(stepContext, PlatFormCarType.CHOICE_PROMPT, msg1, options1);

    }


    async finalstep(stepContext) {
        let payload = stepContext.options.payload

      
        let time = await Datastore.getInstance().getTimestamp()
        let tc1 = stepContext.options.username + " (" + time + ") :" + stepContext.result.value
        payload.transcript.push(tc1)
        console.log("tc in not supported:" + payload.transcript)

        let languageCode = DialogUtils.getInstance().getLanguageCode(stepContext.result.value)
        console.log("language code:" + languageCode)
        let text = await TranslatorService.getInstance().translate(payload.Form_submite_text, languageCode)
        LoggingUtil.log.debug("Translated text :" + text + " " + payload.Form_submite_text + " " + languageCode)
        payload.Form_submite_text = text
        return await stepContext.beginDialog('PO.check', { language: languageCode, payload: stepContext.options.payload })
    }

}

