import { PlatFormCarType } from './PlatformCards';
import { PlatformAdapter } from './../../../core/bot/PlatformAdapter';
import { LoggingUtil } from '../../../../common/utils/log4js';
const { InputHints, MessageFactory, CardFactory } = require('botbuilder');
import { ComponentDialog, ConfirmPrompt, TextPrompt, ChoicePrompt, NumberPrompt, ChoiceFactory, WaterfallDialog, Dialog } from 'botbuilder-dialogs';
import { CardHandler } from '../CardHandler';
import { BaseComponentDialog } from '../../BaseComponentDialog';
import { } from '../CardHandler';
import { DialogUtils } from '../DialogUtils';
import { DC_PO_check } from './DC_PO_check';
import { servicenow } from '../../../service/servicenow';
import { AzureSearchService } from '../../../service/AzureSearchService';
import { query } from 'express-validator/check';
import { searchService } from '../../../service/searchService';
import { SearchIndexClient } from '@azure/search-documents';
import { Datastore } from '../Datastore';
import { MessageFormattingHandler } from '../MessageFormatingHandler';
import { DataAzure } from './DataAzure';
import { NLP } from '../../../../common/enums/PlatformEnums';


var parseString = require('xml2js').parseString;
var moment = require('moment-timezone')



export class HR_Greetings extends BaseComponentDialog {

    public getNewInstance(bot: any) {
        const instance = new HR_Greetings(this.name);
        instance.bot = bot;
        return instance;
    }
    constructor(id: string) {
        super(id || 'HR_Greeting');


        this.addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new NumberPrompt(PlatFormCarType.NUMBER_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [

                this.startStep.bind(this),
                this.midStep.bind(this),
                //this.midStep1.bind(this),
                this.secondStep.bind(this),
                this.mailsend.bind(this),
                //this.createticket.bind(this),
                //this.thirdStep.bind(this)
            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }
    
    async startStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value hr_greeting startstep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */

        let username = await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity)
        stepContext.options.username = username
        console.log("session is in Policy details",stepContext.options.session_id,stepContext.options.username)
        console.log("excluded folder in Hr_greeting - ",stepContext.options.excludedfolder)
        stepContext.options.userinput = 'yes'
        console.log("stepContext.options.userinput in firststep- ",stepContext.options.userinput);
        console.log("###stepContext.options.topic in firststep- ",stepContext.options.topic);
        if(stepContext.options.topic=='yes'){
            await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, { prompt: "" });
            return Dialog.EndOfTurn
        }else{
            if(stepContext.options.retry) {
                let msg1 = "Please enter another policy or a topic to search or type exit to start over."
                await Datastore.getInstance().logTranscriptHR(msg1,stepContext.options.session_id,"BOT")
                await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, { prompt: msg1 });
                return Dialog.EndOfTurn
            }else{
                let msg = "I can search within documents stored on our main sharepoint site."
                await stepContext.context.sendActivity(msg);
                await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")

                let msg1 = 'Please enter a topic to start searching.'
                await Datastore.getInstance().logTranscriptHR(msg1,stepContext.options.session_id,"BOT")
                await stepContext.prompt(PlatFormCarType.TEXT_PROMPT, { prompt: msg1 });
                return Dialog.EndOfTurn
            }
        }

    }

    async midStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value hr_greeting midstep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */

        let res = stepContext.context.activity.text
        console.log("user query text**", res)
        stepContext.options.utterance = res

        if(res=='Sharepoint topic search'){
            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true,topic: "yes"});
        }

        this.nlpService.type = NLP.LUIS
        let intentResult = await this.nlpService.onRecognize(stepContext.context)
        console.log("intent result", intentResult)
        console.log("intentResult.topIntent", intentResult.topIntent)
        console.log("intentResult.topScore", intentResult.topScore)
        if (intentResult.topIntent == 'None' || intentResult.topScore < 0.8) {
            stepContext.options.skip2 = false
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            return await stepContext.next()
        }
        else if (intentResult.topIntent == "HR.Greeting" && intentResult.topScore > 0.80) {
            return await stepContext.replaceDialog("HrGreeting");  
            //handle timeout issue
        }
        else if (intentResult.topIntent == "Personal.information" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            let result = await searchService.getInstance().PersonalIntent(await DialogUtils.getInstance().getemail(stepContext.context))
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Personnel_Card.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        }
        else if (intentResult.topIntent == "Contact.information" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            let result = await searchService.getInstance().PersonalIntent(await DialogUtils.getInstance().getemail(stepContext.context))
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Contact_Crad.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        }
        else if (intentResult.topIntent == "Job.information" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            let result = await searchService.getInstance().PersonalIntent(await DialogUtils.getInstance().getemail(stepContext.context))
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Office_Card.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        }
        else if (intentResult.topIntent == "Manager.information" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            let result = await searchService.getInstance().ManagerIntent(await DialogUtils.getInstance().getemail(stepContext.context))
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.Manager_Card.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        }
        else if (intentResult.topIntent == "Onpremises.information" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            let result = await searchService.getInstance().PersonalIntent(await DialogUtils.getInstance().getemail(stepContext.context))
            const cardmsgg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.OnPremise_Crad.toString(), result.data)
            await stepContext.context.sendActivity(cardmsgg)
            await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
            //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);

            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        }
        else if (intentResult.topIntent == "HR.IsThere" && intentResult.topScore > 0.84) {
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            return await stepContext.replaceDialog('HR_IsThere',{feedback: true,session_id: stepContext.options.session_id,username:stepContext.options.username})
        }
        else {
            console.log("no intents matched");
            await Datastore.getInstance().logTranscriptHR(res,stepContext.options.session_id,stepContext.options.username)
            return await stepContext.next()
        }

    }

    async secondStep(stepContext) {

        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value hr_greeting secondstep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */
        console.log("stepContext.options.userinput in second step- ",stepContext.options.userinput);
        let resp
        let filteredresp
        try{
            let result1 = await AzureSearchService.getInstance().querying(stepContext.options.utterance);
            
            console.log("Query response length - ", result1.value.length)
            console.log("Utterance value", stepContext.options.utterance)
            resp = result1.value;
            console.log("Excluded folder - ", stepContext.options.excludedfolder)
            filteredresp = await AzureSearchService.getInstance().validateurl(resp,stepContext.options.excludedfolder);
            console.log("filtered array response length - ", filteredresp.length)
        }catch(err){
            console.log("##########ERROR####### in HR_greeting secondstep:" + err)
            let msg = "Error in server. Please try later"
            await stepContext.context.sendActivity(msg)

            let payload1 = {                                                         //payload for incident
                // userName: userName ,
                short_description: "Error in Azure cognitive search API",
                description: "User Utterance - "+ stepContext.options.utterance,
                assignment_group: "APP-FLS-BotFramework",
                category: "Applications",
                subcategory: "Chatbot",
                contact_type: "chat",
                u_preferred_contact_method_caller: "chat",
                u_preferred_contact_method_impacted_user: "chat",
                impact: "2"
            }
            let ticket = await servicenow.getInstance().CreateTicket(payload1)
            LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
            let ticket_number = ticket.result.number
            console.log("data type of ticket number", typeof (ticket_number))
            let payload = {                                                            //payload for history_hr db
                User_conversation_id: stepContext.context.activity.conversation.id,
                User_name: await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity),
                User_email: await DialogUtils.getInstance().getemail(stepContext.context),
                utterance: stepContext.options.utterance,
                usecase_name: 'Error in Azure cognitive search API',
                INC_Number: ticket_number
            }
            await Datastore.getInstance().logutterancedatatodb(payload,stepContext.options.session_id)

            return await stepContext.endDialog()
        }

        /////////////////////////////////////////////////////

        try{
            if (filteredresp.length < 1) {

                console.log("####### No results in first search api");
                let result2 = await AzureSearchService.getInstance().querying2(stepContext.options.utterance);
                    
                console.log("Query response length - ", result2.value.length)
                console.log("Utterance value", stepContext.options.utterance)
                resp = result2.value;
                console.log("Excluded folder - ", stepContext.options.excludedfolder)
                filteredresp = await AzureSearchService.getInstance().validateurl(resp,stepContext.options.excludedfolder);
                console.log("filtered array response length - ", filteredresp.length)
            }else{
                let score = filteredresp[0]["@search.rerankerScore"];
                console.log("#######SCORE - ",score);
                if(score<=0.8){
                    let result2 = await AzureSearchService.getInstance().querying2(stepContext.options.utterance);
                    
                    console.log("Query response length - ", result2.value.length)
                    console.log("Utterance value", stepContext.options.utterance)
                    resp = result2.value;
                    console.log("Excluded folder - ", stepContext.options.excludedfolder)
                    filteredresp = await AzureSearchService.getInstance().validateurl(resp,stepContext.options.excludedfolder);
                    console.log("filtered array response length - ", filteredresp.length)
                }else{
                    console.log("************ SCORE greater than 0.8 *****************")
                }
            }
        }catch(err){
            console.log("##########ERROR####### in HR_greeting secondstep:" + err)
            let msg = "Error in server. Please try later"
            await stepContext.context.sendActivity(msg)

            let payload1 = {                                                         //payload for incident
                // userName: userName ,
                short_description: "Error in Azure cognitive search API",
                description: "User Utterance - "+ stepContext.options.utterance,
                assignment_group: "APP-FLS-BotFramework",
                category: "Applications",
                subcategory: "Chatbot",
                contact_type: "chat",
                u_preferred_contact_method_caller: "chat",
                u_preferred_contact_method_impacted_user: "chat",
                impact: "2"
            }
            let ticket = await servicenow.getInstance().CreateTicket(payload1)
            LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
            let ticket_number = ticket.result.number
            console.log("data type of ticket number", typeof (ticket_number))
            let payload = {                                                            //payload for history_hr db
                User_conversation_id: stepContext.context.activity.conversation.id,
                User_name: await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity),
                User_email: await DialogUtils.getInstance().getemail(stepContext.context),
                utterance: stepContext.options.utterance,
                usecase_name: 'Error in Azure cognitive search API',
                INC_Number: ticket_number
            }
            await Datastore.getInstance().logutterancedatatodb(payload,stepContext.options.session_id)

            return await stepContext.endDialog()
        }
        ////////////////////////////////////////////////////


        stepContext.options.skip1 = false
        if (filteredresp.length < 1) {
            stepContext.options.skip1 = true
            return await stepContext.next()
        }

        let msg1 = "Top 3 results for your query **\""+stepContext.options.utterance+"\"** are as follows:"
        await Datastore.getInstance().logTranscriptHR(msg1,stepContext.options.session_id,"BOT")
        await stepContext.context.sendActivity(msg1);
        if(filteredresp.length<3){
            console.log("Query response length less than 3 ");
            for (let i = 0; i < filteredresp.length; i++) {
                const card = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.pdfCard2.toString(), filteredresp[i])
                await stepContext.context.sendActivity(card)
            }
        }else{
            console.log("Query response length greater than 3 ");
            for (let i = 0; i < 3; i++) {
                const card = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.pdfCard2.toString(), filteredresp[i])
                await stepContext.context.sendActivity(card)
            }
        }
        await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")

        //await stepContext.context.sendActivities([{ type: 'delay', value: 1000 * 3 }]);
        return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});
    }

    async mailsend(stepContext){
        
        //*******************************************TIMEOUT CHANGE************************************************* */
        let sess_id = await Datastore.getInstance().get_SessionID(stepContext.context.activity.conversation.id)
        let timeoutvalue =  await Datastore.getInstance().get_timeoutvalue(sess_id)
        console.log("timeout value hr_greeting thirdstep - ",timeoutvalue)
        if(timeoutvalue=="Completed-Timeout"){
            return await stepContext.replaceDialog("HrGreeting");
        }

        //*******************************************TIMEOUT CHANGE************************************************* */

        let msg = "Sorry I'm still learning! I am unable to find the requested query."
            // \n\nPlease click [here](https://duracell.sharepoint.com/sites/External/itsolutions/Lists/ApplicationPortfolioManagement/All%20Items%20View.aspx) to view the details on the **Application Portfolio Management** page."
        await stepContext.context.sendActivity(msg)
        await Datastore.getInstance().logTranscriptHR("Sorry I am still learning! I am unable to find the requested query.",stepContext.options.session_id,"BOT")
        let mailsend;
        if (stepContext.options.skip1 == true) {
            //********************************SEND EMAIL******************************************************* */
            try{
                let emailpayload = {                                                            //payload for history_hr db
                    User_name: await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity),
                    User_email: await DialogUtils.getInstance().getemail(stepContext.context),
                    utterance: stepContext.options.utterance
                }
                if(stepContext.options.userinput=='yes'){
                    let sendemail = await this.sendEmail(emailpayload);
                }
                //return await stepContext.next()
                return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});
            }catch(err){
                console.log("error while sending email - ",err);
                mailsend='failed';
                stepContext.options.mailsend=mailsend
                //return await stepContext.next()
                return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});
            }
            //********************************SEND EMAIL******************************************************* */
            
        }
    }

    async createticket(stepContext){

        let msg = "I am unable to find the requested query."
            // \n\nPlease click [here](https://duracell.sharepoint.com/sites/External/itsolutions/Lists/ApplicationPortfolioManagement/All%20Items%20View.aspx) to view the details on the **Application Portfolio Management** page."
        await stepContext.context.sendActivity(msg)
        await Datastore.getInstance().logTranscriptHR(msg,stepContext.options.session_id,"BOT")

        let payload1 = {                                                         //payload for incident
            // userName: userName ,
            short_description: stepContext.options.utterance,
            description: "Intent not found",
            assignment_group: "APP-FLS-BotFramework",
            category: "Applications",
            subcategory: "Chatbot",
            contact_type: "chat",
            u_preferred_contact_method_caller: "chat",
            u_preferred_contact_method_impacted_user: "chat",
            impact: "2"
        }
        if(stepContext.options.userinput=='yes'){
            let ticket = await servicenow.getInstance().CreateTicket(payload1)
            LoggingUtil.log.info("ticket number:" + JSON.stringify(ticket))
            let ticket_number = ticket.result.number
            console.log("data type of ticket number", typeof (ticket_number))
            stepContext.options.ticket_number = ticket_number
        }
        return await stepContext.next()
    }

    async thirdStep(stepContext) {
  
        let payload = {                                                            //payload for history_hr db
                User_conversation_id: stepContext.context.activity.conversation.id,
                User_name: await DialogUtils.getInstance().getUserNameOnly(stepContext.context.activity),
                User_email: await DialogUtils.getInstance().getemail(stepContext.context),
                utterance: stepContext.options.utterance,
                usecase_name: 'Policy Details',
                INC_Number: stepContext.options.ticket_number
            }
            stepContext.options.payload = payload;
            
            
            if(stepContext.options.mailsend=='failed'){
                stepContext.options.payload.usecase_name = "Unrecognized-Intent Policy details failed to send mail"
            }else{
                stepContext.options.payload.usecase_name = "Unrecognized-Intent Policy details"
            }
            
            if(stepContext.options.userinput=='yes'){
                const cardmsg = CardHandler.getInstance().createCardMsgActivity(stepContext, PlatFormCarType.HR_CARD.toString(), stepContext.options.payload)
                console.log("cardmsg " + JSON.stringify(cardmsg))
                await Datastore.getInstance().logTranscriptHR("Card displayed!",stepContext.options.session_id,"BOT")
                await stepContext.context.sendActivity(cardmsg);
                
                LoggingUtil.log.info("Payload for HR db:" + JSON.stringify(stepContext.options.payload))
                await Datastore.getInstance().logutterancedatatodb(stepContext.options.payload,stepContext.options.session_id)
            }
            return await stepContext.replaceDialog("HR_Greeting",{session_id: stepContext.options.session_id,excludedfolder: stepContext.options.excludedfolder,retry: true});

        
       
    }

    public async sendEmail(payload: any) {
        let utterance = payload.utterance;
        let username = payload.User_name;
        let usermail = payload.User_email;
        var nodemailer = require('nodemailer');
        let res
        try {
            var moment = require('moment-timezone')
            let m = moment().tz('America/Toronto').format()
            let time = m.substring(0, 10) + " " + m.substring(11, 19)

            let transporter = await nodemailer.createTransport({
                host: "smtp.duracell.com",
                port: 25,
                secure: false, // true for 465, false for other ports

            });

            console.log("Message sent: inside nodemailer");

            await transporter.verify(function (error, success) {
                if (error) {
                    LoggingUtil.log.info("Error in verify")
                    console.log(error);
                } else {
                    res = true
                    console.log("Server is ready to take our messages");
                }
            });
            LoggingUtil.log.info("After transporter verify")

            // send mail with defined transport object
            let info = await transporter.sendMail({
                from: 'duracmbf@duracell.com', // sender address
                to: 'n.k@duracell.com',
                subject: "Unrecognized-Intent Policy details", // Subject line
                text: "test mail", // plain text body
                html: "<html> <head></head>" +
                "<body>" +
                "<p>" +
                "User queried for below utterance which is not able to recognized by the automated bot: </br>"+
                "<b>Username</b>: " + username + " </br>" +
                "<b>User Email</b>: " + usermail + " </br>" +
                "<b>User utterance</b>: " + utterance + " </br>" +
                "<b>Timestamp</b>: " + time + "</br>" +
                "This is an automated mail please do not reply.</br>" +
                "</p>" +
                "</body>" +
                "</html>",
            });
            LoggingUtil.log.info("After sendmail ")

        }
        catch (e) {
            LoggingUtil.log.error("Error in send mail=" + e)
        }

        return res

    }
}

