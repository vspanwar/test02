const { InputHints, MessageFactory,CardFactory } = require('botbuilder');
import { ComponentDialog, DialogTurnResult,ActivityPrompt,TextPrompt,ChoicePrompt,ChoiceFactory, ConfirmPrompt,WaterfallDialog,WaterfallStepContext } from 'botbuilder-dialogs';
import {FeedbackDetails } from './FeedbackDetails';
import { PlatFormCarType } from './PlatformCards'; 
import { CardHandler } from '../CardHandler';
import { MessageUtils } from '../MessageUtils';
import { AdminService } from '../../../service/AdminService';



 export class FeedbackDialog extends ComponentDialog {
     
    constructor(id:string) {
        super(id || 'feedbackDialog');

            this.addDialog(new ConfirmPrompt(PlatFormCarType.CONFIRM_PROMPT))
            .addDialog(new TextPrompt(PlatFormCarType.TEXT_PROMPT))
            .addDialog(new ChoicePrompt(PlatFormCarType.CHOICE_PROMPT))
            .addDialog(new ActivityPrompt('formPrompt', async (stepContext) => {
                    const activity = stepContext.recognized.value;
                   if (activity.type === 'message') {
              
                     return true;

                    }
                    return false;
                }));        
                this.addDialog(new WaterfallDialog(PlatFormCarType.WATERFALL_DIALOG, [
                this.categoryStep.bind(this),
                this.confirm1Step.bind(this),
                this.confirm2Step.bind(this)
            ]));

        this.initialDialogId = PlatFormCarType.WATERFALL_DIALOG;
    }

    async categoryStep(stepContext) {
        const feedbackDetails = stepContext.options as FeedbackDetails;
        let msg
        if (stepContext.options.language){
            stepContext.context.activity.locale=stepContext.options.language
            // messageText = MessageUtils.getInstance().getMessage("CreateIncident_moreDetails",stepContext.options.language);
        }
         msg = MessageUtils.getInstance().getMessage("Feedback_overallExp",stepContext.context.activity.locale);
        let options=[MessageUtils.getInstance().getMessage("Feedback_verySatisfied",stepContext.context.activity.locale),
        MessageUtils.getInstance().getMessage("Feedback_satisfied",stepContext.context.activity.locale),
        MessageUtils.getInstance().getMessage("Feedback_neutral",stepContext.context.activity.locale),
        MessageUtils.getInstance().getMessage("Feedback_dissatisfied",stepContext.context.activity.locale)]
        return CardHandler.sendPrompt(stepContext,PlatFormCarType.CHOICE_PROMPT,msg,options);

    }


    async confirm1Step(stepContext) {

        let payload = {
            status: stepContext.result.value,
            timestamp: new Date()
        }
        await AdminService.getInstance().updateSession(stepContext.context.activity.conversation.id, payload, 'usecase.feedback')
        const feedbackDetails = stepContext.options as FeedbackDetails;
        feedbackDetails.button=stepContext.result.index;
        const msg= MessageUtils.getInstance().getMessage("Feedback_whatWentWrong",stepContext.options.language)
        const msg1= MessageUtils.getInstance().getMessage("Feedback_shareExperience",stepContext.options.language)
        if(feedbackDetails.button==2 ||feedbackDetails.button==3){
            return  await stepContext.prompt(PlatFormCarType.TEXT_PROMPT,msg+"\n\n"+msg1);
        }
        else{
            stepContext.context.activity.text = '';
            return await stepContext.next();          
        }
       
    }

    async confirm2Step(stepContext) {
       
        await AdminService.getInstance().updateSession(stepContext.context.activity.conversation.id, stepContext.context.activity.text, 'usecase.feedback.user_feedback')
        const msg1=MessageUtils.getInstance().getMessage("Feedback_extended",stepContext.options.language);
        await stepContext.context.sendActivity(msg1);  
        const msg=MessageUtils.getInstance().getMessage("Feedback_thanks",stepContext.options.language);
        await stepContext.prompt(PlatFormCarType.TEXT_PROMPT,msg)
        return await stepContext.endDialog();
     
    }

}


