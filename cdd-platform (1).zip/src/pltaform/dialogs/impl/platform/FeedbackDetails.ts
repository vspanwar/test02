export class FeedbackDetails {
    public button: number;
}
