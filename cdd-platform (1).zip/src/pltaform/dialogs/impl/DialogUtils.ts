import { TeamsInfo } from "botbuilder";
import { Channels } from "botframework-schema";
import { Logger } from "log4js";
import { LoggingUtil } from "../../../common/utils/log4js";
import { PlatformCache } from "../../core/PlatformCache";
import { RecognizerFactory } from "../../core/recognizer/IntentRecognizer";
import { TranslatorService } from "../../service/TranslatorService";
import { HttpUtil } from './../../../common/utils/HttpUtil';

export class DialogUtils{
    private static instance: DialogUtils = null;
    private static languageCache=new Map<String, String>()
    private constructor() {
        DialogUtils.languageCache.set("English","en")
        DialogUtils.languageCache.set("Spanish","es")
        DialogUtils.languageCache.set("Polish","pl")
        DialogUtils.languageCache.set("Turkish","tr")
        DialogUtils.languageCache.set("Hungarian","hu")
        DialogUtils.languageCache.set("Dutch","nl")
        DialogUtils.languageCache.set("French","fr")
        DialogUtils.languageCache.set("Swedish","sv")
        DialogUtils.languageCache.set("Russian","ru")
        DialogUtils.languageCache.set("German","de")
        DialogUtils.languageCache.set("Italian","it")
        DialogUtils.languageCache.set("Portuguese","pt")
        DialogUtils.languageCache.set("Czech","cs")
        DialogUtils.languageCache.set("Arabic","ar")
        DialogUtils.languageCache.set("Korean","ko")
        DialogUtils.languageCache.set("Indonesian","id")
        DialogUtils.languageCache.set("Thai","th")
        DialogUtils.languageCache.set("Japanese","ja")
        DialogUtils.languageCache.set("Vietnamese","vi")
        DialogUtils.languageCache.set("Chinese","zh-Hans")
        
        DialogUtils.languageCache.set("zh-Hans","Chinese")
        DialogUtils.languageCache.set("en","English")
        DialogUtils.languageCache.set("es","Spanish")
        DialogUtils.languageCache.set("pl","Polish")
        DialogUtils.languageCache.set("tr","Turkish")
        DialogUtils.languageCache.set("hu","Hungarian")
        DialogUtils.languageCache.set("nl","Dutch")
        DialogUtils.languageCache.set("fr","French")
        DialogUtils.languageCache.set("sv","Swedish")
        DialogUtils.languageCache.set("ru","Russian")
        DialogUtils.languageCache.set("de","German")
        DialogUtils.languageCache.set("it","Italian")
        DialogUtils.languageCache.set("pt","Portuguese")
        DialogUtils.languageCache.set("cs","Czech")
        DialogUtils.languageCache.set("ar","Arabic")
        DialogUtils.languageCache.set("ar","Arabic")
        DialogUtils.languageCache.set("ko","Korean")
        DialogUtils.languageCache.set("id","Indonesian")
        DialogUtils.languageCache.set("th","Thai")
        DialogUtils.languageCache.set("ja","Japanese")
        DialogUtils.languageCache.set("vi","Vietnamese")        
    }
    public static getInstance(): DialogUtils {
        if (DialogUtils.instance == null) {
            DialogUtils.instance = new DialogUtils();
        }
        return DialogUtils.instance;
    }
    public static getServicePortalUrl(){
        return "https://tcsesbx.service-now.com/tcscognix"
    }
    public async getUserNameOnly(activity:any){
        let userName=""
        let name = ''
        if(activity.channelId=="emulator"){
            userName="N, Keerthana"
            let arr= userName.split(",")
            name= arr[1]
        }
        else if(activity.channelId=="directline"){
            userName=activity.from.id
            let arr= userName.split(",")
            name= arr[1]
        }
        else{
            userName=activity.from.name
            console.log("User name for Teams in getUserNameOnly----"+userName);
            //name = userName.replace(' ','').split(',').reverse().join(' ')
            let arr = userName.split(",")
            name= arr[1]
        }
           
        return name
    }

    public async getemail(context :any ){
        let email = ''
        let user_details
        //LoggingUtil.log.info("Inside getmail:::"+JSON.stringify(context))
        if(context.activity.channelId == Channels.Directline){
            email = context.activity.channelData.mail_id
        }
        else if(context.activity.channelId == Channels.Msteams){
            let member=await TeamsInfo.getMember(context,context.activity.from.id)
            LoggingUtil.log.info("User Details:"+JSON.stringify(member))
            LoggingUtil.log.info("User Details:"+member)

            email= (await member).email
        }
        else{
            //email = 'geete.a@duracell.com'
            email = 'zlatanov.r@duracell.com'
        }
        LoggingUtil.log.info("Fetched mail::::"+email)
        return email
    }    //    data = name +" ("+d+") :"

    //    console.log("Name in dialog utils:"+name +"   time:"+d  +  "   data:"+data)

    //    if(activity.type === 'message') 
    //    { 
    //         if(activity.text == undefined)
    //         {
    //         // LoggingUtil.log.info("Activity text undefined:")  
    //         }
    //         else
    //         { 
    //              data = name +" ("+d+") : "+ activity.text
    //             // LoggingUtil.log.info("Activity text:"+activity.text)  
    //         }
    //         LoggingUtil.log.info("data inside gettranscript"+data)
    //     }
    

    //    else if(activity.attachments[0].contentType==="application/vnd.microsoft.card.hero"){
          
    //         let text = activity.attachments[0].content.text
    //        data = name+" ("+d+ ") : "+ activity.attachments[0].content.text
    //        LoggingUtil.log.info("Hero card text:"+text)
    //    }

    //     return data
    // }


    public getLanguageCode(language:String){
        return DialogUtils.languageCache.get(language)
    }
    //  API FOR INTERACTION
    private constructHeaders(config:any) {
        let authToken = "Basic " + Buffer.from(config.principal  + ":" + config.secret).toString('base64')
        let headers = {}
        headers['Authorization'] = authToken;
        headers['Content-Type'] = 'application/json';
        LoggingUtil.log.debug("## Token:" + authToken);
        return headers;
    }
    public async Interaction(payload){
        const config = {
            
            "principal":"cdd_chatbot.interaction" ,
            "secret": "cdd_chatbot.interaction"
        }
        const url='https://tcsesbx.service-now.com/api/now/table/interaction'
        return HttpUtil.post(url,payload,this.constructHeaders(config))
        

    }
    public async GetPhone(sys_id){
        const config = {
            
            "principal":"genesys.integration" ,
            "secret": "genesys.integration"
        }
        const url='https://tcsesbx.service-now.com/api/now/table/sys_user?sysparm_query=sys_id%3D'+sys_id+'&sysparm_fields=phone&sysparm_limit=1'
        let res= await HttpUtil.get(url,this.constructHeaders(config))
        console.log(res.result[0].phone,"PHONE_NUMBER")
        if (res.result[0].phone){
            //return undefined
            return res.result[0].phone
        }
        return undefined

    }
    public async Translate (msg,language){
        
        let text= await TranslatorService.getInstance().translate(msg, language,'')
        return text
    }
}




