import { po_data } from "../../model/PO_details";

export class Find_email {
    private static instance: Find_email

    constructor() { }

    public static getInstance(): Find_email {
        if (Find_email.instance == null) {
            Find_email.instance = new Find_email();
        }
        return Find_email.instance;
    }

    public getEmail(company_code: any) {

        let comapany_code = company_code
        let email = ''
        switch (comapany_code) {
            case '1001': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1002': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1003': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1004': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1005': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1006': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1007': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '1008': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '2001': email = 'suppliersupportch.im@duracell.com'
                break
            case '2002': email = 'suppliersupportbe.im@duracell.com'
                break
            case '2003': email = 'aarschotap.im@duracell.com'
                break
            case '2004': email = 'suppliersupportuk.im@duracell.com'
                break
            case '2005': email = 'suppliersupportfr.im@duracell.com'
                break
            case '2006': email = 'suppliersupportde.im@duracell.com'
                break
            case '2007': email = 'suppliersupportat.im@duracell.com'
                break
            case '2008': email = 'suppliersupportit.im@duracell.com'
                break
            case '2009': email = 'suppliersupportes.im@duracell.com'
                break
            case '2011': email = 'suppliersupportpl.im@duracell.com'
                break
            case '2014': email = 'suppliersupportnl.im@duracell.com'
                break
            case '2016': email = 'suppliersupporttr.im@duracell.com'
                break
            case '2017': email = 'suppliersupportsa.im@duracell.com'
                break
            case '2019': email = 'suppliersupportae.im@duracell.com'
                break
            case '2021': email = 'aarschotap.im@duracell.com'
                break
            case '2022': email = 'suppliersupportssc.im@duracell.com'
                break
            case '3002': email = 'Suppliersupportmx.im@duracell.com'
                break
            case '3003': email = 'suppliersupportbr.im@duracell.com'
                break
            case '3004': email = 'suppliersupportcl.im@duracell.com'
                break
            case '4006': email = 'APB2BHelpDesk@duracell.com'
                break
            case '4007': email = 'APB2BHelpDesk@duracell.com'
                break
            case '4009': email = 'APB2BHelpDesk@duracell.com'
                break
            case '4010': email = 'APB2BHelpDesk@duracell.com'
                break
            case '4011': email = 'APB2BHelpDesk@duracell.com'
                break

            case '9001': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '9002': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '9003': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '9004': email = 'APNAHelpDesk.im@duracell.com'
                break
            case '9005': email = 'suppliersupportch.im@duracell.com'
                break
            case '9006': email = 'suppliersupportch.im@duracell.com'
                break
            default: email = ''
                break
        }


        return email
    }
    public getPayload(short_description: any, error: any, payload1: any, api_response: any) {
        console.log("inside get payload: " + error)
        console.log("payload isss: " + payload1)


        var moment = require('moment-timezone')
        let m = moment().tz('America/Toronto').format()
        let time = m.substring(0, 10) + " " + m.substring(11, 19)


        let username = (payload1.email).split('@')[0]

        let desc = "PO number: " + payload1.po_number + " Timestamp:" + time + " User email:" + payload1.email + " Error: " + error.toString() + " API response:" + api_response.toString()
        let payload = {
            short_description: short_description,
            u_affected_user: username,
            description: desc,
            assignment_group: "APP-FLS-BotFramework",
            category: "Applications (All)",
            caller_id: "botframework",
            subcategory: "Chatbot",
            contact_type: "self-service"
        }
        console.log("inside get payload: " + JSON.stringify(payload))
        return payload
    }
    public async sendEmail(payload: any, error: any) {
        console.log("Inside sendmail::" + error)
        var nodemailer = require('nodemailer');
        let po_number = payload.po_number
        let email = payload.email
        let res

        var moment = require('moment-timezone')
        let m = moment().tz('America/Toronto').format()
        let time = m.substring(0, 10) + " " + m.substring(11, 19)

        let transporter = nodemailer.createTransport({
            host: process.env.smpt_host,
            port: 25,
            secure: false, // true for 465, false for other ports

        });
        console.log("Message sent: inside nodemailer");

        transporter.verify(function (error, success) {
            if (error) {
                res = false
                console.log(error);
            } else {
                res = true
                console.log("Server is ready to take our messages");
            }
        });


        // send mail with defined transport object
        let info = transporter.sendMail({
            from: 'duracmbf@duracell.com',   //process.env.smtp_from_email
            to: 's.a@duracell.com',
            // process.env.smpt_to_email
            subject: "Automation Failed",
            text: "Automation error mail",
            html: "<html> <head></head>" +
                "<body>" +
                "<p>" +
                "Please find the error details below:</br>" +
                "<b>PO number</b>: " + po_number + " </br>" +
                "<b>User Email</b>: " + email + " </br>" +
                "<b>Timestamp</b>: " + time + " </br>" +
                "<b>Error</b>: " + error + "</br>" +
                "</p>" +
                "</body>" +
                "</html>",
        });

        return res

    }








}