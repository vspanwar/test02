
import { BaseComponentDialog } from './../BaseComponentDialog';
import { RecognizerFactory } from './../../core/recognizer/IntentRecognizer';
;
import { AdminService } from './../../service/AdminService';
import { RootDialog } from "../RootDialog";
import { NoneDialog } from './platform/NoneDialog';
import { LoggingUtil } from '../../../common/utils/log4js';
import { HR_Greetings } from './platform/HR_Greetings';
import { Personal_Info } from './platform/Personal_Info';
import { PlatformTimeOut } from './platform/PlatformTimeOut';
import { hrgreetings } from './platform/hrgreetings';
import { ItApplication } from './platform/ItApplication';
import { HR_IsThere } from './platform/HR_IsThere';


export class DialogFactory {

    public static dialogRegistry: Map<string, BaseComponentDialog>;

    public static getRegistry(){
        if( ! DialogFactory.dialogRegistry ){
            DialogFactory.dialogRegistry = new Map<string, BaseComponentDialog>();
               
            DialogFactory.dialogRegistry.set('None', new NoneDialog("None")); 
            DialogFactory.dialogRegistry.set('HR_Greeting', new HR_Greetings("HR_Greeting")); 
            DialogFactory.dialogRegistry.set('Personal.intent', new Personal_Info("Personal.intent")); 
            DialogFactory.dialogRegistry.set('Timeout', new PlatformTimeOut("Timeout"));   
            DialogFactory.dialogRegistry.set('HrGreeting', new hrgreetings("HrGreeting")); 
            DialogFactory.dialogRegistry.set('ItApplication', new ItApplication("ItApplication"));
            DialogFactory.dialogRegistry.set('HR_IsThere', new HR_IsThere("HR_IsThere")); 
           
           }
        return DialogFactory.dialogRegistry;
    }

    public static async getRootDialog(bot:any, tenantId:string){
        const recognizer= RecognizerFactory.getRecognizer(tenantId,bot);
        var dialogs = [];
        let nlpConfig =await AdminService.getInstance().getNlpCfg(bot.tenantId,bot.botId);
        if(nlpConfig.intents){
            //console.log("asssssssssssss",JSON.stringify(nlpConfig))
            for (let intent of nlpConfig.intents){
                let dialogTmp = this.getRegistry().get(intent.name).getNewInstance(bot);
                 //console.log("Intent in factory",intent)

                 //AdminService.getInstance().getNlpCfg(bot.tenantId,bot.botId);
                dialogs.push( dialogTmp );
                LoggingUtil.log.info("##dialogRegistered: "+dialogTmp._id)

            }
        }
        return new RootDialog(tenantId + ".root.dialog", dialogs,recognizer );
    }

    
}