import { LoggingUtil } from "../../../common/utils/log4js";
var msg_en=require('../../../../translators/en_english_translator')
var msg_es=require("../../../../translators/es_spanish_translator.json")
//var msg_de=require('../../../../translators/de_german_translator.json')
//var msg_id=require('../../../../translators/id_indonesian_bahasa_translator.json')
//var msg_cs=require("../../../../translators/cs_czech_translator.json")
//var msg_fr=require("../../../../translators/fr_french_translator.json")
//var msg_hu=require("../../../../translators/hu_hungarian_translator.json")
//var msg_it=require("../../../../translators/it_italian_translator.json")
//var msg_ja=require("../../../../translators/ja_japanese_translator.json")
//var msg_ko=require("../../../../translators/ko_korean_translator.json")
var msg_nl=require("../../../../translators/nl_dutch_translator.json")
//var msg_pl=require("../../../../translators/pl_polish_translator.json")
var msg_pt=require("../../../../translators/pt_potuguese_translator.json")
//var msg_ru=require("../../../../translators/ru_russian_translator.json")
//var msg_sv=require("../../../../translators/sv_swedish_translator.json")
//var msg_th=require("../../../../translators/th_thai_translator.json")
//ar msg_tr=require("../../../../translators/tr_turkish_translator.json")
//var msg_vi=require("../../../../translators/vi_vietnamese_translator.json")
var msg_zn=require("../../../../translators/zh-Hans_Mandarin_Chinese_translator.json")
//var msg_ar=require("../../../../translators/ar_arabic_translator.json")
export class MessageUtils{

    private static instance: MessageUtils = null;
    private static translator=new Map<String, String>()
    private constructor() {
        MessageUtils.translator.set("en",msg_en)

        MessageUtils.translator.set("es",msg_es)
       // MessageUtils.translator.set("de",msg_de)
        //MessageUtils.translator.set("id",msg_id)
        //MessageUtils.translator.set("cs",msg_cs)
        // MessageUtils.translator.set("fr",msg_fr)
        // MessageUtils.translator.set("hu",msg_hu)
        // MessageUtils.translator.set("it",msg_it)
        //MessageUtils.translator.set("ja",msg_ja)
        //MessageUtils.translator.set("ko",msg_ko)
        MessageUtils.translator.set("nl",msg_nl)
        //MessageUtils.translator.set("pl",msg_pl)
        MessageUtils.translator.set("pt-pt",msg_pt)
        //MessageUtils.translator.set("ru",msg_ru)
        //MessageUtils.translator.set("sv",msg_sv)
        //MessageUtils.translator.set("th",msg_th)
       // MessageUtils.translator.set("tr",msg_tr)
        //MessageUtils.translator.set("vi",msg_vi)
        MessageUtils.translator.set("zh-Hans",msg_zn)
        //MessageUtils.translator.set("ar",msg_ar)

    }
    public static getInstance(): MessageUtils {
        if (MessageUtils.instance == null) {
            MessageUtils.instance = new MessageUtils();
        }
        return MessageUtils.instance;
    }

    public getMessage(messageKey:string, languageCode:string):string{

        console.log("message key:" + messageKey + " languageCode:" + languageCode)
        if(this.languageIsThere(languageCode)){
        
            let translator = this.getTranslator(languageCode)
            console.log("Message Text:" + translator[messageKey])
            return translator[messageKey]

        }
        else{
            return  msg_en[messageKey]
        } 
    }

    public getTranslator(languageCode:string):any{
        return MessageUtils.translator.get(languageCode)
    }
    

    public languageIsThere(languageCode:string){
        if(MessageUtils.translator.has(languageCode)){
            return true
        }
        else{
            return false
        }
    }
    
}

