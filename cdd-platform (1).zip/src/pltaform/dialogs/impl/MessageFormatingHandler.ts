import { LoggingUtil } from "../../../common/utils/log4js";

export class MessageFormattingHandler {
    private static instance: MessageFormattingHandler

    constructor() { }

    public static getInstance(): MessageFormattingHandler {
        if (MessageFormattingHandler.instance == null) {
            MessageFormattingHandler.instance = new MessageFormattingHandler();
        }
        return MessageFormattingHandler.instance;
    }

    public getAnchorString(activity: any, url: string, title: string) {

        let ans = ""
        if (activity.channelId == "webchat" || activity.channelId == "directline") {
            ans = ans + "*|a_ " + url + "||" + title + " _a|* "
        }
        else {
            ans = ans + "[" + title + "](" + url + ") "
        }
        LoggingUtil.log.info("Anchor tag response:"+ans)
        return ans
    }

    public getBoldString(activity: any, msg: string) {

        let ans = ""
        if (activity.channelId == "webchat" || activity.channelId == "directline") {
            ans = ans + "*|b_ " + msg + " _b|*"
        }
        else {
            ans = ans + "**" + msg + "**"
        }
        return ans
    }

    public getNextline(activity: any) {
        let ans = ""
        if (activity.channelId == "webchat" || activity.channelId == "directline") {
            ans = ans + "*|n_ _n|*"
        }
        else {
            ans = ans + "\n\n"
        }
        return ans
    }
  


    public getRandomNo() {
        return Math.floor(100000 + Math.random() * 900000)
    }

    public anchorConvertToWebClient(activity: any, message: string) {
        if (activity.channelId == "webchat" || activity.channelId == "directline") {
            var i
            var anchor_start = false
            var url = false
            var title = false
            var url_link = ''
            var title_msg = ''
            var previous_msg = ''
            // let activate = {
            //     channelId:"webchat"
            //   }
            for (i = 0; i < message.length; i++) {
                if (message[i] == "[") {
                    anchor_start = true
                    title = true
                    //previous_msg = previous_msg + message[i]
                }
                else if (message[i] == "]") {
                    anchor_start = false
                    title = false
                    previous_msg = previous_msg + message[i]
                }
                else if (message[i] == '(') {
                    anchor_start = true
                    url = true
                    // previous_msg = previous_msg + message[i]
                }
                else if (message[i] == ')') {
                    anchor_start = false
                    url = false
                    previous_msg = previous_msg + message[i]
                    message = message.replace(previous_msg, this.getAnchorString(activity, url_link.slice(1), title_msg.slice(1)))
                    title_msg = ''
                    url_link = ''
                    previous_msg = ''
                }
                if (anchor_start) {
                    if (title) {
                        title_msg = title_msg + message[i]
                    }
                    else if (url) {
                        url_link = url_link + message[i]
                    }
                    previous_msg = previous_msg + message[i]
                }
            }
            message = message.replace(/\n\n/g, " *|n_ _n|* ")
            message = message.replace(/\n/g, " *|n_ _n|* ")
            // console.log("message",message)
        }
        return message
    }

    // public anchorConvertToWebClient(activity : any , message : string){
    //     //if(activity.channelId=="webchat" || activity.channelId=="directline"){
    //         var i
    //         var anchor_start = false
    //         var url = false
    //         var title = false
    //         var url_link = ''
    //         var title_msg = ''
    //         var previous_msg = ''
    //         for(i = 0;i<message.length;i++) { 

    //             if(anchor_start)
    //             {
    //                 if(url)
    //                 {
    //                     url_link = url_link + message[i]
    //                     previous_msg = previous_msg + message[i]
    //                 }
    //                 else if(title)
    //                 {
    //                     title_msg = title_msg + message[i]
    //                     previous_msg = previous_msg + message[i]
    //                 }
    //                 if(message[i]=="]" || message[i]=='(')
    //                 {
    //                     title = false
    //                     url = true
    //                     previous_msg = previous_msg + message[i]
    //                     continue
    //                 }
    //             }

    //             if(message[i]=="[")
    //             {
    //                 anchor_start = true
    //                 title = true
    //                 previous_msg = previous_msg + message[i]
    //                 continue;

    //             }
    //             else if(message[i]==')')
    //             {
    //                 anchor_start = false
    //                 url = false
    //                 console.log("title",title_msg,"url",url_link)
    //                 previous_msg = previous_msg + message[i]
    //                 message = message.replace(previous_msg,this.getAnchorString(activity,url_link,title_msg))
    //                 title_msg = ''
    //                 url_link = ''
    //                 previous_msg = ''
    //                 continue;
    //             }


    //         }  
    //         message = message.replace(/\n/g,"*|n_ _n|*")
    //    // }
    //     return message
    // }
}