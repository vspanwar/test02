import { KeyVaultService } from "../../../common/utils/keyvault/keyVaultService";
import { LoggingUtil } from "../../../common/utils/log4js";
import { po_data } from "../../model/PO_details";

import { MSSQLConfig } from "../../../common/repository/MSSQLConfig";
import { TranslatorService } from "../../service/TranslatorService";
import { env } from "process";
import { callbackify } from "util";
import { resolve } from "path";
import { rejects } from "assert";
var Connection = require('tedious').Connection;
var Request = require('tedious').Request;
var moment = require('moment-timezone')

export class Datastore {
    private static instance: Datastore

    constructor() { }

    public static getInstance(): Datastore {
        if (Datastore.instance == null) {
            Datastore.instance = new Datastore();
        }
        return Datastore.instance;
    }

    public async getTimestamp() {

        // var moment =require('moment-timezone')
        let m = moment().tz('America/Toronto').format()
        let time = m.substring(0, 10) + " " + m.substring(11, 19)
        return time

    }
    public async getDate() {

        // var moment =require('moment-timezone')
        let m = moment().tz('America/Toronto').format()
        let date = m.substring(0, 10)
        return date

    }
    public gettranscript(activity: any, env_name: any) {
        // LoggingUtil.log.info(":Activity in gettranscript "+JSON.stringify(activity))
        var moment = require('moment-timezone')
        let m = moment().tz('America/Toronto').format()
        let d = m.substring(0, 10) + " " + m.substring(11, 19)
        // let date = m.substring(0,10)


        let name = ""
        let data = ''

        if (activity.from.name == env_name || activity.from.name == 'Bot') {
            name = 'Bot'
        }
        else {
            if (activity.channelId == 'emulator') {
                activity.from.id = "S, Anusyua"
            }
            name = activity.from.id.split(",")[1]
        }

        data = name + " (" + d + ") :"
        return data
    }


    public async getConfig() {
        let db = await this.getDBdetails()
        let dbname = db.dbname
        var config =
        {
            server: 'aznc-rpasqld001.corp.duracell.com',
            // process.env.sql_server,

            authentication: {
                type: 'default',
                options: {
                    // userName: await KeyVaultService.getInstance().getKey('SQLusername'), 
                    // password: await KeyVaultService.getInstance().getKey('SqlToken')

                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {

                encrypt: true,
                database: dbname
                //'ipsoftaudit' 
            }
        };
        return config
    }

    public async getDBdetails() {
        // let dbname = process.env.DatabaseName
        // let tablename = process.env.TableName
        let data = {
            dbname: 'ipsoftaudit',
            tablename: 'mbf_history'
        }
        return data
    }

    public async gethrDBdetails() {
        // let dbname = process.env.DatabaseName
        // let tablename = process.env.TableName
        let data = {
            dbname: 'ipsoftaudit',
            tablename: 'mbf_history_hr'
        }
        return data
    }

    public async Updatedb(field: any, value: any, conv_id1: any) {
        // console.log("Field: "+field+ " "+"value"+ value)

        let db = await this.getDBdetails()
        let dbname = db.dbname
        let tablename = db.tablename
        let conv_id = conv_id1.split('|')[0]
        var config = await this.getConfig()
        //var connection = await  MSSQLConfig.getDBConnection()
        var connection = new Connection(config);

        connection.on('connect', async function (err) {
            // If no error, then good to proceed.
            console.log("Connected into db")
            await executeStatement(dbname, tablename)

        });
        connection.connect();

        async function executeStatement(database: any, tablename: any) {

            var request = new Request("UPDATE [" + database + "].[dbo].[" + tablename + "] SET " + field + " = '" + value + "' WHERE user_conversation_id = '" + conv_id + "' AND status NOT LIKE 'Completed%';",
                //var request = new Request("UPDATE ["+database+"].[dbo].["+tablename+"] SET status = 'DevInProgess' WHERE user_conversation_id = 'abcd123';",
                function (err) {
                    if (err) {
                        console.log(err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            await connection.execSql(request);
        }

    }

    public async UpdatedbHR(field: any, value: any, session_id: any) {
        // console.log("Field: "+field+ " "+"value"+ value)

        let db = await this.getDBdetails()
        let dbname = db.dbname
        let tablename = db.tablename
        var config = await this.getConfig()
        //var connection = await  MSSQLConfig.getDBConnection()
        var connection = new Connection(config);

        connection.on('connect', async function (err) {
            // If no error, then good to proceed.
            console.log("Connected into db")
            await executeStatement(dbname, tablename)

        });
        connection.connect();

        async function executeStatement(database: any, tablename: any) {

            var request = new Request("UPDATE [" + database + "].[dbo].[" + tablename + "] SET " + field + " = '" + value + "' WHERE session_id = '" + session_id + "' AND status NOT LIKE 'Completed%';",
                //var request = new Request("UPDATE ["+database+"].[dbo].["+tablename+"] SET status = 'DevInProgess' WHERE user_conversation_id = 'abcd123';",
                function (err) {
                    if (err) {
                        console.log(err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            await connection.execSql(request);
        }

    }

    public async logdatatodb(db_data: any, payload: any) {

        let db = await this.getDBdetails()
        LoggingUtil.log.info("Credentials :" + JSON.stringify(db))
        let dbname = db.dbname
        let tablename = db.tablename
        var config = await this.getConfig()
        LoggingUtil.log.info("config:" + JSON.stringify(config))

        var connection = new Connection(config);
        connection.on('connect', function (err) {
            // If no error, then good to proceed.
            console.log("Connected into db logdatatodb")
            executeStatement(dbname, tablename)

        });
        connection.connect();

        function executeStatement(database: any, tablename: any) {

            let user_conversation_id = db_data.User_conversation_id.split('|')[0]
            // let user_conversation_id = 'abcd123'
            let User_name = db_data.User_name
            let User_email = db_data.User_email
            let create_timestamp = db_data.Create_timestamp
            let status = db_data.Status
            let gr_number = db_data.GR_number
            let end_timestamp = db_data.end_timestamp
            let transcript = ""
            let date = db_data.Date
            let branch = db_data.branch

            console.log("Query into db: " + "INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,create_timestamp,end_timestamp,status,gr_number,date,transcript,branch) VALUES ('" + user_conversation_id + "','" + User_name + "','" + User_email + "','" + create_timestamp + "','" + end_timestamp + "','" + status + "','" + gr_number + "','" + date + "','" + transcript + "','" + branch + "');")
            var request = new Request("INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,create_timestamp,end_timestamp,status,gr_number,date,transcript,branch) VALUES ('" + user_conversation_id + "','" + User_name + "','" + User_email + "','" + create_timestamp + "','" + end_timestamp + "','" + status + "','" + gr_number + "','" + date + "','" + transcript + "','" + branch + "');",
                //var request = new Request('INSERT INTO [IPSOFTAudit].[dbo].[1DeskAudit] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16) VALUES ("'+id+'","'+channel_name+'","'+process+'","'+user_id+'","'+time_Stamp+'","'+attribute1+'","'+attribute2+'","'+attribute3+'","'+attribute4+'","'+attribute5+'","'+attribute6+'","'+attribute7+'","'+attribute8+'","'+attribute9+'","'+attribute10+'","'+attribute11+'","'+attribute12+'","'+attribute13+'","'+attribute14+'","'+attribute15+'","'+attribute16+'");',

                function (err) {
                    if (err) {
                        console.log("error in logdb query",err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            connection.execSql(request);
        }

    }


    public async loghrdatatodb(db_data: any) {

        let db = await this.getDBdetails()
        //LoggingUtil.log.info("Credentials in hr :" + JSON.stringify(db))
        let dbname = db.dbname
        let tablename = db.tablename
        var config = await this.getConfig()
        //LoggingUtil.log.info("config:" + JSON.stringify(config))
        
        return new Promise(async (resolve, rejects) => {
        var connection = new Connection(config);
        connection.on('connect', function (err) {
            // If no error, then good to proceed.
            if(err){
                rejects (err)
            }
            console.log("Connected into db logdatatodb in hr")
            //resolve (executeStatement(dbname, tablename))
            executeStatement(dbname, tablename)

        });
        connection.connect();

        function executeStatement(database: any, tablename: any) {

            let user_conversation_id = db_data.User_conversation_id.split('|')[0]
            // let user_conversation_id = 'abcd123'
            let User_name = db_data.User_name
            let User_email = db_data.User_email
            let create_timestamp = db_data.Create_timestamp
            let status = db_data.Status
            let end_timestamp = db_data.end_timestamp
            let transcript = ""
            let date = db_data.Date
            let branch = db_data.branch

            console.log("Query into db: " + "INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,create_timestamp,end_timestamp,status,date,transcript,branch) VALUES ('" + user_conversation_id + "','" + User_name + "','" + User_email + "','" + create_timestamp + "','" + end_timestamp + "','" + status + "','" + date + "','" + transcript + "','" + branch +  "');")
            var request = new Request("INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,create_timestamp,end_timestamp,status,date,transcript,branch) VALUES ('" + user_conversation_id + "','" + User_name + "','" + User_email + "','" + create_timestamp + "','" + end_timestamp + "','" + status + "','" + date + "','" + transcript + "','" + branch +  "');",
                //var request = new Request('INSERT INTO [IPSOFTAudit].[dbo].[1DeskAudit] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16) VALUES ("'+id+'","'+channel_name+'","'+process+'","'+user_id+'","'+time_Stamp+'","'+attribute1+'","'+attribute2+'","'+attribute3+'","'+attribute4+'","'+attribute5+'","'+attribute6+'","'+attribute7+'","'+attribute8+'","'+attribute9+'","'+attribute10+'","'+attribute11+'","'+attribute12+'","'+attribute13+'","'+attribute14+'","'+attribute15+'","'+attribute16+'");',

                function (err, result) {
                    if (err) {
                        console.log("error in logdb hr query",err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                //console.log("in hr request.on")
                //return resolve ("in hr request.on")
                resolve (connection.close());
            });
            connection.execSql(request);
        }
    })

    }

    public async logutterancedatatodb(db_data: any,sess_id:any) {

        let db = await this.gethrDBdetails()
        LoggingUtil.log.info("Credentials :" + JSON.stringify(db))
        let dbname = db.dbname
        let tablename = db.tablename
        var config = await this.getConfig()
        LoggingUtil.log.info("config:" + JSON.stringify(config))

        var connection = new Connection(config);
        connection.on('connect', function (err) {
            // If no error, then good to proceed.
            console.log("Connected into db logdatatodb")
            executeStatement(dbname, tablename)

        });
        connection.connect();

        function executeStatement(database: any, tablename: any) {

            let User_conversation_id = db_data.User_conversation_id.split('|')[0]
            //let session_id = sess_id
            let User_name = db_data.User_name
            let User_email = db_data.User_email
            let utterance = db_data.utterance
            let usecase_name = db_data.usecase_name
            let INC_Number = db_data.INC_Number

            console.log("Query into db: " + "INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,utterance,usecase_name,INC_Number) VALUES ('" + User_conversation_id + "','" + User_name + "','" + User_email + "','" + utterance + "','" + usecase_name + "','" + INC_Number + "');")
            var request = new Request("INSERT INTO [" + database + "].[dbo].[" + tablename + "] (user_conversation_id,user_name,user_email,utterance,usecase_name,INC_Number) VALUES ('" + User_conversation_id + "','" + User_name + "','" + User_email + "','" + utterance + "','" + usecase_name + "','" + INC_Number + "');",
                //var request = new Request('INSERT INTO [IPSOFTAudit].[dbo].[1DeskAudit] (id, channel_Name, process_Name, user_Id,time_Stamp,attribute1,attribute2,attribute3,attribute4,attribute5,attribute6,attribute7,attribute8,attribute9,attribute10,attribute11,attribute12,attribute13,attribute14,attribute15,attribute16) VALUES ("'+id+'","'+channel_name+'","'+process+'","'+user_id+'","'+time_Stamp+'","'+attribute1+'","'+attribute2+'","'+attribute3+'","'+attribute4+'","'+attribute5+'","'+attribute6+'","'+attribute7+'","'+attribute8+'","'+attribute9+'","'+attribute10+'","'+attribute11+'","'+attribute12+'","'+attribute13+'","'+attribute14+'","'+attribute15+'","'+attribute16+'");',

                function (err) {
                    if (err) {
                        console.log("error in logdb utterance query",err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            connection.execSql(request);
        }

    }



    public async gethrPayload(env) {
        let ts = await this.getTimestamp()
        let date = await this.getDate()
        let payload = {
            "User_conversation_id": '',
            "User_name": '',
            "User_email": '',
            "Create_timestamp": ts,

            "feedback_value": '',
            "feedback_comments": '',

            "Status": "New",
            "end_timestamp": ts,
            "Transcript": "",
            "Date": date,
            "branch": env.split('F')[1]
        }
        return payload
    }


    public async logTranscript(value: any, conv_id1: any) {

        console.log("transcript value" + value)

        let db = await this.getDBdetails()
        let dbname = db.dbname
        let tablename = db.tablename
        let conv_id = conv_id1.split('|')[0]

        var config = await this.getConfig()
        var connection = new Connection(config);
        connection.on('connect', function (err) {
            // If no error, then good to proceed.
            console.log("Connected into db")
            executeStatement(dbname, tablename)

        });
        connection.connect();

        function executeStatement(database: any, tablename: any) {
            LoggingUtil.log.info("transcript query  ----->  update [" + database + "].[dbo].[" + tablename + "] set transcript=concat(transcript,'" + value + "') WHERE user_conversation_id='" + conv_id + "' AND status <> 'Completed';")

            var request = new Request("update [" + database + "].[dbo].[" + tablename + "] set transcript=concat(transcript,'" + value + "') WHERE user_conversation_id='" + conv_id + "' AND status <> 'Completed'",
                function (err) {
                    if (err) {
                        console.log("error in log transcript",err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                connection.close();
            });
            connection.execSql(request);
        }

    }

    public async logTranscriptHR(value: any, session_id: any, user:any) {

        console.log("transcript value" + value)
        let time =await Datastore.getInstance().getTimestamp()

        let tc = user +"("+ time +"): " + value+"|"
        console.log("here is tc-->",tc)
        let db = await this.getDBdetails()
        let dbname = db.dbname
        let tablename = db.tablename

        var config = await this.getConfig()
        var connection = new Connection(config);
        //return new Promise(async (resolve, rejects) => {
        connection.on('connect', function (err) {
            if(err){
                //rejects (err)
            }
            // If no error, then good to proceed.
            console.log("Connected into db")
            executeStatement(dbname, tablename)

        });
        connection.connect();

        function executeStatement(database: any, tablename: any) {
            LoggingUtil.log.info("transcript query for HR----->  update [" + database + "].[dbo].[" + tablename + "] set transcript=concat(transcript,'" + tc + "') WHERE session_id='" + session_id + "' AND status <> 'Completed';")

            var request = new Request("update [" + database + "].[dbo].[" + tablename + "] set transcript=concat(transcript,'" + tc + "') WHERE session_id='" + session_id + "' AND status <> 'Completed'",
                function (err) {
                    if (err) {
                        console.log("error in log transcript",err);
                    }
                }
            );
            request.on("requestCompleted", function (rowCount, more) {
                //resolve (connection.close());
                connection.close();
            });
            connection.execSql(request);
        }
   // })
    }


    public async getPayload(env) {
        let ts = await this.getTimestamp()
        let date = await this.getDate()
        let payload = {
            "User_conversation_id": '',
            "User_name": '',
            "User_email": '',
            "Create_timestamp": ts,

            "Status": "New",
            "GR_number": "",
            "end_timestamp": ts,
            "Transcript": "",
            "Date": date,
            "branch": env.split('F')[1]
        }
        return payload
    }

    public async getThankyouMsg(language: any) {
        let msg1 = "Thank you for using"
        let msg2 = "Virtual Assistant. Please close the browser tab as your session has ended. Have a great day."
        let msg3 = await TranslatorService.getInstance().translate(msg1, language)
        let msg4 = await TranslatorService.getInstance().translate(msg2, language)
        return msg3 + " Duracell " + msg4
    }

    public async updateStatus(activity: any, status: any) {
        let ts = await this.getTimestamp()
        await this.Updatedb('end_timestamp', ts, activity.conversation.id)
        await this.Updatedb('status', status, activity.conversation.id)

    }
    public async updateStatusHR(activity: any, status: any) {
        let session_id = await this.get_SessionID(activity.conversation.id)
        console.log("sess_id in update HR", session_id)
        let ts = await this.getTimestamp()
        await this.UpdatedbHR('end_timestamp', ts, session_id)
        await this.UpdatedbHR('status', status, session_id)

    }

    public async updateendtimestamp(activity: any) {

        let ts = await this.getTimestamp()
        await this.Updatedb('end_timestamp', ts, activity.conversation.id)
        //await this.Updatedb('status',status,activity.conversation.id)  

    }

    public async check_LineItem(lineitem: any, po_number: any, ref_number: any) {
        console.log("Field in data: ", lineitem, po_number, ref_number)
        // var moment = require('moment-timezone')
        // let m = moment().tz('America/Toronto').format()
        // let time = m.substring(0, 10) + " " + m.substring(11, 19)

        let dbname = process.env.DatabaseName
        let tablename = process.env.TableName
        let time = await this.getTimestamp()
        let domainCode = process.env.domainCode   //'domainCode=MBFPROD'
        LoggingUtil.log.info("Domain code in lineitem:" + domainCode)

        var Connection = require('tedious').Connection;

        var config = {
            server: 'aznc-rpasqld001.corp.duracell.com', //process.env.sql_server,
            authentication: {
                type: 'default',
                options: {
                    // userName: await KeyVaultService.getInstance().getKey('SQLusername'),
                    // password: await KeyVaultService.getInstance().getKey('SqlToken')
                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {
                encrypt: true,
                database: 'ipsoftaudit',
                rowCollectionOnDone: true,
                //rowCollectionOnRequestCompletion: true
            }
        };
        const allRows = [];
        var connection = new Connection(config);
        return new Promise(async (resolve, rejects) => {
            connection.on('connect', function (err) {

                if (err) {
                    rejects(err)
                }
                //console.log("enter the connection" , err)
                executeStatement(connection, function (error, result) {
                    // console.log("Connected into db in lineitem", result)
                    if (error) {
                        rejects(error)
                    }
                    //resolve(result)
                })
            });

            connection.connect();
            var Request = require('tedious').Request;
            function executeStatement(connection, callback) {
                let result = []
                var request = new Request("SELECT count(*) FROM [IPSOFTAudit].[dbo].[1DeskAudit] where attribute1='" + "domainCode=" + domainCode + "' and attribute10='bpn_purchaseOrder=" + po_number + "' and attribute11='po_line=" + lineitem + "' and attribute5='bpn_invoiceReference=" + ref_number + "' and cast (time_Stamp as datetime) between dateadd(DAY,-14,'" + time + "') and '" + time + "'",
                    //var request = new Request("SELECT count(*) FROM [IPSOFTAudit].[dbo].[1DeskAudit] where attribute1='domainCode=MBFPROD' and attribute10= 'bpn_purchaseOrder=7130080243' and attribute11='po_line="+lineitem+"' and attribute5='bpn_invoiceReference=1017' and cast (time_Stamp as datetime) between dateadd(DAY,-14,'2022-06-10') and '2022-06-10'",
                    function (err: any, rowCounts, res, row) {
                        if (err) {
                            console.log(err);
                            return callback(err, null);
                        }
                        else {
                            console.log(rowCounts + "rows returned")
                            // console.log(result + " rows returned")
                            // return callback(null,result)
                        }

                    });

                request.on('row', function (columns) {
                    columns.forEach(function (column) {
                        let row = []
                        row.push(
                            //metadata: column.metadata,
                            column.value
                            //toString: () => column.value
                        );
                        console.log(JSON.stringify(row) + "col rows returned")
                        allRows.push(row);
                    });
                });

                request.on('doneProc', function (rowCount, more, returnStatus, rows) {
                    //console.log('onDoneProc');
                    console.log('all rows here', allRows);
                    //console.log('all values here',allRows[0][0]);
                    // result.push(allRows)
                    // return result
                    return resolve(allRows[0][0]);
                });

                request.on("requestCompleted", function (rowCounts, more) {
                    connection.close();
                });
                connection.execSql(request);
            }
        })

    }

    public async get_SessionID(conv_id1) {
        console.log("Field in data: ", conv_id1)
        let conv_id = conv_id1.split('|')[0]

        var Connection = require('tedious').Connection;
        var config = {
            server: 'aznc-rpasqld001.corp.duracell.com', //process.env.sql_server,
            authentication: {
                type: 'default',
                options: {
                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {
                encrypt: true,
                database: 'ipsoftaudit',
                rowCollectionOnDone: true,
            }
        };
        const allRows = [];
        var connection = new Connection(config);
        return new Promise(async (resolve, rejects) => {
            connection.on('connect', function (err) {

                if (err) {
                    console.log("error")
                    rejects(err)
                }
                console.log("entered the connection")
                executeStatement(connection, function (error, result) {
                    if (error) {
                        console.log("error")
                        rejects(error)
                    }
                })
            });

            connection.connect();
            var Request = require('tedious').Request;
            function executeStatement(connection, callback) {
                let result = []
                console.log("here is the query:","SELECT TOP 1 session_id FROM [IPSOFTAudit].[dbo].[mbf_history] where user_conversation_id = '"+conv_id+"' ORDER BY create_timestamp DESC")
                var request = new Request("SELECT TOP 1 session_id FROM [IPSOFTAudit].[dbo].[mbf_history] where user_conversation_id = '"+conv_id+"' ORDER BY create_timestamp DESC",
                    function (err: any, rowCounts, res, row) {
                        if (err) {
                            console.log(err);
                            return callback(err, null);
                        }

                    });

                request.on('row', function (columns) {
                    columns.forEach(function (column) {
                        let row = []
                        row.push(column.value);
                        //console.log(JSON.stringify(row) + "col rows returned")
                        allRows.push(row);
                    });
                });

                request.on('doneProc', function (rowCount, more, returnStatus, rows) {
                    //console.log('all rows here', allRows);
                    console.log('all values here',allRows[0][0]);
                    // result.push(allRows)
                    // return result
                    return resolve(allRows[0][0]);
                    //return allRows[0][0]
                });

                request.on("requestCompleted", function (rowCounts, more) {
                    connection.close();
                });
                connection.execSql(request);
            }
        })

    }

    public async get_timeoutvalue(sessionid) {
        console.log("Field in data session id : ", sessionid)
        //let conv_id = conv_id1.split('|')[0]

        var Connection = require('tedious').Connection;
        var config = {
            server: 'aznc-rpasqld001.corp.duracell.com', //process.env.sql_server,
            authentication: {
                type: 'default',
                options: {
                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {
                encrypt: true,
                database: 'ipsoftaudit',
                rowCollectionOnDone: true,
            }
        };
        const allRows = [];
        var connection = new Connection(config);
        return new Promise(async (resolve, rejects) => {
            connection.on('connect', function (err) {

                if (err) {
                    console.log("error")
                    rejects(err)
                }
                console.log("entered the connection")
                executeStatement(connection, function (error, result) {
                    if (error) {
                        console.log("error")
                        rejects(error)
                    }
                })
            });

            connection.connect();
            var Request = require('tedious').Request;
            function executeStatement(connection, callback) {
                let result = []
                console.log("here is the query:","SELECT status FROM [IPSOFTAudit].[dbo].[mbf_history] where session_id = "+sessionid)
                var request = new Request("SELECT status FROM [IPSOFTAudit].[dbo].[mbf_history] where session_id = "+sessionid,
                    function (err: any, rowCounts, res, row) {
                        if (err) {
                            console.log("error - ",err);
                            return callback(err, null);
                        }

                    });

                request.on('row', function (columns) {
                    columns.forEach(function (column) {
                        let row = []
                        row.push(column.value);
                        //console.log(JSON.stringify(row) + "col rows returned")
                        allRows.push(row);
                    });
                });

                request.on('doneProc', function (rowCount, more, returnStatus, rows) {
                    //console.log('all rows here', allRows);
                    console.log('all values here',allRows[0][0]);
                    // result.push(allRows)
                    // return result
                    return resolve(allRows[0][0]);
                    //return allRows[0][0]
                });

                request.on("requestCompleted", function (rowCounts, more) {
                    connection.close();
                });
                connection.execSql(request);
            }
        })

    }


}



