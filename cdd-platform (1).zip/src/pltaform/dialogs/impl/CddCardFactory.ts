import { PlatformCards } from './platform/PlatformCards';
import { CardFactory } from 'botbuilder';
import { Activity, ActivityTypes, Attachment, 
    AttachmentLayoutTypes, CardAction, InputHints, SuggestedActions } from 'botframework-schema';

export class CddCardFactory {

    static getPlatformAdaptiveCard(cardName: string, 
        stepContext: any,
        options?:any,
        options1?:any,
        options2?:any): Attachment {

            return CardFactory.adaptiveCard(PlatformCards.getCard(cardName,stepContext, options,options1,options2));
    }

   
    
}