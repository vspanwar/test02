import { LoggingUtil } from '../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';



export class searchService  {

    private static instance: searchService;
    //private static baseUrl = 'https://durg-teamsbot-search.search.windows.net'
   //process.env.servicenow_base_url
   // 'https://duracelldev1.service-now.com'
    constructor() { 
    }

    public static getInstance(): searchService {
        if (searchService.instance == null) {
            searchService.instance = new searchService()
        }
        return searchService.instance;
    }


    public async PersonalIntent(email:any){

        var axios = require('axios');

        let result1 = await searchService.getInstance().graphapi()
        console.log("Bearer Token value", result1.data.access_token)

        var config = {
        method: 'get',
        url: 'https://graph.microsoft.com/beta/users/' + email,
        headers: { 
            'Authorization': 'Bearer ' + result1.data.access_token
        }
        };

        //console.log("configuration of api---===+++",config)
        let Result = axios(config)
        console.log("--------------->personal Intent details " ,Result)

        return Result

    }

    public async ManagerIntent(email:any){

        var axios = require('axios');

        let result1 = await searchService.getInstance().graphapi()
        console.log("Bearer Token value", result1.data.access_token)

        var config = {
        method: 'get',
        url: 'https://graph.microsoft.com/beta/users/' + email+'/manager',
        headers: { 
            'Authorization': 'Bearer ' + result1.data.access_token
        }
        };

        //console.log("configuration of api Manger---===+++",config)
        let Result = axios(config)
        console.log("--------------->Manager Intent details " ,Result)

        return Result

    }

    public async graphapi(){
        var axios = require('axios');
        var qs = require('qs');
        var data = qs.stringify({
            'grant_type': 'client_credentials',
            ' client_id': '9a44974b-9c21-408d-ab91-45e1d854d3f6',
            ' client_secret': '6-A.n4~brBrIHxz6Xdd03b-pFCYz8T-I25',
            ' scope': 'https://graph.microsoft.com/.default' 
        });
        var config = {
            method: 'post',
            url: 'https://login.microsoftonline.com/82f26667-2afe-4c78-b49d-6d0619d6a76d/oauth2/v2.0/token',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded', 
                'Cookie': 'fpc=AljcZK5Bf_xCsxm7JrCf_-BPVc6WAQAAANPgYdoOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd'
            },
            data : data
        };

        let Result = axios(config)
        //console.log("--------------->bearer Token **** " ,Result)

        return Result

    }
   
   
}