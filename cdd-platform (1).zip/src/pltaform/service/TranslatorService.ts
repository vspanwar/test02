import { LoggingUtil } from './../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { Console } from 'console';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';

const axios = require('axios');

export class TranslatorService  {

    private static instance: TranslatorService;
    private static baseUrl = 'https://api.cognitive.microsofttranslator.com/translate?api-version=3.0'
    private static detectUrl ='https://api.cognitive.microsofttranslator.com/detect?api-version=3.0'
    private static region = 'northcentralus'
    
   
    constructor() { 
    }

    public static getInstance(): TranslatorService {
        if (TranslatorService.instance == null) {
            TranslatorService.instance = new TranslatorService()
        }
        return TranslatorService.instance;
    }

    public async translate(text:any , to:any, from?:any){

        if(to != 'en')  
        {
            console.log("Inside if in ts")
            const host = 'https://api-nam.cognitive.microsofttranslator.com';
            const path = '/translate?api-version=3.0';
            const params = '&to=';
         
            const url = host + path + params + to;
            
            var res = await fetch(url, {
                method: 'POST',
                body: JSON.stringify([{ Text: text }]),
                headers: {
                    'Content-Type': 'application/json',
                    //'Ocp-Apim-Subscription-Key':await KeyVaultService.getInstance().getKey("TanslatorToken"),
                    'Ocp-Apim-Subscription-Key':'9fb7d3b4dba842d3a2f1b05c6a5e24ae',
                    
                    'Ocp-Apim-Subscription-Region': TranslatorService.region
                }
            });

            if (!res.ok) {
                throw new Error('Call to translation services failed.'+await res);
            }

            var responseBody = await res.json();
            console.log(responseBody,"translation")

            if (responseBody && responseBody.length > 0) {
                console.log(responseBody[0].translations[0].text,"translation11")
                return responseBody[0].translations[0].text;
            } else {
                return text;
            }
        }
        else{
            console.log("inside else in ts")
            return text;
        }

    }


    public async detect(text:any){
        let url = TranslatorService.detectUrl
        var header = {
            //'Ocp-Apim-Subscription-Key': TranslatorService.key,
            'Content-Type': 'application/json',
        }
        
        let response =await HttpUtil.post(url, [{"Text":text}], header)
        return response
    }

}