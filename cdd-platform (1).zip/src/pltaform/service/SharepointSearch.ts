import { LoggingUtil } from '../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';



export class SharepointSearch {

    private static instance: SharepointSearch;
    constructor() {
    }

    public static getInstance(): SharepointSearch {
        if (SharepointSearch.instance == null) {
            SharepointSearch.instance = new SharepointSearch()
        }
        return SharepointSearch.instance;
    }

    /**
     * SharePoint service Testing Rest Api 
     * get token and then use it to find data
     */




    public async ItData(Application: any,coloumn:String) {

        var axios = require('axios');

        let result1 = await SharepointSearch.getInstance().SharePointApi()
        console.log("Bearer Token value", result1.data.access_token)

        var config = {
            method: 'get',
            url: 'https://duracell.sharepoint.com/sites/External/itsolutions/_api/web/lists/GetByTitle(\'Application Portfolio Management\')/items?$filter=startswith(Title, \'' +Application+'\')&filter=Active eq 1&$select='+coloumn,
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + result1.data.access_token
            }
        };

        //console.log("configuration of api---===+++", config)

        let Result = await axios(config)
        console.log("--------------->pSharepoint Details **** ", Result)
        console.log("pSharepoint Details **** ", Result.data.value[0][`${coloumn}`])
        let response = Result.data.value[0][`${coloumn}`]

        return response

    }

    public async ExpandedItData(Application: any,coloumn:String) {

        var axios = require('axios');

        let result1 = await SharepointSearch.getInstance().SharePointApi()
        console.log("Bearer Token value", result1.data.access_token)

        var config = {
            method: 'get',
            url:'https://duracell.sharepoint.com/sites/External/itsolutions/_api/web/lists/GetByTitle(\'Application Portfolio Management\')/items?$filter=startswith(Title, \''+Application+'\')&filter=Active eq 1&$select=*,'+coloumn+'/Title&$expand='+coloumn,
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + result1.data.access_token
            }
        };

        //console.log("configuration of api---===+++", config)

         let Result = await axios(config)
         //console.log("--------------->pSharepoint Details **** ", Result)
         console.log("pSharepoint Details **** ", Result.data.value)
         let response = Result.data.value[0][`${coloumn}`]
          
         return Result.data.value
        //return response

    }

    public async Multiple_Data(Application: any) {

        var axios = require('axios');
        try{
            let result1 = await SharepointSearch.getInstance().SharePointApi()
            //console.log("Bearer Token value", result1.data.access_token)

            var config = {
                method: 'get',
                url:'https://duracell.sharepoint.com/sites/External/itsolutions/_api/web/lists/GetByTitle(\'Application Portfolio Management\')/items?$filter=startswith(Title,\''+Application+'\')&filter=Active eq 1&$select=BusinessProcess,Vendor,ITContact/Title,ITContact/EMail,BusinessOwnerKeyUser/Title,BusinessOwnerKeyUser/EMail,BackupOwner/Title&$expand=ITContact,BusinessOwnerKeyUser,BackupOwner',
                headers: {
                    'Accept': 'application/json',
                    'Authorization': 'Bearer ' + result1.data.access_token
                }
            };

            //console.log("configuration of api---===+++", config)
            let Result = await axios(config)
            console.log("Sharepoint Details **** ", Result.data.value[0])

            return Result.data.value[0]
        }catch(err){
            console.log("Error in sharepoint api - ",err);
            return "failed"
        }

    }

    public async GetUserID(usermail: any) {
        var axios = require('axios');
        try{
            let token = await SharepointSearch.getInstance().GetTokenforADGroup()
            var config = {
            method: 'get',
            url: 'https://graph.microsoft.com/beta/users?$filter=mail eq \''+usermail+'\' &$count=true',
            headers: { 
                'ConsistencyLevel': 'eventual', 
                'Authorization': 'Bearer '+token
            }
            };

            let Result = await axios(config)
            console.log("GetUserID Details **** ", Result.data.value[0])
            return Result.data.value[0].id
        }catch(err){
            console.log("Error in GetUserID api - ",err);
            return "failed"
        }    

    }

    public async GetGroupID(group: any) {
        var axios = require('axios');
        try{
            let token = await SharepointSearch.getInstance().GetTokenforADGroup()
            var config = {
            method: 'get',
            url: 'https://graph.microsoft.com/v1.0/groups?$filter = displayName eq \''+group+'\'',
            headers: { 
                'ConsistencyLevel': 'eventual', 
                'Authorization': 'Bearer '+token
            }
            };

            let Result = await axios(config)
            console.log("GetGroupID Details **** ", Result.data.value[0])
            return Result.data.value[0].id
        }catch(err){
            console.log("Error in GetGroupID api - ",err);
            return "failed"
        }    

    }

    public async GetGroupMembers(groupid: any) {
        var axios = require('axios');
        try{
            let token = await SharepointSearch.getInstance().GetTokenforADGroup()
            var config = {
            method: 'get',
            url: 'https://graph.microsoft.com/v1.0/groups/'+groupid+'/members?$select = id',
            headers: { 
                'ConsistencyLevel': 'eventual', 
                'Authorization': 'Bearer '+token
            }
            };

            let Result = await axios(config)
            //console.log("GetGroupID Details **** ", Result.data.value[0])
            return Result.data.value
        }catch(err){
            console.log("Error in GetGroupID api - ",err);
            return "failed"
        }    

    }

    public async GetUserGroupList(userid: any) {
        var axios = require('axios');
        try{
            let token = await SharepointSearch.getInstance().GetTokenforADGroup()
            var config = {
            method: 'get',
            url: 'https://graph.microsoft.com/beta/users/'+userid+'/memberOf?$select = id',
            headers: { 
                'ConsistencyLevel': 'eventual', 
                'Authorization': 'Bearer '+token
            }
            };

            let Result = await axios(config)
            //console.log("GetGroupID Details **** ", Result.data.value[0])
            return Result.data.value
        }catch(err){
            console.log("Error in GetGroupID api - ",err);
            return "failed"
        }    

    }
    



    public async SharePointApi() {
        var axios = require('axios');
        var qs = require('qs');
        var data = qs.stringify({
            'grant_type': 'client_credentials',
            ' client_id': 'ab147343-1f06-42e3-9b61-76788b7029cf@82f26667-2afe-4c78-b49d-6d0619d6a76d',
            ' client_secret': 'sS38Q~7iYZLpk4xshE6ie0j5c_vjfYpOskJPbcIz',
            'resource': '00000003-0000-0ff1-ce00-000000000000/duracell.sharepoint.com@82f26667-2afe-4c78-b49d-6d0619d6a76d'
        });
        var config = {
            method: 'post',
            url: 'https://accounts.accesscontrol.windows.net/82f26667-2afe-4c78-b49d-6d0619d6a76d/tokens/OAuth/2',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Cookie': 'esctx=AQABAAAAAAD--DLA3VO7QrddgJg7WevrDMMVI_wQ-cN-8dU9G43KUm5da0Qy6_s6leAr60SNjX-csZIZGvwk83RnTXyfp1kYvN7IUum5Lz9RuGjhhL2l02hdcO7GsRhqLc-hXDuWdYXa2Pe9KDPRqMU1JZN4wNnEzG_22MXbp4TNvpRN7DsUzujE_OO8cPK4pOyj3lFvn40gAA; fpc=As2Da1K0219DvhPGuiWrLw3Tf0OUAQAAAASyn9oOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd'
            },
            data: data
        };

        let Result = await axios(config)

       // console.log("--------------->bearer Token **** ", Result)

        return Result

    }

    public async GetTokenforADGroup() {
        var axios = require('axios');
        var qs = require('qs');
        var data = qs.stringify({
            'grant_type': 'client_credentials',
            'client_id': '67a235a6-0ffd-4e72-8a85-7c65c1ce3caa',
            'client_secret': 'uFu8Q~B~PiFuQ2R4VnkY1dUnc7aZRh9DzK6FHbBZ',
            'scope': 'https://graph.microsoft.com/.default'
        });
        var config = {
            method: 'post',
            url: 'https://login.microsoftonline.com/82f26667-2afe-4c78-b49d-6d0619d6a76d/oauth2/v2.0/token',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            data: data
        };

        let Result = await axios(config)

       // console.log("--------------->bearer Token **** ", Result)

        return Result.data.access_token

    }


}