import { LoggingUtil } from './../../common/utils/log4js';
const tenantCfg = require('../../../resources/config/tenant.json');

export class TenantService  {
     
     
     public static getTenantCfg () {
      LoggingUtil.log.debug(JSON.stringify(tenantCfg));
       return tenantCfg;
     }

     public static getNlpCfg (jsonFile:string) {
      LoggingUtil.log.debug(`jsonFile ::${jsonFile}`);
       const cfg = require('../../../resources/config/tenants/'+jsonFile );
       //console.log(cfg);
       return cfg;
     }

     public static getDialogCfg (dialogName:string) {
          LoggingUtil.log.debug(`dialogName ::${dialogName}`);
          const token = dialogName.split(".", 3);
          // if(token.length < 2 )
          //    return {}
          try {
               const cfg = require('../../../resources/config/tenants/'
                                   +token[0] + '/dialogs/' +  dialogName +'.json');
               //console.log(cfg);
               return cfg;
          } catch (e) {
               LoggingUtil.log.error(`${dialogName} config not found`);
               return {};
           }
     }


}