import { LoggingUtil } from './../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { Activity, TurnContext } from 'botbuilder';
import { ChatSessionData } from '../model/ChatSessionData';
import { UsecaseSessionData } from '../model/UsecaseSessionData';
const Querystring = require('querystring');

export class AdminService  {


    private static adminService: AdminService;
    

    public static getInstance(): AdminService {
        if (AdminService.adminService == null) {
            AdminService.adminService = new AdminService()
        }
        return AdminService.adminService;
    }

    public async getTenantConfig(): Promise<any> {
        return this.get('/tenant/config/active');
        
    }
    public async getNlpCfg(tenantId:any, botId:any): Promise<any> {
        let config = {'tenantId':tenantId, 'botId':botId}
        return this.get('nlp/nlpconfig/' + tenantId,config);
    }
    public async getDialogCfg (tenantId:any,
                               botId:any,
                               tenantName:string,
                               dialogName:string) : Promise<any>{
        LoggingUtil.log.debug(`dialogName ::${dialogName}`);
        let config = {'tenantId':tenantId,
                      'botId':botId,
                      'tenantName': tenantName,
                      'dialogName':dialogName};
       return this.get('nlp/dialogconfig' + tenantId,config);
   }
   public async logFeedback(payload:any){
       LoggingUtil.log.debug("Admin service logging feedback, Payload: " + JSON.stringify(payload))
       return this.post('feedback/log', payload) 
   }
   public async logUseCaseData(payload:any){

        let response = await this.get('chatHistory/' + payload.conversationId)
        payload['sessionID']=response.sessionID
        payload['region']=response.region
        payload['language']=response.language
        LoggingUtil.log.debug("Admin service passing logging Usecasedata, Payload: " + JSON.stringify(payload))
        return this.post('usecase/log', payload) 
   }
   //to store only chat data
   public async logUseChatHistory(payload:any){
    LoggingUtil.log.debug("Admin service passing logging chathistory , Payload: " + JSON.stringify(payload))
    return this.post('chathistory/log', payload) 
   }

   //to add region and language and ticket number in chat 
   public async updateChatHistory(payload:any){
    
    return this.post('chathistory/update', payload)
   }

   //add ticket number in use case
   public async updateUseCase(payload:any){
       
       return this.post('usecase/update', payload)
   }

   // add usecase data

   public async addUseCase(activity:Partial<Activity>, usecaseName:any){
    let usecase_payload =await UsecaseSessionData.getInstance().startData(activity, usecaseName)
    return this.post('report/usecase/create',usecase_payload);
}

    //add chat history 
    public async addChatHistory(activity:Partial<Activity>){
        let chatPayload= await this.createChatHistoryPayload(activity)
        return this.post('report/usecase/append',chatPayload);
    }

    public async getCurrentIntent(activity:Partial<Activity>)
    {
        let payload = {
            conversationId : activity.conversation.id
        }
        return this.post('report/usecase/getPrevious',payload)
    }



    //create chat history payload
    public async createChatHistoryPayload(activity:Partial<Activity>){
        let payload=await ChatSessionData.getInstance().startData(activity)
        return payload
    }

    public async updateFeedback(payload){
        return this.post('report/usecase/update',payload);
    }
  



    private async get(path, config?:any): Promise<any> {
        let baseUrl = CommonWebPaths.getfullPath(Module.ADMIN);
        let headers = {}
        headers['Content-Type'] = 'application/json'

        try {
            return  await HttpUtil.get(baseUrl + path,headers,config)
        } catch (e) {
            console.log('Error' + JSON.stringify(e))
            return e;
        }

    }

    private async post(path, payload:any,config?:any): Promise<any> {
        let baseUrl = CommonWebPaths.getfullPath(Module.ADMIN);
        let headers = {}
        headers['Content-Type'] = 'application/json'

        try {
            return  await HttpUtil.post(baseUrl + path, payload, headers)
        } catch (e) {
            console.log('Error' + JSON.stringify(e))
            return e;
        }

    }
    public async getdocumentbyId(id: any): Promise<any> {
        let payload={}
        payload['id']=id;
        return this.post('meetingroom/getdocument',payload);
    }

    
    public async createUserSession(payload:any):Promise<any>{
        return this.post('tenant/config/userSession/create',payload);
    }

    public async createSession(payload:any):Promise<any>{
        //let payload=await ChatSessionData.getInstance().startData(activity)

        return this.post('session/userSession/create',payload)
    }

    public async updateSession(convId: string, payload:any, field: string):Promise<any>{
        // let payload = await this.createSessionPayload(context);
        let updatePayload = {
            conversationId:convId,
            updateField:field,
            payload: payload
        } 
        LoggingUtil.log.info("admin service user_queue_perlanguage11:"+JSON.stringify(updatePayload))
        return this.post('session/userSession/update',updatePayload);
    }


    public async logTranscriptToDB(activity:Partial<Activity>){
        // let create_append_field = activity.from.id+"::"+activity.text;
        let create_append_field;

        
            create_append_field = {
                user_text: '',
                bot_response: activity.text,
                requester_id: activity.from.id,
                requester: activity.from.name,
                requester_type: '',
                create_timestamp: new Date()
            }
        
        

        let payload = {
            conversationId:activity.conversation.id,
            appendField:'usecase.transcript',
            appendData:[create_append_field]
        }
        console.log("Transcript::: ", payload)
        return this.post('session/userSession/append',payload);
    }


    //GENESYS CALLBACK API Functions
    private async Callback_token(){
        // const tenant_id = 'b8b1112f-415b-4c2f-95c0-9a02468afb8b'
         let url = "https://login.mypurecloud.ie/oauth/token"
         const  headers ={ 
                'Content-Type': 'application/x-www-form-urlencoded', 
                'Authorization': 'Basic MzYwMDVjOTYtMDQzYy00YmM0LTgzNmMtNDg5OTg3NjlmZmExOkI5ZFZrVTBlQjVGcW9WMGdVMVFnZWswLTJ6WjNrdTdVUk10LV80NXRnT0k='
              }
           
         let body = Querystring['stringify']({
             grant_type : 'client_credentials'
         })

         let res = await HttpUtil.post(url,body,headers)
  
         return res
     }
    public async Callback(PhoneNumber,queId,FirstName,callback_time){

        let token_id = await this.Callback_token()
        

        
        let url = 'https://api.mypurecloud.ie/api/v2/conversations/callbacks'
           const headers =  {
                'Content-Type': 'application/json',
                'Authorization':'Bearer ' + token_id.access_token
            }
 
            let payload = {
                "scriptId": "bbb3f108-655c-4037-8dab-f9370ce7bec7",
                "queueId": queId,
                "callbackUserName": FirstName,
                "callbackNumbers": [PhoneNumber],
                "callbackScheduledTime": callback_time, 
                "countryCode": "",
                "validateCallbackNumbers": true
                }
          console.log(token_id,headers,payload,PhoneNumber,"checkingtoken")
        return HttpUtil.post(url,payload,headers)
    }

    //GENESYS LIVE_CHAT 
      public async fetchToken(){
        let webUrl = "https://api.mypurecloud.ie/api/v2/webchat/guest/conversations";
        // const headers = new Headers({
          
        //   'Content-Type': 'application/json'
        //   // 'Authorization' : 'Bearer ' + environment.tokenGenesys
        // });
        const options = {
          headers: {
            'Content-Type': 'application/json'
          }
        };
        let data = 
        {
          "organizationId": "69ad5769-f309-4c7d-9998-c1b03dbd34af",
          "deploymentId" : "6307605f-e52f-4128-b9d3-a2cd9c37cdcd",
          "routingTarget" : {
            "targetType" : "queue",
            "targetAddress": "InnoHub_ CustomerB_AllOther_Chat"
          },
          "memberInfo" : { 
            "displayName" : "Joe Dirt",
            "avatarImageUrl": "http://some-url.com/JoeDirtsFace",
            "lastName" : "Joe",
            "firstName" : "Dirt",
            "email" : "joe.dirt@tcsddp.com",
            "phoneNumber" : "+12223334444",
            "customFields" : {
              "queueId" : "13c0b58a-ba82-4e96-b9bd-b32b3d22d59a",
              "usecase": "platform.audio.issue",
                  "skill" : "English",
                 "email" : "joe.dirt@tcsddp.com"
            }
          }
        }
        
        
        return HttpUtil.post(webUrl, data, options);
      }
    
      public async connectWithAgent(msg:any,convID:any,memberID:any,token:any){
        //let token_id = await this.fetchToken("Joe Dirt","joe.dirt@example.com")
        //console.log(token_id+"chat token")

        console.log("---->inside call",msg,convID,memberID,token)
        let webUrl = 'https://api.mypurecloud.ie/api/v2/webchat/guest/conversations/'+convID+'/members/'+memberID+'/messages';
        // const headers = new Headers({
          
        //   'Content-Type': 'application/json',
        //   'Authorization' : 'Bearer ' + token 
        // });
        let  headers= {
            'Content-Type': 'application/json',
            'Authorization' : 'Bearer ' + token 
          }
    
        let data ={
          "body" : "USER:" + msg,
          "bodyType" : "standard"
        }
     
        // const options = new RequestOptions({ method: RequestMethod.Post, headers: headers });
        return HttpUtil.post(webUrl, JSON.stringify(data), headers);
      }

    
}

    



