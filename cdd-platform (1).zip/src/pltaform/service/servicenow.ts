// import { LoggingUtil } from '../../common/utils/log4js';
// import { CommonWebPaths } from "../../common/web/CommonWebPaths";
// import { Module } from "../../common/enums/PlatformEnums";
// import { HttpUtil } from "../../common/utils/HttpUtil";
// import { header } from 'express-validator/check';
// import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';



// export class servicenow  {

//     private static instance: servicenow;
//     private static baseUrl = process.env.servicenow_base_url

//     constructor() { 
//     }

//     public static getInstance(): servicenow {
//         if (servicenow.instance == null) {
//             servicenow.instance = new servicenow()
//         }
//         return servicenow.instance;
//     }

   
//     public async getAuth()
//     {
//         let username = await KeyVaultService.getInstance().getKey("servicenowUsername")
//         let password = await KeyVaultService.getInstance().getKey("servicenowToken")
//         let authToken = "Basic " + Buffer.from(username  + ":" + password).toString('base64')
//         LoggingUtil.log.info("Auth check::"+authToken)
//         return authToken

//     }

//     public async CreateTicket( payload:any){ 
//      console.log("Inside create ticket service")
//         let url = servicenow.baseUrl+'/api/now/table/incident?sysparm_display_value=true&sysparm_fields=number&sysparm_input_display_value=true'
//        let body = payload
//        console.log("payload from class"+JSON.stringify(body))   
//        LoggingUtil.log.info("URL Inside create ticket service:"+url)

//         var header = {
//             'cache-control': 'no-cache',
//             'Authorization':  await this.getAuth(),
//             'content-type': 'application/json'
//         }
//         try{
//              LoggingUtil.log.info("header  Inside create ticket service:"+JSON.stringify(header))
//             let response =await HttpUtil.post(url, body, header)
//             if(response.name && response.name=="Error"){
//                 LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
//                 let response1 =await HttpUtil.post(url, body, header)
//                 return response1
                
//             }
//             else{
//                 console.log("***********inside else*********************")
//                 console.log("REsponse in soap service:"+response)
//                 console.log("REsponse in soap service:"+JSON.stringify(response))

//                 return response
//             }
//         }
//         catch(e){
//             return "this is error"
//         }
//     }

//     public async TicketStatus( number:any){ 
//         console.log("Inside update ticket service")
//            let url1 = servicenow.baseUrl+'/api/now/v1/table/incident?sysparm_query=number%3D'
//            let url = url1+number
         
       
//           console.log("inside update service url:"+url)
   
//            var header = {
//                'postman-token': '8ba23e89-7687-d5cb-ab27-fb96131e0c22',
//                'cache-control': 'no-cache',
//                'Authorization': 'Basic VGVjaF9UQ1NfQ2hhdGJvdDpxLnRBNF9GeC1KUzJ',
//                //'Authorization': 'Basic QzEyMjI0NDpTd2VldHlAMjQ1OQ==',
//                'content-type': 'application/json'
//            }
//            try{
//                let response =await HttpUtil.get(url, header)
//                if(response.name && response.name=="Error"){
//                    LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
//                    let response1 =await HttpUtil.get(url, header)
//                    return response1
                   
//                }
//                else{
//                    console.log("***********inside else*********************")
//                    console.log("REsponse in soap service:"+response)
//                    console.log("REsponse in soap service:"+JSON.stringify(response))
   
//                    return response
//                }
//            }
//            catch(e){
//                return "this is error"
//            }
//        }
   
//     public async getfieldValue( url:any) { 
//         //let url = url
      
//          console.log("url value in getfieldValue:"+url)
    
 
//         var header = {
//             'postman-token': '8ba23e89-7687-d5cb-ab27-fb96131e0c22',
//             'cache-control': 'no-cache',
//             'Authorization': 'Basic VGVjaF9UQ1NfQ2hhdGJvdDpxLnRBNF9GeC1KUzJANTZf',
//             //'Authorization': 'Basic QzEyMjI0NDpTd2VldHlAMjQ1OQ==',
//             'content-type': 'application/json'
//         }
//         try{
//             let response =await HttpUtil.get(url, header)
//             if(response.name && response.name=="Error"){
//                 LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
//                 let response1 =await HttpUtil.get(url, header)
//                 return response1
                
//             }
//             else{
//                 console.log("***********inside else*********************")
//                 console.log("REsponse in soap service:"+response)
//                 console.log("REsponse in soap service:"+JSON.stringify(response))
               
//                 return response
//             }
//         }
//         catch(e){
//             return "this is error"
//         }
//     }
  
// }

////////////////////////////////////////
import { LoggingUtil } from '../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';



export class servicenow  {

    private static instance: servicenow;
   private static baseUrl = 'https://duracelldev1.service-now.com'
   //process.env.servicenow_base_url
   // 'https://duracelldev1.service-now.com'
    constructor() { 
    }

    public static getInstance(): servicenow {
        if (servicenow.instance == null) {
            servicenow.instance = new servicenow()
        }
        return servicenow.instance;
    }

   
    public async getAuth()
    {
        let username = 'botframework'
        //await KeyVaultService.getInstance().getKey("servicenowUsername")
       
        let password = 'PjEN2AP9bqrj2^Q9*PAA'
        //await KeyVaultService.getInstance().getKey("servicenowToken")
       
        let authToken = "Basic " + Buffer.from(username  + ":" + password).toString('base64')
        LoggingUtil.log.info("Auth check::"+authToken)
        return authToken

    }

    public async CreateTicket( payload:any){ 
     console.log("Inside create ticket service")
        let url = servicenow.baseUrl+'/api/now/table/incident?sysparm_display_value=true&sysparm_fields=number&sysparm_input_display_value=true'
       let body = payload
       console.log("payload from class"+JSON.stringify(body))   
       LoggingUtil.log.info("URL Inside create ticket service:"+url)

        var header = {
            'cache-control': 'no-cache',
            'Authorization':  await this.getAuth(),
            'content-type': 'application/json'
        }
        try{

            let response =await HttpUtil.post(url, body, header)
            if(response.name && response.name=="Error"){
                LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
                let response1 =await HttpUtil.post(url, body, header)
                return response1
                
            }
            else{
                console.log("***********inside else*********************")
                console.log("REsponse in soap service:"+response)
                console.log("REsponse in soap service:"+JSON.stringify(response))

                return response
            }
        }
        catch(e){
            return "this is error"
        }
    }

    public async TicketStatus( number:any){ 
        console.log("Inside update ticket service")
           let url1 = servicenow.baseUrl+'/api/now/v1/table/incident?sysparm_query=number%3D'
           let url = url1+number
         
       
          console.log("inside update service url:"+url)
   
           var header = {
               'postman-token': '8ba23e89-7687-d5cb-ab27-fb96131e0c22',
               'cache-control': 'no-cache',
               'Authorization': 'Basic VGVjaF9UQ1NfQ2hhdGJvdDpxLnRBNF9GeC1KUzJANTZf',
               //'Authorization': 'Basic QzEyMjI0NDpTd2VldHlAMjQ1OQ==',
               'content-type': 'application/json'
           }
           try{
               let response =await HttpUtil.get(url, header)
               if(response.name && response.name=="Error"){
                   LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
                   let response1 =await HttpUtil.get(url, header)
                   return response1
                   
               }
               else{
                   console.log("***********inside else*********************")
                   console.log("REsponse in soap service:"+response)
                   console.log("REsponse in soap service:"+JSON.stringify(response))
   
                   return response
               }
           }
           catch(e){
               return "this is error"
           }
       }
   
    public async getfieldValue( url:any) { 
        //let url = url
      
         console.log("url value in getfieldValue:"+url)
    
 
        var header = {
            'postman-token': '8ba23e89-7687-d5cb-ab27-fb96131e0c22',
            'cache-control': 'no-cache',
            'Authorization': 'Basic VGVjaF9UQ1NfQ2hhdGJvdDpxLnRBNF9GeC1KUzJANTZf',
            //'Authorization': 'Basic QzEyMjI0NDpTd2VldHlAMjQ1OQ==',
            'content-type': 'application/json'
        }
        try{
            let response =await HttpUtil.get(url, header)
            if(response.name && response.name=="Error"){
                LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
                let response1 =await HttpUtil.get(url, header)
                return response1
                
            }
            else{
                console.log("***********inside else*********************")
                console.log("REsponse in soap service:"+response)
                console.log("REsponse in soap service:"+JSON.stringify(response))
               
                return response
            }
        }
        catch(e){
            return "this is error"
        }
    }
   
}

