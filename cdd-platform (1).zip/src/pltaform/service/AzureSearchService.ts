import { LoggingUtil } from '../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';
import { odata, SearchClient, SearchIndex, SearchIndexClient, SearchIndexerClient, SearchIndexerSkillset, SearchIndexStatistics } from '@azure/search-documents';
import { url } from 'inspector';
import { DialogUtils } from '../dialogs/impl/DialogUtils';
const axios = require('axios');


const endpoint = process.env.SEARCH_API_ENDPOINT || "";
const apiKey = process.env.SEARCH_API_ADMIN_KEY || "";
const indexName = "example-index-sample-1";



export class AzureSearchService {

  private static instance: AzureSearchService;

  constructor() {
  }

  public static getInstance(): AzureSearchService {
    if (AzureSearchService.instance == null) {
      AzureSearchService.instance = new AzureSearchService()
    }
    return AzureSearchService.instance;
  }


  /**
   * Graph API Services : 
   * get taoken and then using user email id filter it
   */



   public async graphapi(){
    var axios = require('axios');
    var qs = require('qs');
    var data = qs.stringify({
        'grant_type': 'client_credentials',
        ' client_id': '9a44974b-9c21-408d-ab91-45e1d854d3f6',
        ' client_secret': '6-A.n4~brBrIHxz6Xdd03b-pFCYz8T-I25',
        ' scope': 'https://graph.microsoft.com/.default' 
    });
    var config = {
        method: 'post',
        url: 'https://login.microsoftonline.com/82f26667-2afe-4c78-b49d-6d0619d6a76d/oauth2/v2.0/token',
        headers: { 
            'Content-Type': 'application/x-www-form-urlencoded', 
            'Cookie': 'fpc=AljcZK5Bf_xCsxm7JrCf_-BPVc6WAQAAANPgYdoOAAAA; stsservicecookie=estsfd; x-ms-gateway-slice=estsfd'
        },
        data : data
    };

    let Result = axios(config)

    console.log("--------------->bearer Token **** " ,Result)

    return Result

  }


  public async PersonalIntent(email:any){

    var axios = require('axios');

    let result1 = await AzureSearchService.getInstance().graphapi()
    console.log("Bearer Token value", result1.data.access_token)

    var config = {
    method: 'get',
    url: 'https://graph.microsoft.com/Beta/users?$filter=mail eq \''+ email +'\'',
    headers: { 
        'Authorization': 'Bearer ' + result1.data.access_token
    }
    };

    console.log("configuration of api---===+++",config)

    let Result = axios(config)

    console.log("--------------->personal Intent details **** " ,Result)

    return Result

}


  /**
   * 
   * Create ;update ;delete indexing
   */


  public async CreateIndex(indexName: string, client: SearchIndexClient) {
    console.log(`Creating Index Operation`);
  }

  public async getAndUpdateIndex(indexName: string, client: SearchIndexClient) {
    console.log(`Get And Update Index Operation`);
    const index: SearchIndex = await client.getIndex(indexName);
    index.fields.push({
      type: "Edm.DateTimeOffset",
      name: "lastUpdatedOn",
      filterable: true
    });
    return await client.createOrUpdateIndex(index);
  }


  public async getIndexStatistics(indexName: string, client: SearchIndexClient) {
    console.log(`Get Index Statistics Operation`);
    const statistics: SearchIndexStatistics = await client.getIndexStatistics(indexName);
    console.log(`Document Count: ${statistics.documentCount}`);
    console.log(`Storage Size: ${statistics.storageSize}`);
  }

  public async deleteIndex(indexName: string, client: SearchIndexClient) {
    console.log(`Deleting Index Operation`);
    await client.deleteIndex(indexName);
  }





  /**
   * Creating SkillSeT ,Update Skillset , DeleteSkillSet
  */

  public async createSkillset(skillsetName: string, client: SearchIndexerClient) {
    console.log(`Creating Skillset Operation`);
  }

  public async getAndUpdateSkillset(skillsetName: string, client: SearchIndexerClient) {
    console.log(`Get And Update Skillset Operation`);
  }

  public async deleteSkillset(skillsetName: string, client: SearchIndexerClient) {
    console.log(`Deleting Skillset Operation`);
    await client.deleteSkillset(skillsetName);
  }

  //querying the result

  public async querying2(searchText: String) {
    console.log("yes you are getting-->", searchText)
    
    var axios = require('axios');
    var data = '';

    var config = {
      method: 'get',
      url: 'https://duracell-cognitive-search.search.windows.net/indexes/sharepoint-policyindex/docs?api-version=2021-04-30-Preview&queryType=semantic&captions=extractive&answers=extractive%7Ccount-3&semanticConfiguration=semantic-search&queryLanguage=en-US&search=' + searchText,
      headers: {
        'api-key': 'kL9f1zvewle8zzpdKCAkrOzQ1tKOfIrgSNVx6AjcTNAzSeDoFIU8',
        'Content-Type': 'application/json'
      },
      data: data
    };

    let Result = await axios(config)

    // console.log("--------------->" ,Result.data["value"][0]["@search.captions"][0][ "text"])
    // console.log("--------------->" ,Result.data)
    //console.log("--------------->" ,Result)
    //return Result.data["value"][0]["@search.captions"][0][ "text"]
    return Result.data
  }

  public async querying(searchText: String) {
    console.log("yes you are getting-->", searchText)
    
    var axios = require('axios');
    var data = '';

    var config = {
      method: 'get',
      url: 'https://duracell-cognitive-search.search.windows.net/indexes/hrpolicy-index/docs?api-version=2021-04-30-Preview&queryType=semantic&captions=extractive&answers=extractive%7Ccount-3&semanticConfiguration=semantic-search&queryLanguage=en-US&search=' + searchText,
      headers: {
        'api-key': 'kL9f1zvewle8zzpdKCAkrOzQ1tKOfIrgSNVx6AjcTNAzSeDoFIU8',
        'Content-Type': 'application/json'
      },
      data: data
    };

    let Result = await axios(config)

    // console.log("--------------->" ,Result.data["value"][0]["@search.captions"][0][ "text"])
    // console.log("--------------->" ,Result.data)
    //console.log("--------------->" ,Result)
    //return Result.data["value"][0]["@search.captions"][0][ "text"]
    return Result.data
  }

  public async validateurl(resp: any,excludedfolder: any){
    try{
      let length = resp.length;
      let ex_len = excludedfolder.length;
      let filteredarray=[];
      let path;
      let date;
      for(var i=0;i<length;i++){
        path=(resp[i].metadata_spo_item_path).toLowerCase();
        date=resp[i].metadata_spo_item_last_modified;
        if(path.includes("archive")){
          console.log("path includes archive folder in a "+i+" response, "+path);
        }else if(path.includes("drafts")){
          console.log("path includes draft folder in a "+i+" response, "+path);
        }else if(path.includes("global newsletter")){
          console.log("path includes global newsletter folder in a "+i+" response, "+path);
        }else if(path.includes("recognition")){
          console.log("path includes recognition folder in a "+i+" response, "+path);
        }else if(path.includes("employee announcements")){
          console.log("path includes employee announcements folder in a "+i+" response, "+path);
        }else if(date.includes("2017") || date.includes("2018") || date.includes("2019") || date.includes("2016")){
          console.log("date includes 2017,2018,2019,2016 in a "+i+" response, "+date);
        }else{
          let v = "";
          for(var j=0;j<ex_len;j++){
            if(path.includes(excludedfolder[j])){
              console.log("path includes " +excludedfolder[j] +" folder in a "+i+" response, "+path);
              v="exclude"
            }
          }
          if(v!="exclude")
            filteredarray.push(resp[i]);
        }
      }
      return filteredarray;
    }catch(err){
      console.log("error in validate url policy file - ",err);
      return null;
    }
  }


}

