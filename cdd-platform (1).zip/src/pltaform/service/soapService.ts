// import { LoggingUtil } from '../../common/utils/log4js';
// import { CommonWebPaths } from "../../common/web/CommonWebPaths";
// import { Module } from "../../common/enums/PlatformEnums";
// import { HttpUtil } from "../../common/utils/HttpUtil";
// import { header } from 'express-validator/check';
// import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';
// import { logger } from '@azure/identity';


// export class soapService  {

//     private static instance: soapService;
//     private static baseUrl = process.env.sap_base_URL
//     //'https://extraneteca.duracell.com/sap/bc/srt/scs/sap/'
//     //process.env.sap_base_URL
 
//     constructor() { 
//     }

//     public static getInstance(): soapService {
//         if (soapService.instance == null) {
//             soapService.instance = new soapService()
//         }
//         return soapService.instance;
//     }

//     public async xmltojson (payload:any)
//     {
//         var parseString = require('xml2js').parseString; 
//         let response = ""
      
//         parseString(payload, function (err, result) {    
//         console.log("Error in convert xmltojson :  "+err)
//         response = result        
//         });
//         return response
       
//     }
//     public async getAuth()
//     {
//         let username = await KeyVaultService.getInstance().getKey("SAPusername")
//         //'1DESKROBOT'
//         let password =await KeyVaultService.getInstance().getKey("saptoken")
//         // 'fuCvjBTsx&%7NF'
//         let authToken = "Basic " + Buffer.from(username  + ":" + password).toString('base64')
//         LoggingUtil.log.info("Auth check::"+authToken)
//         return authToken

//     }

//     public async getAuthResponse( payload:any, url1 : any){ 
//       //  console.log("id in soap service"+id)   
//         let url = soapService.baseUrl+url1
//         let body = payload
//         LoggingUtil.log.info("URL in auth from app:::::::"+url)

//         var header = {
    
//         'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
//         'cache-control': 'no-cache',
//         'Authorization': await this.getAuth(),
//         'content-type': 'application/soap+xml; charset=utf-8'
        
//         }

//         LoggingUtil.log.info("Auth code ::::"+JSON.stringify(header))
//         try{
//             let response =await HttpUtil.post(url, body, header)
//             if(response.name && response.name=="Error"){
//                 LoggingUtil.log.debug("**-------------------Error in 1st attempt-----------------------**")
//                 let response1 =await HttpUtil.post(url, body, header)
//                 return response1
                
//             }
//             else{
//                 console.log("***********inside else*********************")
//                 //console.log("REsponse in soap service:"+response)
//                 return response
//             }
//         }
//         catch(e){
//             return "this is error"
//         }
//     }


//     public async getPODetails(payload:any,url1:any){ 
          
//         let url = soapService.baseUrl+url1        
//         let body = payload         
//          console.log("payload from class"+body) 
//         LoggingUtil.log.info("URL in getpo from app:::::::"+url)

//          // console.log("inside soap service url:"+url) 

//           var header = {      
//           'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
//           'cache-control': 'no-cache',
//           'Authorization': await this.getAuth(),
//           'content-type': 'application/soap+xml; charset=utf-8'             
  
//           }

//           try{
//               let response =await HttpUtil.post(url, body, header)
//               if(response.name && response.name=="Error"){
//                   LoggingUtil.log.debug("**-------------------Error in 1st attempt og get po details-----------------------**")
//                   let response1 =await HttpUtil.post(url, body, header)
   
//                   return response1                  
//               }
//               else{
//                   console.log("***********inside else*********************")                  
                 
//                   return response
//               }
//           }
//           catch(e){
//               return "this is error"
//           }
//       }


//       public async PostGR(payload:any,url1:any){ 
//         //console.log("po_number inside the getpodetails  : "+po_number)   
//        let url = soapService.baseUrl+url1        
//        let body = payload         
//         console.log("payload from class"+body) 
//         LoggingUtil.log.info("URL in postgr from app:::::::"+url)

//         // console.log("inside soap service url:"+url) 

//          var header = {      
//          'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
//          'cache-control': 'no-cache',
//          'Authorization': await this.getAuth(),
//          'content-type': 'application/soap+xml; charset=utf-8'             
 
//          }

//          try{
//              let response =await HttpUtil.post(url, body, header)
//              if(response.name && response.name=="Error"){
//                  LoggingUtil.log.debug("**-------------------Error in 1st attempt of post gr-----------------------**")
//                  let response1 =await HttpUtil.post(url, body, header)
  
//                  return response1                  
//              }
//              else{
//                  console.log("***********inside else*********************")                  
                
//                  return response
//              }
//          }
//          catch(e){
//              return "this is error"
//          }
//      }

    
// }

/////////////////////////////////////////////////
import { LoggingUtil } from '../../common/utils/log4js';
import { CommonWebPaths } from "../../common/web/CommonWebPaths";
import { Module } from "../../common/enums/PlatformEnums";
import { HttpUtil } from "../../common/utils/HttpUtil";
import { header } from 'express-validator/check';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';
import { logger } from '@azure/identity';


export class soapService  {

    private static instance: soapService;
    private static baseUrl = 'https://extraneteca.duracell.com/sap/bc/srt/scs/sap/'
  
    constructor() { 
    }

    public static getInstance(): soapService {
        if (soapService.instance == null) {
            soapService.instance = new soapService()
        }
        return soapService.instance;
    }

    public async xmltojson (payload:any)
    {
        var parseString = require('xml2js').parseString; 
        let response = ""
      
        parseString(payload, function (err, result) {    
        console.log("Error in convert xmltojson :  "+err)
        response = result        
        });
        return response
       
    }
    public async getAuth()
    {
        let username = '1DESKROBOT'
        let password = 'fuCvjBTsx&%7NF'
    
        let authToken = "Basic " + Buffer.from(username  + ":" + password).toString('base64')
        LoggingUtil.log.info("Auth check::"+authToken)
        return authToken

    }

    public async getAuthResponse( payload:any, url1 : any){ 
      //  console.log("id in soap service"+id)   
        let url = soapService.baseUrl+url1
        let body = payload
        LoggingUtil.log.info("URL in auth from app:::::::"+url)
        LoggingUtil.log.info("PAyload in auth:"+JSON.stringify(payload))

        var header = {
    
        'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
        'cache-control': 'no-cache',
        'Authorization': await this.getAuth(),
        'content-type': 'application/soap+xml; charset=utf-8'
        
        }

        LoggingUtil.log.info("Auth code ::::"+JSON.stringify(header))
        try{
            let response =await HttpUtil.post(url, body, header)
            if(response.name && response.name=="Error"){
                LoggingUtil.log.debug("**------Error in PO check 1st attempt------**")
                let response1 =await HttpUtil.post(url, body, header)
                LoggingUtil.log.info("Auth response1 ::::"+JSON.stringify(response1))
                return response1
                
            }
            else{
                console.log("****PO check API success****")
                //console.log("REsponse in soap service:"+response)
                return response
            }
        }
        catch(e){
            return "this is error"
        }
    }


    public async getPODetails(payload:any,url1:any){ 
          
        let url = soapService.baseUrl+url1        
        let body = payload         
         console.log("payload from class "+body) 
        LoggingUtil.log.info("URL in getpo from app:::::::"+url)
        LoggingUtil.log.info("PAyload in getpo: "+(payload))

         // console.log("inside soap service url:"+url) 

          var header = {      
          'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
          'cache-control': 'no-cache',
          'Authorization': await this.getAuth(),
          'content-type': 'application/soap+xml; charset=utf-8'             
  
          }

          try{
              let response =await HttpUtil.post(url, body, header)
              if(response.name && response.name=="Error"){
                  LoggingUtil.log.debug("**-----------Error in 1st attempt of get po details------------**")
                  let response1 =await HttpUtil.post(url, body, header)
   
                  return response1                  
              }
              else{
                  console.log("********inside else of get PO*********")                  
                 
                  return response
              }
          }
          catch(e){
              return "this is error"
          }
      }


      public async PostGR(payload:any,url1:any){ 
        //console.log("po_number inside the getpodetails  : "+po_number)   
       let url = soapService.baseUrl+url1        
       let body = payload         
        console.log("payload from class in poST gr"+body) 
        LoggingUtil.log.info("URL in postgr from app:::::::"+url)

        // console.log("inside soap service url:"+url) 

         var header = {      
         'postman-token': '6bf65afe-3786-2b2f-8a6d-7bd14d306919',
         'cache-control': 'no-cache',
         'Authorization': await this.getAuth(),
         'content-type': 'application/soap+xml; charset=utf-8'             
 
         }

         try{
             let response =await HttpUtil.post(url, body, header)
             if(response.name && response.name=="Error"){
                 LoggingUtil.log.debug("**-------Error in 1st attempt of post gr--------**")
                 let response1 =await HttpUtil.post(url, body, header)
  
                 return response1                  
             }
             else{
                 console.log("*******inside else in POST GRS*******")                  
                
                 return response
             }
         }
         catch(e){
             return "this is error"
         }
     }

    
}



