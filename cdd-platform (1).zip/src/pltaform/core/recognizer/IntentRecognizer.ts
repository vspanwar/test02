import { IntentResult } from './../../../common/utils/nlp/IntentResult';
import { Luis } from '../../../common/utils/nlp/impl/Luis';
import { BaseRecognizer } from '../../../common/utils/nlp/BaseRecognizer';
import { CompositeRecognizer } from '../../../common/utils/nlp/impl/CompositeRecognizer';
import { AbstractHandler } from '../../../common/utils/handler/PlatformHandler';
// const { LuisRecognizer } = require('botbuilder-ai');

export class RecognizerFactory {

    //private static luisRegCreator = new LuisRecognizerCreator();
    

    // private static instance: IntentRecognizer;
    
    // public static getInstance(): IntentRecognizer {
    //   if (IntentRecognizer.instance == null) {
    //     IntentRecognizer.instance = new IntentRecognizer();
    //   }
    //   return IntentRecognizer.instance;
    // }
  
    /**
     *
     * @param tenantId 
     * @param botId 
     */
    public static  getRecognizer(tenantId:string,bot:any): BaseRecognizer {
        return new CompositeRecognizer(bot);
    }
}






