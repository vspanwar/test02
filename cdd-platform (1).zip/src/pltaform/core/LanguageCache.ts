import { LoggingUtil } from './../../common/utils/log4js';
import { BasePlatformBot } from './bot/BasePlatformBot';
import { BaseCache } from './../../common/core/BaseCache';
import { ActivityHandler, BotFrameworkAdapter } from 'botbuilder';
import { Module } from '../../common/enums/PlatformEnums';

export class LanguageCache {
    private cache: Map<any, any>;
    public static instance: LanguageCache;
    // private adaptorCache: Map<string, BotFrameworkAdapter>;
 
    private constructor() { 
        this.cache = new Map<any, any>();
    }

    public static getInstance(): LanguageCache {
        if (LanguageCache.instance == null) {
            LanguageCache.instance = new LanguageCache();
        }
        return LanguageCache.instance;
      }

    public addBotLanguage(conversationID: any, language: any):any {
        console.log("0000000000000000",conversationID,language);
        this.cache.set(conversationID,language);
        // console.log(`[addBot] cache-size: ${this.cache.size}`);
    }

    public getBotLanguage(conversationID: any) {
        // console.log(`[getBot] botId: ${botId}`);
        // logger.info(`[getBotLanguage] conversationID: ${conversationID}`)
        return this.cache.get(conversationID);
    }

    public getBotCache(): Map<any, any> {
        return this.cache;
    }

    public containsBot(conversationID: string): boolean {
        return this.cache.has(conversationID)
    }

    public removeBot(conversationID: string) {
        this.cache.delete(conversationID);
    }

    // public addAdaptor(botId: string, adaptor: BotFrameworkAdapter) {
    //     // console.log(`[addBot] botId: ${botId}`);
    //     this.adaptorCache.set(botId, adaptor);
    //     // console.log(`[addBot] cache-size: ${this.cache.size}`);
    // }

    // public getAdaptor(botId: string): BotFrameworkAdapter {
    //     // console.log(`[getBot] botId: ${botId}`);
    //     return this.adaptorCache.get(botId);
    // }
}