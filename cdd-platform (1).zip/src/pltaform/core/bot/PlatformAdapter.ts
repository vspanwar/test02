import { CddTranscriptLogger } from './../../../common/utils/CddTranscriptLogger';
import { PlatformApplicationContext } from './../PlatformApplicationContext';
import { BotFrameworkAdapter, BotFrameworkAdapterSettings, WebRequest, WebResponse, TurnContext, ConversationState, TranscriptLoggerMiddleware, ShowTypingMiddleware, ConsoleTranscriptLogger, TranscriptLogger, Activity } from 'botbuilder';
import { RequestData } from '../../model/RequestData';
import { LoggingUtil } from '../../../common/utils/log4js';
import { DefaultTranslatorMiddleware } from './Translator/DefaultTranslatorMiddleware';

export class PlatformAdapter extends BotFrameworkAdapter {
    public constructor(settings?: Partial<BotFrameworkAdapterSettings>) {
        super(settings);
        // super.use( this.middleWareHook);
        super.use(new TranscriptLoggerMiddleware(new CddTranscriptLogger()));
        super.use(new ShowTypingMiddleware());
        super.use(new DefaultTranslatorMiddleware());
        super.onTurnError = this.onTurnErrorHandler;
    }

    public async process(req: WebRequest,
        res: WebResponse,
        logic: (context: TurnContext) => Promise<any>): Promise<void> {
            this.preProcess();
            super.processActivity(req,res,logic);
            this.postProcess();
    }


    private preProcess(){
        LoggingUtil.log.debug('preProcess');
    }

    private postProcess(){
        LoggingUtil.log.info('postProcess ------');
        const data =  PlatformApplicationContext.getInstance().getRequestData();
        LoggingUtil.log.info('webRequest:' + data.webRequest);
        LoggingUtil.log.info('webRequest:' + data.webResponse);
        LoggingUtil.log.info('tenantId:' + data.tenantId);
        LoggingUtil.log.info('botId:' + data.botId);
        LoggingUtil.log.info('userName:' + data.userName);
        LoggingUtil.log.info('Messages from Users: ' + JSON.stringify(data.reqBody));
    }

    private middleWareHook = async (context, next)=>{
        const data =  PlatformApplicationContext.getInstance().getRequestData();
        data.turnContext=context;
        await next();
        LoggingUtil.log.info('middleWareHook end' + context);
    }

    // Catch-all for errors.
private onTurnErrorHandler = async (context, error) => {
    

    // This check writes out errors to console log .vs. app insights.
    // NOTE: In production environment, you should consider logging this to Azure
    //       application insights.
    LoggingUtil.log.error(`\n [onTurnError] unhandled error: ${ error }`);
    // Clear out conversation state to avoid keeping the conversation in a corrupted bot state.
    // await this.conversationState.delete(context);

    // Send a message to the user.
    // await context.sendActivity(errorMsg);
    // Send a trace activity, which will be displayed in Bot Framework Emulator
    await context.sendTraceActivity(
        'OnTurnError Trace',
        `${ error }`,
        'https://www.botframework.com/schemas/error',
        'TurnError'
    );

    // Send a message to the user
    await context.sendActivity('The bot encountered an error or bug.');
    await context.sendActivity('To continue to run this bot, please fix the bot source code.');
};

// Set the onTurnError for the singleton BotFrameworkAdapter.
}