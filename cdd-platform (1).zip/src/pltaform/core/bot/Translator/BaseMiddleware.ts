import { LoggingUtil } from './../../../../common/utils/log4js';
import { Activity, TurnContext } from 'botbuilder';
import { ResourceResponse } from 'botframework-schema';
import { TranslatorService } from '../../../service/TranslatorService';
import { LanguageCache } from '../../LanguageCache';


export abstract class BaseMiddleware {
    private readonly trascript: boolean;
    private readonly period: number;
    private interval: any;
    private finished: boolean;

    constructor() {
        this.trascript = true;
    }

    public abstract onUserQuery(activity:Partial<Activity>);

    public abstract onBotResponse(activity:Partial<Activity>);

    public onAttachment(attachments:any[]){
        LoggingUtil.log.info(`There is/are ${attachments.length}  attachments`)
    }

    public abstract onUserQueryPredicate(activity:Partial<Activity>):boolean;

    public abstract onBotResponsePredicate(activity:Partial<Activity>):boolean;


    private translateUserQuery(activity:Partial<Activity>){
        if(this.onUserQueryPredicate(activity)){
           // LoggingUtil.log.debug(`Before handling User Query: ${activity.text}`);
            this.onUserQuery(activity);
            //LoggingUtil.log.debug(`After handling User Query: ${JSON.stringify( activity)}`);
        }
    }

    private translateBotResponse(activity:Partial<Activity>){
        if(this.onBotResponsePredicate(activity)){
            // activity.text = 'Re-Translated Text' 
           // LoggingUtil.log.debug(`Before handling bot response: ${activity.text}`);
            this.onBotResponse(activity);
            if(activity.attachments){
                this.onAttachment(activity.attachments);
            }
           // LoggingUtil.log.debug('After handling bot response '+ JSON.stringify( activity))
        }
    }

    public async onTurn(context: TurnContext, next: () => Promise<void>): Promise<void> {

        // Let the rest of the process run.
        // After everything has run, stop the indicator!
        // LoggingUtil.log.debug('Before: ' + JSON.stringify(context.activity))
        
        // ----------Translator Service-----
        // if(context.activity.type=='message'){
        // await context.onSendActivities(async (context, activities, nextSend) => {

    //         console.log("%%%%%%%%%%%",context.activity.text,"*** ",activities[0].text)
               
    //         let userLanguage=await TranslatorService.getInstance().detect(context.activity.text||activities[0].text)
    //         console.log("usertext.......",userLanguage[0].language,context.activity.conversation.id)
    //         LanguageCache.getInstance().addBotLanguage(context.activity.conversation.id,userLanguage[0].language)

    //         // const userLanguage ="en"// await this.languagePreferenceProperty.get(context, DEFAULT_LANGUAGE);
    //         const shouldTranslate =true// userLanguage !== "en";

    //         // Translate messages sent to the user to user language
    //         if (shouldTranslate) {
    //             for (const activity of activities) {
    //                 await this.translateMessageActivity(activity, userLanguage[0].language);
    //             }
    //         }
    //         return await nextSend();
    //     });
    // }

    //     await next();
        // -------------original--------
        try {
           
            this.translateUserQuery(context.activity)
            this.trackSendActivity(context)
            return await next();            
        }
        finally
        {
            // LoggingUtil.log.debug('After: ' +JSON.stringify(context.activity))
        }
    }

    
    async translateMessageActivity(activity, targetLocale) {
        if (activity.type === "message"&& activity.text!=undefined) {
            // activity.text = await TranslatorService.getInstance().translate(activity.text, targetLocale);
        }
    }
    
    private trackSendActivity(context){
        // hook up onSend pipeline
        context.onSendActivities(async (ctx: TurnContext, activities: Partial<Activity>[], 
            nextSend: () => Promise<ResourceResponse[]>) => {            
            activities.forEach(activity=>{ this.translateBotResponse(activity)})
            const responses: ResourceResponse[] = await nextSend();
            return responses;
        });
    }


}