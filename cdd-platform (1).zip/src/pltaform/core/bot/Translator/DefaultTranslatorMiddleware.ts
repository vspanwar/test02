import { EnvironmentParams } from './../../../../common/startup/EnvironmentParams';
import { BaseMiddleware } from "../Translator/BaseMiddleware";
import { Activity, TurnContext } from 'botbuilder';

export class DefaultTranslatorMiddleware extends BaseMiddleware{

    public onUserQuery(activity: Partial<Activity>) {
        // throw new Error("Method not implemented.");
    }


    public onBotResponse(activity: Partial<Activity>) {
        // throw new Error("Method not implemented.");
    }




    public onUserQueryPredicate(activity: Partial<Activity>): boolean {
        return EnvironmentParams.getEnvironment().dynaTranslatorFlag 
        && activity && activity.type=='message';
    }
    public onBotResponsePredicate(activity: Partial<Activity>): boolean {
        return EnvironmentParams.getEnvironment().dynaTranslatorFlag
        && activity && activity.type=='message';
    }


    
    
}