import { RootDialog } from '../../dialogs/RootDialog';
import { BasePlatformBot } from './BasePlatformBot';
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import { ActivityHandler, MessageFactory } from 'botbuilder';

export class SimplePlatformBot extends BasePlatformBot {
    constructor(tenantId:string, botId:string, botName:string, dialog?:RootDialog) {
        super(tenantId,botId,botName,dialog);
        // See https://aka.ms/about-bot-activity-message to learn more about the message and other activity types.
        // this.onMessage(async (context, next) => {
        //     const replyText = `Echo: ${ context.activity.text }`;
        //     await context.sendActivity(MessageFactory.text(replyText, replyText));
        //     // By calling next() you ensure that the next BotHandler is run.
        //     await next();
        // });
    }

}
