
import { PlatformAdapter } from './PlatformAdapter';
import { TenantService } from './../../service/TenantService';
import { Environment } from './../../../common/model/Environment';
//import { DialogFactory } from './../../dialogs/impl/DialogFactory';

import { PlatformCache } from './../PlatformCache';
import { SimplePlatformBot } from './SimplePlatformBot';
import { RootDialog } from '../../dialogs/RootDialog';
import { LoggingUtil } from '../../../common/utils/log4js';
import { DeploymentEnv } from '../../../common/enums/PlatformEnums';
import { AdminService } from './../../service/AdminService';
import { DialogFactory } from '../../dialogs/impl/DialogFactory';



export class BotBootstrapController {



  constructor(private environment:Environment){
      
  }

  public async init() {
        //const cfg = TenantService.getTenantCfg();
        const cfg =await AdminService.getInstance().getTenantConfig()
        //console.log("this is data" + JSON.stringify(cfg))
        for (let tenant of cfg) {
          const tenantId = tenant.tenantId;         

          for (let bot of tenant.tenantBot) {
            
              const botId = bot.botId+"";
              const appId = bot.appId;
              const appSecret = bot.appSecret;
              console.log("App Id " + appId + "App secret " + appSecret)
              //PlatformCache.getInstance().addAdaptor(botId, adaptor);
              // Create Root dialog
             
              console.log("bott in bootstrap1:"+JSON.stringify(bot))

              const dialog = await DialogFactory.getRootDialog(bot, tenantId);
              LoggingUtil.log.info("Dialog from factory");
              // Create bot 
              const simpleBot = new SimplePlatformBot(tenantId,botId,bot.botName,dialog);
              simpleBot.adapter = this.createPlatformAdapter(appId,appSecret);
              LoggingUtil.log.info(`created EchoBot **** ${bot.botName} ${simpleBot.adapter}`);
              PlatformCache.getInstance().addBot(simpleBot);
              LoggingUtil.log.info(`fetched EchoBot from memory**** ${PlatformCache.getInstance().getBot(botId).adapter}`);

          }
     }

  }

  private createPlatformAdapter(appId:string, appSecret:string):PlatformAdapter {
    const isLocalDeployment = this.environment.isDeploymentEnvLocal();// (this.environment.deploymentEnv === DeploymentEnv.LOCAL);
    appId = isLocalDeployment?"":appId;
    appSecret = isLocalDeployment?"":appSecret;
    return  new PlatformAdapter({ appId: appId,
                                  appPassword: appSecret});
    
  }




}