import { LoggingUtil } from './../../../common/utils/log4js';
import { PlatformAdapter } from './PlatformAdapter';
import { TurnContext } from 'botbuilder';
import { ActivityHandler, MessageFactory, CardFactory, BotFrameworkAdapter,TeamsActivityHandler,TaskModuleResponse , TaskModuleRequest , TaskModuleTaskInfo } from 'botbuilder';
import { ConversationState, MemoryStorage, UserState, Storage,StatePropertyAccessor } from 'botbuilder';
import { DialogState } from 'botbuilder-dialogs';
import { RootDialog } from '../../dialogs/RootDialog';
const WelcomeCard = require('../../../../resources/welcomeCard.json');
import {BotMessagePreviewActionType , BotMessagePreviewType } from "botframework-schema";
import { HandoffMiddleware } from '../liveagent/HandOffMiddleware';
import { po_data } from '../../model/PO_details';
import { PlatformApplicationContext } from '../PlatformApplicationContext';
import { Datastore } from '../../dialogs/impl/Datastore';
import { ActivityTimeout } from '../../../common/utils/botTimeout/botTimeout/activityTimeout';
import { DialogUtils } from '../../dialogs/impl/DialogUtils';

export class BasePlatformBot extends TeamsActivityHandler {
    private memoryStorage: Storage;
    private conversationState:ConversationState;
    private userState:UserState;
    private _adapter:PlatformAdapter;
    private activityTimeout: ActivityTimeout = null;
    // private static memoryStorage = new MemoryStorage();
    private dialogState: StatePropertyAccessor<DialogState>;
    

    constructor(private tenantId:string,
                private botId:string,
                private botName:string,
                private dialog?:RootDialog) {
       super();
       const nameSpace = tenantId + '.'+botId;
       this.memoryStorage= new MemoryStorage();
       this.conversationState = new ConversationState(this.memoryStorage, nameSpace);
       this.userState = new UserState(this.memoryStorage,nameSpace);
       this.dialogState = this.conversationState.createProperty<DialogState>('DialogState');
       this.activityTimeout = new ActivityTimeout(this);
    

       if(dialog) 
      {
        this.onMessage(async (context, next) => {
            LoggingUtil.log.debug("*****BasePlatformBot:onMessage ");
                // Run the Dialog with the new message Activity.
            const turnCtx:TurnContext = context as TurnContext;
            // const value  = await HandoffMiddleware.getInstance().isUserAgentInLiveChat(context.activity);
            // LoggingUtil.log.info("value in baseplatform:=="+value);


            let d= await Datastore.getInstance().getTimestamp()
            if(context.activity.channelId == 'emulator')
            {
              context.activity.from.id = "S, Anusyua"
            }
      
            if(context.activity.channelId == 'directline'){ 
            //if(context.activity.channelId == 'directline'||context.activity.channelId == 'emulator'){  
            let name = context.activity.from.id.split(",")[1]
            let data = name +" ("+d+") : "+ context.activity.text+"|"
            LoggingUtil.log.info("inside  Activity text :"+data)   
            await Datastore.getInstance().logTranscript(data,context.activity.conversation.id)
            }
            // else{
            //   let name = await DialogUtils.getInstance().getUserNameOnly(context.activity)
            //   let session_id = await Datastore.getInstance().get_SessionID(context.activity.conversation.id)
            //   console.log("session id-->", session_id)
            //   // let data = name +" ("+d+") : "+ context.activity.text+"|"
            //   LoggingUtil.log.info("inside  Activity text else:"+ context.activity.text) 
            //   await Datastore.getInstance().logTranscriptHR(context.activity.text,session_id,name)  
            // }

                await (this.dialog as RootDialog).run(context, this.dialogState);
                await next();

            });
      }
     
       this.onEvent(async (context,next) =>{
        if(context.activity.name=="sendParamData" && context.activity.type =="event"){
       

        }
       
        await next();
       });
       this.onEvent(async (context,next) =>{
        if(context.activity.name=="userLoginSuccess" && context.activity.type =="event"){
          console.log("inside user login event")
        
        }
        await next();
       });

       this.onEvent(async (context,next) =>{
        if(context.activity.name=="mail_id" && context.activity.type =="event"){
        
        }
        await next();
       });
       this.onEvent(async (context,next) =>{
        if(context.activity.name=="Browser_Language" && context.activity.type =="event"){
         
         LoggingUtil.log.info("inside  browser language event")
         PlatformApplicationContext.getInstance().getRequestData().browser_language = context.activity.value
        
        }
        await next();
       });
     
     
       this.onMembersAdded(async (context, next) => {
        
        //if(context.activity.channelId == 'directline'||context.activity.channelId == 'emulator'){
          const membersAdded = context.activity.membersAdded;
            LoggingUtil.log.info("BasePlatformBot:onMembersAdded ");
            for (const member of membersAdded) {
                if (member.id !== context.activity.recipient.id) {
                 
                    if(dialog) {
                      // if(context.activity.channelId == 'emulator'){
                      //   context.activity.text = " ";
                      // }
                        //context.activity.text = " ";

                        //if(context.activity.channelId == 'msteams'){ //||context.activity.channelId=="emulator"){
                          LoggingUtil.log.info("BasePlatformBot:onMessage:dialog");
                          await (dialog as RootDialog).run(context, this.dialogState);              
                        // }
                        // else{
                        //   LoggingUtil.log.info("BasePlatformBot:onMessage:dialog run1");
                        //   await (this.dialog as RootDialog).run1(context, this.dialogState);
                        // }
                    }

                }
            }
            // By calling next() you ensure that the next BotHandler is run.
            await next();     

       //}
      });
            
    

        this.onDialog(async (context, next) => {
            // Save any state changes. The load happened during the execution of the Dialog.
            await this.conversationState.saveChanges(context, false);
            await this.userState.saveChanges(context, false);

            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });

     
    }

    protected handleTeamsTaskModuleFetch(context: TurnContext, request: TaskModuleRequest): Promise<TaskModuleResponse> {
        let response: TaskModuleResponse;
        console.log(request,"request")
        context.sendActivity(MessageFactory.text(`handleTeamsTaskModuleFetch TaskModuleRequest: ${JSON.stringify(request)}`));

      
        switch (request.data.taskModule) {
          case "player":
              response = ({
                task: {
                  type: "continue" as BotMessagePreviewActionType,
                  value: {
                    title: "YouTube Player",
                    url: `https://${process.env.HOSTNAME}/youTubePlayer1Tab/player.html?vid=${request.data.videoId}`,
                    width: 1000,
                    height: 700
                  } as TaskModuleTaskInfo
                }
              } as TaskModuleResponse);
              break;
            default:
              response = ({
                task: {
                  type: "continue" as BotMessagePreviewActionType,
                  value: {
                    title: "YouTube Player",
                    url: `https://${process.env.HOSTNAME}/youTubePlayer1Tab/player.html?vid=X8krAMdGvCQ&default=1`,
                    width: 1000,
                    height: 700
                  } as TaskModuleTaskInfo
                }
              } as TaskModuleResponse);
            break;
        };
      
        console.log("handleTeamsTaskModuleFetch() response", response);
        return Promise.resolve(response);
      }

 

    get adapter():PlatformAdapter {
        return this._adapter;
      }

    set adapter(adapter:PlatformAdapter) {
        this._adapter = adapter;
      }
   

    public getTenantId():string {
        return this.tenantId;
    }
    public getBotId():string {
        return this.botId;
    }
    public getBotName():string {
        return this.botName;
    }

    public getStorage():Storage{
        return this.memoryStorage;
    }

    public getConversationState():ConversationState{
        return this.conversationState;
    }
    
    public getUserState():UserState{
        return this.userState;
    }

    private onMembersAddedInternal = async (context, next) => {
        const membersAdded = context.activity.membersAdded;
        const welcomeText = 'Hello and welcome!';
        for (const member of membersAdded) {
            if (member.id !== context.activity.recipient.id) {
                await context.sendActivity(MessageFactory.text(welcomeText, welcomeText));
            }
        }
        // By calling next() you ensure that the next BotHandler is run.
        await next();
    }
    private onTurnInternal = async (context, next) => {
                 // Handle a "turn" event.
               await context.sendActivity(`${ context.activity.type } activity received.`);
                // Continue with further processing.
                await next();
            }
    private onEndOfConversationInternal = async (context, next) => {
        // Handle a "turn" event.
      await context.sendActivity(`End of coversation.`);
       // Continue with further processing.
       await next();
   }

   private onTypingInternal = async (context, next) => {
    // Handle a "turn" event.
        await context.sendActivity(`On typing`);
        // Continue with further processing.
        await next();
    }

    private onUnrecognizedActivityTypeInternal = async (context, next) => {
        // Handle a "turn" event.
            await context.sendActivity(`On onUnrecognizedActivityTypeInternal`);
            // Continue with further processing.
            await next();
    }

    private onDialogInternal = async (context, next) => {
        // Handle a "turn" event.
            await context.sendActivity(`On onDialogInternal`);
            // Continue with further processing.
            await next();
        }

    private onMembersRemovedInternal = async (context, next) => {
            // Handle a "turn" event.
                await context.sendActivity(`On onMembersRemovedInternal`);
                // Continue with further processing.
                await next();
    }

}

