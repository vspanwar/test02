import { Environment } from './../../common/model/Environment';
import { Module } from './../../common/enums/PlatformEnums';
import { BotRouter } from './../web/BotRouter';

import { EnvironmentParams } from './../../common/startup/EnvironmentParams';

import {PlatformCache} from './PlatformCache';
import {PlatformAdapter} from './bot/PlatformAdapter';
import { BotBootstrapController } from './bot/BotBootstrapController';
// import { WebApp } from '../web/PlatformWebApp';
import { AsyncHookMap } from 'async-hooks-map';

import { config } from 'dotenv';
import * as path from 'path';
import { RequestData } from '../model/RequestData';
import { BaseAppContext } from '../../common/core/BaseAppContext';
import { BaseRouter } from '../../common/web/BaseRouter';

export class PlatformApplicationContext extends BaseAppContext{

  private static instance: PlatformApplicationContext;
  // private webApp: WebApp;
  private cache:PlatformCache;
  private botBotstrapController:BotBootstrapController;
  // private botAdapter:PlatformAdapter;
  private environment:Environment;
  private constructor(){super()}

  public static getInstance(): PlatformApplicationContext {
    if (PlatformApplicationContext.instance == null) {
        PlatformApplicationContext.instance = new PlatformApplicationContext();
    }
    return PlatformApplicationContext.instance;
  }


  public  onInit(){
      console.log('Init');
      this.cache = PlatformCache.getInstance();
      this.botBotstrapController =new BotBootstrapController(this.getEnvironment());
      this.botBotstrapController.init();

      // this.webApp = new WebApp();
      // this.webApp.initApp();
      // this. botAdapter = new PlatformAdapter();

   }

   public  getModule(){
      return Module.PLATFORM;
   }

   public getCache():PlatformCache{
       return this.cache;
   }

   public getRouter():BaseRouter{
    
    return new BotRouter(Module.PLATFORM);
   }

  //  public getBotAdapter():PlatformAdapter{
  //   return this.botAdapter;
  //  }


}