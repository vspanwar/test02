import { BaseRedisAPIs } from "../../../../common/repository/dao/BaseRedisAPIs";
import { LoggingUtil } from "../../../../common/utils/log4js";
import { Table } from "../model/LiveAgentEnums";
import { TransactionDao } from "../model/TransactionDao";


export class TransactionTableManager extends BaseRedisAPIs {
    private static instance:TransactionTableManager;

    public static getInstance(){
        if(TransactionTableManager.instance == null){
            TransactionTableManager.instance =  new TransactionTableManager();
        }
        return TransactionTableManager.instance;
    }

    public async createTransactionEntry(userId:string,transactionDao:TransactionDao){
        return await this.hashSet(Table.TransactionTable,userId,JSON.stringify(transactionDao));
    }

    public async getTransactionEntry(convId:string){
        let res = await this.hashGet(Table.TransactionTable,convId);
        return JSON.parse(res);
    }

    public async deleteTransactionEntry(userId:string){
        let res = await this.hashDelete(Table.TransactionTable,userId);
        return (res==1)?true:false;
    }

    public async getAllTransactionEntries(){
       
        let res:Array<any> = await this.hashGetValues(Table.TransactionTable);
        if(res.length>0){
            res = await res.map(record =>{
                let new_record  = JSON.parse(record);
                return new_record
            });
            return res;

        }else return [];
    }

    /** suppose you want to find 'Cbo Mfdm Bot' string then, matchStr would be like Cbo* or *Bot or *Mfdm*  
    in response will get all matching results from given hash
    */

    public async scanTransactionByKey(matchStr:string){
        let res = await this.hashScan(Table.TransactionTable,matchStr);
        LoggingUtil.log.info("hash scan: "+ JSON.stringify(res)+": match str: "+matchStr);
        return (res && res[1].length==0)?null:res[1];
    }

    public async removeEntryFromTransaction(convId:string){
        let res = await this.hashDelete(Table.TransactionTable,convId);
        LoggingUtil.log.info("conversation id  remove entry: "+convId);
        return (res==1)?true:false;
    }
}