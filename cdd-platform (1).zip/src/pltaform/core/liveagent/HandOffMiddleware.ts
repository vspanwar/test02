import { AdminService } from "../../service/AdminService";
import { TransactionTableManager } from "./service/TransactionTableManager";
import { Activity, TurnContext } from 'botbuilder-core';
import { TransactionDao } from "./model/TransactionDao";
import { LoggingUtil } from "../../../common/utils/log4js";
import { SendMessageActivity } from "./model/SendMessageActivity";
import { IsThereAnythingElse } from "../../dialogs/impl/platform/IsThereAnythingelse";

const WebSocket = require('ws');
let memberID = ""
let liveAgentID = ""


export class HandoffMiddleware {

  private static instance: HandoffMiddleware;
  public static getInstance() {
    if (HandoffMiddleware.instance == null) {
      HandoffMiddleware.instance = new HandoffMiddleware();
    }
    return HandoffMiddleware.instance;
  }


  public async handoffEvent(context: TurnContext, event_url: string) {

    const ws = new WebSocket(event_url);

    ws.on('open', function open() {
      ws.send('something');
    });

    ws.on('message', function incoming(data) {
      console.log(data);

    });
    ws.onmessage = async (data) => {

      let agentAvailable = false;
      if (data.data.topicName != "channel.metadata") {
        console.log("websocket message:", data.data);
      }

      let dataFinal = JSON.parse(data.data)
      if (dataFinal.topicName != "channel.metadata" &&
        dataFinal?.eventBody?.conversation?.id) {
        const keyPattern = "*" + dataFinal.eventBody.conversation.id + "*";
        LoggingUtil.log.info('FFFF:::' + keyPattern)
        const trasactionRecord = await TransactionTableManager.getInstance().scanTransactionByKey(keyPattern);
        const tableKey = trasactionRecord[0];
        const tableValue: TransactionDao = JSON.parse(trasactionRecord[1]);
        LoggingUtil.log.info(`transation entry === ${JSON.stringify(trasactionRecord)}`);

        if (dataFinal.eventBody.conversation.id && dataFinal.metadata.type == "member-change") {
          //This condition is applied to get liveAgentID 
          if (dataFinal.eventBody.member.state == "ALERTING") {
            liveAgentID = dataFinal.eventBody.member.id
            LoggingUtil.log.info("Agent ID: " + liveAgentID)
            return liveAgentID
          }
          else {
            LoggingUtil.log.info("Changing member of chat")
          }
        }
        else {
          LoggingUtil.log.info("Normal")
        }

        if (dataFinal.eventBody.conversation.id && dataFinal.eventBody.member) {
          if (dataFinal.eventBody.member.id == liveAgentID) {
            if (dataFinal.eventBody.member.state == "CONNECTED") {
              LoggingUtil.log.info("Agent has joined the chat")
              await SendMessageActivity.sendMessage(tableValue.convRef, "** Agent has joined the chat. **")
            }
            // else{
            //   LoggingUtil.log.info("Agent rejected the call")
            //   await SendMessageActivity.sendMessage(tableValue.convRef, "** Agent can not joined the chat. **")
            // }
          }
          else{
            LoggingUtil.log.info("Proceeding with flow")
          }
        }
        else{
          LoggingUtil.log.info("Working")
        }

        

        if (dataFinal.eventBody.conversation.id && dataFinal.eventBody.bodyType == "standard") {
          if (dataFinal.eventBody.sender.id == liveAgentID) {
            //THIS CONDITION WILL MATCH AGENT ID WITH SENDER ID

            const msg = dataFinal.eventBody.body;
            LoggingUtil.log.info("inside send agent message to user: " + msg);
            await SendMessageActivity.sendMessage(tableValue.convRef, msg);
          }
          else {
            // HERE SENDER ID WILL BE USER's ID
            const msg = dataFinal.eventBody.body;
            LoggingUtil.log.info('User message' + msg)
          }
        }

        else {
          if (dataFinal.eventBody.conversation.id && dataFinal.metadata.type == "member-change" && dataFinal.eventBody.member.state == "DISCONNECTED") {
            if (dataFinal.eventBody.member.id == liveAgentID) { //websocket will close after agent left the meeting.
              LoggingUtil.log.info("Agent has left the meeting")
              ws.close()
              await SendMessageActivity.sendMessage(tableValue.convRef, "Agent has left the chat.")
              LoggingUtil.log.info("Deleting transaction record since Agent has left the chat")
              agentAvailable = false
              await TransactionTableManager.getInstance().deleteTransactionEntry(trasactionRecord[0])
              return 

            }
            else {
              LoggingUtil.log.info("Change in possession") // Here call is moving back and forth in queues as queue is also a member with unique id
            }
          }

          else if (dataFinal.eventBody.conversation.id && dataFinal.eventBody.body == "No agents Available, Disconnecting the chat." && dataFinal.eventBody.bodyType == "standard" && dataFinal.metadata.type == "message") {
            LoggingUtil.log.info("Deleting Transaction record since no agent is available to attend the call") // when no agent is available to connect with user
            await SendMessageActivity.sendMessage(tableValue.convRef, "No agents available right now. Please try again after some time")
            agentAvailable = false
            ws.close()
            return await TransactionTableManager.getInstance().deleteTransactionEntry(trasactionRecord[0])

          }


      
      if (data.data.topicName != "channel.metadata") {
        console.log("websocket message:", data.data);
      }

        }
      }
      else {
        LoggingUtil.log.info("Waiting for Conversation to proceed")
      }


    }
  }


  public async getConnectionDetails(activty: Partial<Activity>): Promise<string> {
    let userName = 'ashmeet.aad'
    let email = 'Ashmeet.S@tcsddp.com'
    let fetch_token = await AdminService.getInstance().fetchToken()
    //console.log("token value"+fetch_token)
    let convID = fetch_token.id
    let token = fetch_token.jwt
    memberID = fetch_token.member['id']
    let event_url = fetch_token.eventStreamUri

    let convRef = TurnContext.getConversationReference(activty);


    let payload = <TransactionDao>{
      convRef: convRef,
      jwt: token,
      memberId: memberID,
      agentname: '',
      agentId: '',
      convId: convID,
    }

    const transactionKey = `${activty.conversation.id}.${convID}`;
    const response = await TransactionTableManager.getInstance().createTransactionEntry(transactionKey, payload);
    LoggingUtil.log.info(response, "REDIS TRANSACTION Entry")
    return event_url;
  }

  /* check if this activity related to liveagent functionality or chatbot. we check transaction table for this
  */

  public async isUserAgentInLiveChat(activity: Partial<Activity>) {

    LoggingUtil.log.info("inside is user agent live chat")
    let pattern = "*" + activity.conversation.id + "*"
    let res = await TransactionTableManager.getInstance().scanTransactionByKey(pattern);
    LoggingUtil.log.info("isUserAgentInLiveChat:@@ " + res + ` ${res != null}`);
    if (res != null) {
      // this.sendMsgToAgent(res[1], activity.text);

      //  console.log(JSON.parse(res[1].jwt)+"JWTTT")
      return true;
    } 
    else {
      return false;
    }

  }


  public async sendMsgToAgent(activity: Partial<Activity>): Promise<void> {
    LoggingUtil.log.info('Sending user message to Agent')
    LoggingUtil.log.info("inside is user agent live chat")
    let pattern = "*" + activity.conversation.id + "*"
    let res = await TransactionTableManager.getInstance().scanTransactionByKey(pattern);
    const record: TransactionDao = JSON.parse(res[1]);
    LoggingUtil.log.info("response transaction:@@ " + res + ` ${res != null}`);
    if (res != null) {

      //console.log(JSON.parse(res[1].jwt)+"JWTTT")
      LoggingUtil.log.info("sendmsgtoAgent : cnvId: " + record.convId + "::member: " + record.memberId + "::jwt:" + record.jwt);

      const response = await AdminService.getInstance().connectWithAgent(activity.text, record.convId, record.memberId, record.jwt);
      LoggingUtil.log.info("response: " + JSON.stringify(response));
    }
  }

}