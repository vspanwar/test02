import { ConversationReference } from "botbuilder";
import { LoggingUtil } from "../../../../common/utils/log4js";
import { PlatformCache } from "../../PlatformCache";

/**
 * Model for sending msg activity to any user within bot by their Conversation Reference
 */
export class SendMessageActivity {

    public static async sendMessage(convoRef:Partial<ConversationReference>,text:string){
        LoggingUtil.log.debug("conv ref"+JSON.stringify(convoRef));
        
        let adapter = PlatformCache.getInstance().getBot('1' ).adapter;
        //convoRef.conversation.properties = text;
        LoggingUtil.log.info("msg text: "+text);
        await adapter.continueConversation(convoRef,async turnContext=>{
            //turnContext.activity.channelData.type = LiveAgentTypes.CHANNELTYPE
            LoggingUtil.log.info("sendActivityText: "+ text+ "for"+turnContext.activity.from.id);
            await turnContext.sendActivity(text)
            
        })

    }
}