import { ConversationReference } from "botbuilder";

/**
 * Schema for Transaction table data
 */

//key is = cddConvId.genesysConvId
export interface TransactionDao{
    convRef:Partial<ConversationReference>;
    //convRef:string;
    jwt: string;
    memberId: string;
    agentname:string;
    agentId:string;
    convId:string;
}