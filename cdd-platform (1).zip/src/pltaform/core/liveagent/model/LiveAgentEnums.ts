

export enum Table{
    PriorityQueue='PriorityQueue' , RequestTable='UserRequestHash' , 
    TransactionTable = 'TransactionRecords' , AvailableAgentTable = 'AvailableAgentPoolBySkill', 
    AvailableAgentPoolById = 'AvailableAgentPoolById', LiveAgentTable  = 'LiveAgentHash'
}

export enum SupportedLang {
    ENG = 'English' , SPA = 'Spanish' , PTGS='Portuguese' , RUS='Russian' , DUT='Dutch' , FRE='French'
}

export enum LiveAgentState {
    LIVE= 'AVAILABLE' ,INCHAT='BUSY' ,DISCONNECT='OFFLINE' , HIDE ='AWAY', MISSED='MISSED'
}

export enum UserType {
    AGENT= 'agent',ADMIN='admin'
}

export enum Events {
    HANDOFFVALUE = 'HANDOFF-EVENT'  , HANDOFFEVENTNAME='handoff.initiate'
}

export enum LiveUserState {
    LIVE= 'AVAILABLE' ,INCHAT='BUSY'
}

export enum Commands{
    LIVE= '//available' ,HIDE='//away' ,DISCONNECT='//offline'  , ENDCHAT='//endchat', ESCALATE='//escalate'
}