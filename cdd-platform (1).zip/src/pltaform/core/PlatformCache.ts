import { LoggingUtil } from './../../common/utils/log4js';
import { BasePlatformBot } from './bot/BasePlatformBot';
import { BaseCache } from './../../common/core/BaseCache';
import { ActivityHandler, BotFrameworkAdapter } from 'botbuilder';
import { Module } from '../../common/enums/PlatformEnums';

export class PlatformCache extends BaseCache {
    private static instance: PlatformCache;
    private botCache: Map<string, BasePlatformBot>;
    // private adaptorCache: Map<string, BotFrameworkAdapter>;
 
    private constructor() { 
        super(Module.PLATFORM);
        this.botCache = new Map<string, BasePlatformBot>();
        LoggingUtil.log.debug('Creating Platform Cache   ')
        // this.adaptorCache = new Map<string, BotFrameworkAdapter>();
    }

    public static getInstance(): PlatformCache {
        if (PlatformCache.instance == null) {
            PlatformCache.instance = new PlatformCache();
        }
        return PlatformCache.instance;
      }

    public addBot(bot: BasePlatformBot) {
        // console.log(`[addBot] botId: ${botId}`);
        this.botCache.set(bot.getBotId(), bot);
        // console.log(`[addBot] cache-size: ${this.cache.size}`);
    }

    public getBot(botId: string): BasePlatformBot {
        // console.log(`[getBot] botId: ${botId}`);
        return this.botCache.get(botId);
    }

    public getBotCache(): Map<string, BasePlatformBot> {
        return this.botCache;
    }

    public containsBot(botId: string): boolean {
        return this.botCache.has(botId)
    }

    public removeBot(botId: string) {
        this.botCache.delete(botId);
    }

    // public addAdaptor(botId: string, adaptor: BotFrameworkAdapter) {
    //     // console.log(`[addBot] botId: ${botId}`);
    //     this.adaptorCache.set(botId, adaptor);
    //     // console.log(`[addBot] cache-size: ${this.cache.size}`);
    // }

    // public getAdaptor(botId: string): BotFrameworkAdapter {
    //     // console.log(`[getBot] botId: ${botId}`);
    //     return this.adaptorCache.get(botId);
    // }
}