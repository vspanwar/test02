import { ItsmServie } from './../service/itsm/ItsmService';
import { LoggingUtil } from './../../common/utils/log4js';
import { EsiService } from './../service/EsiService';
import { Request, Response } from 'express';
import { BaseEsiController } from './BaseEsiController';
import { NextThinkScripts } from '../service/nextThink/NextThinkScripts';

export class EsiController extends BaseEsiController {
private static instance: EsiController;
private service:EsiService;
private itsmService:ItsmServie;

private constructor(){
    super();
    this.service = new EsiService();
    this.itsmService = new ItsmServie();
}

public static getInstance = () => {
    if (EsiController.instance == null) {
        EsiController.instance = new EsiController();
    }
    return EsiController.instance;
}


public async action(req: Request, res: Response) {
    console.log(' action ...2');
    return await this.service.action(req, res).then(tb => {
        res.send(tb);
    });
}

public async operationOnItsm(req: Request, res: Response) {
    LoggingUtil.log.debug('OperationOnItsm ');

    return await this.itsmService.action(req.body.config, 
        req.body.payload,
        req.body.action).then(tb => {
        res.send(tb);
    });
}
public async runNextThink(req: Request, res: Response) {
    LoggingUtil.log.debug('OperationOnItsm ');

    return await NextThinkScripts.getInstance().execute(req.body).then(tb => {
        res.send(tb);
    });
}
}