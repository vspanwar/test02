import { LoggingUtil } from './../../common/utils/log4js';
import { EsiController } from './../controller/EsiController';
import { Router, NextFunction, Request, Response } from 'express';
import { Module } from '../../common/enums/PlatformEnums';
import { BaseRouter } from '../../common/web/BaseRouter';

export class EsiRouter extends BaseRouter {

private controller:EsiController;
/**
Initialize the Router
*/
constructor() {
super(Module.ESI);
//this.controller = new AdminController();
}

onInit(router: Router) {
LoggingUtil.log.debug(' ESI Router');
router.post('/itsm', this.operationOnItsm);

// throw new Error("Method not implemented.");
}

public operationOnItsm(req: Request, res: Response) {
EsiController.getInstance().operationOnItsm(req, res);
}
public runNextThink(req: Request, res: Response) {
EsiController.getInstance().runNextThink(req, res);
}

}