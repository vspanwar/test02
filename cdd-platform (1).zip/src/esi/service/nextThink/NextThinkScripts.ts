import { LoggingUtil } from '../../../common/utils/log4js';
import { NextThinkService } from './NextThinkService';


export class NextThinkScripts { 

    public static instance : NextThinkScripts
    public static getInstance = () => {
        if (NextThinkScripts.instance == null) {
            NextThinkScripts.instance = new NextThinkScripts();
        }
        return NextThinkScripts.instance;
    }


    
    public async execute(payload:any) {
        
        LoggingUtil.log.debug(`Script type :${payload.script}`)
        
        switch(payload.script){
            case "HealthCheck" : {
                return await NextThinkService.getInstance().getHealthChecks(payload)

            }
            default:
                console.log('default');
                break;
         }

        throw new Error("Method not implemented.");
    }






}