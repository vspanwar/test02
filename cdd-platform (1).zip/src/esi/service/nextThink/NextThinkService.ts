import { HttpUtil } from '../../../common/utils/HttpUtil';
import { LoggingUtil } from '../../../common/utils/log4js';

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';


export class NextThinkService { 

    public static url = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1"

    public static instance : NextThinkService
    public static getInstance = () => {
        if (NextThinkService.instance == null) {
            NextThinkService.instance = new NextThinkService();
        }
        return NextThinkService.instance;
    }
    public constructHeaders(){
        let headers={}
        headers['Content-Type']="application/json"
        headers['Access-Control-Allow-Origin']=true
        headers['X-API-Key']="f473cb1d249d4509003be87c31fc321984bca287e6610e937ef197922ec6a9cc"

        return headers
    }
    public async getUserDevices(userName: any){
        if (userName == "alan.rugh@vm-sindemodws02"|| userName == "alan.rugh@prototype"|| userName == "alan.rugh@CDD-Nexthink-Wi"){
        let requestUrl = NextThinkService.url + "/user/"+ userName +"/devices"
        let res = await HttpUtil.get(requestUrl, await this.constructHeaders())

        console.log("DRUID:  " +res['0']["device_uid"])

        return {'device' : res['0']}
    }
    else{
        return {"error ": "Could not able to run script"}
    }
}

    public async getHealthChecks(payload:any){

        let devices = await this.getUserDevices(payload.userId)
        console.log("DUID: "+ devices.device.device_uid)
        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/topic/l1_device_checklist/device/"+devices.device.device_uid+"/windows"
            let res = await HttpUtil.get(requestUrl, this.constructHeaders())
            return res

        }
        return { "error ": "Could not able to run script"}
    }

    public async DiskCleanup(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl1 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/disk_cleanup/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl1, undefined, this.constructHeaders())
            return res
        }
        return {"error": "Could not able to run  script"}
    }

    public async getHealthIssueTicket(payload:any){

        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/disk_cleanup/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}
    }
    public async getOutlookIssues(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/topic/app_outlook_issues/device/"+devices.device.device_uid+"/windows"
            let res = await HttpUtil.get(requestUrl, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}
    }
    public async postOutlookIssues(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/outlook_crash_with_snow/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}
    }
    public async getOutlookIssueTicket(payload:any){

        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/outlook_crash_with_snow/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}
    }
    public async postAudioFix(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/resolve_audio_issues/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}
    }
    public async getAudioFixStatus(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/resolve_audio_issues/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}




    }
    public async postWIFIFix(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/get_wifi_information/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}
    }
    public async getWIFIFixStatus(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/get_wifi_information/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}




    }
    public async postMapNetworkDrive(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/map_network_drive/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}

    }
    public async getMapNetworkDrive(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/map_network_drive/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}




    }
    public async postMSTeamsCache(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/clear_microsoft_teams_cache/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}

    }
    public async getMSTeamsCache(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/clear_microsoft_teams_cache/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}




    }
    public async postMSTeamsReinstall(payload:any){
        console.log("payload in getOutlookIssues"+JSON.stringify(payload))
        let devices = await this.getUserDevices(payload.userId)


        if(devices && devices.device && devices.device.device_uid){
            let requestUrl = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/reinstall_microsoft_teams/"+devices.device.device_uid
            let res = await HttpUtil.post(requestUrl,undefined, this.constructHeaders())
            return res


        }
        return { "error ": "Could not able to run script"}

    }
    public async getMSTeamsReinstall(payload:any){
        let devices = await this.getUserDevices(payload.userId)

        if(devices && devices.device && devices.device.device_uid){
            let requestUrl2 = "https://nxtadapter.southindia.cloudapp.azure.com:8090/v1/remote_action/reinstall_microsoft_teams/"+devices.device.device_uid
            let res = await HttpUtil.get(requestUrl2, this.constructHeaders())
            return res["status"]
        }
        return { "error ": "Could not able to run script"}




    }
    


}