import { HttpUtil } from '../../common/utils/HttpUtil';

export class WeatherService {

    public static WeatherService: WeatherService;

    private constructor() {
    }

    public static getInstance(): WeatherService {
        if (WeatherService.WeatherService == null) {
            WeatherService.WeatherService = new WeatherService();
        }
        return WeatherService.WeatherService;
    }

    public async getWeatherDetails(payload: any): Promise<any>{

        let url = "http://api.openweathermap.org/data/2.5/weather";
        let city = payload.city;
        let apikeyStr = process.env.weather_api_key;
        let queryParams = "?q="+city+"&&appid="+apikeyStr+"&units=metric";
        console.log("Query Params is=" + queryParams);
        let responses = await HttpUtil.get(url + queryParams);
        let response = JSON.parse(responses);

        return response;
    }
}
