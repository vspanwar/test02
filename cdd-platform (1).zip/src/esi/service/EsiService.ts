import { EsiDao } from './../dao/EsiDao';
import { BaseEsiService } from './BaseEsiService';


export class EsiService extends BaseEsiService{
    private dao:EsiDao;

    constructor(){
        super();
        this.dao = new EsiDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}