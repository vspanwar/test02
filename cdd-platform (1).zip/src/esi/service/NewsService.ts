import { HttpUtil } from '../../common/utils/HttpUtil';
//import { EnvironmentParams } from '../../../../common/startup/EnvironmentParams';

export class NewsService {

    public static NewsService: NewsService;

    private constructor() {
    }

    public static getInstance(): NewsService {
        if (NewsService.NewsService == null) {
            NewsService.NewsService = new NewsService();
        }
        return NewsService.NewsService;
    }

    public async getTopFiveNews(): Promise<any>{
        let url = "https://newsapi.org/v2/everything";
        let apikeyStr = process.env.google_news_api_key;
        let queryParams = "?q=Tata&apiKey="+apikeyStr;
        console.log("Query Params is=" + queryParams);
        let responses = await HttpUtil.get(url + queryParams);
        console.log(responses);
        let response = JSON.parse(responses);
        return response;
    }
}