export interface ItsmInterface {
     getSpecificKnowledgeArticle(payload: any, metadata: any): Promise<string>;
     createIncident(payload: any, metadata: any): Promise<string>;
     createInteraction(payload: any, metadata: any): Promise<string>;
     getVariablesOfCatalog(payload: any, metadata: any): Promise<string>;
     submitOrderCatalog(payload: any, metadata: any): Promise<any>;
     createSR(payload: any, metadata: any): Promise<any>;
     addInCartCatalog(payload: any, metadata: any): Promise<any>;
     updateIncident(tool: any, incidentId: string, payload: string): Promise<string>;
     getIncident(payload: any, metadata: any): Promise<string>;
     getKnowledgeArticles(tool: any, searchWord: string): Promise<string>;
     getIncidents (payload: any, metadata: any): Promise<any>;
     getOutages(payload: any, metadata: any): Promise<string>
     getSysId(tool: any, userId: string): Promise<string>
     getHardwareAssets(tool: any, sysId: string): Promise<string>
     getSoftwareAssets(tool: any, softwareName: string): Promise<string>
     getSysIdOfCatalogItem(tool: any, catalogName: string): Promise<string>
     getallcatalogitems(payload:any, config:any): Promise<string>
     buyItem(payload:any, config:any): Promise<string>
     createServiceRequest(tool: any, sysIdOfReq: string): Promise<string>
     addAttachment(payload:any, config:any): Promise<string>
     addAttachmentWithGetCall(payload:any, config:any): Promise<string>
     getUserDetails(tool: any, sysIdOfUser: string): Promise<string>
     getUserDetailsByUserName(payload: any, metadata: any): Promise<string>
     getAssetDetailsByUserSysId(tool: any, sysId: any): Promise<string>
     getIncidentCategories(payload: any, metadata: any): Promise<string>
     modifyUserDetails(payload:any, config:any): Promise<string>
     getManager(payload:any, config:any): Promise<string>
     getPriorites(payload: any, metadata: any): Promise<string>
     modifyIncident(payload: any, metadata: any): Promise<string>
     searchServiceCatalog(tool: any, query: string): Promise<string>
     getServiceRequestStatus(payload: any, metadata: any): Promise<string>
     getServiceRequestStatusByUser(payload: any, metadata: any): Promise<string>


}