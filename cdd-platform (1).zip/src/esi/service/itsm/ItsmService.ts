import { LoggingUtil } from './../../../common/utils/log4js';
import { ExternalApp, ItsmRequestType } from './../../../common/enums/PlatformEnums';
import { ItsmInterface } from './ItsmInterface';
import { SNowService } from './SNowService';

export class ItsmServie { 

    private snow = SNowService.getInstance();


    private getService(type:string): ItsmInterface {

        // if(ExternalApp.ServiceNow.toString() === type ) {
        //     return this.snow;
        // }
        return this.snow;
    }

    public async action(config: any, payload: any, action:string) {
        let service:ItsmInterface = this.getService(config.type);
        LoggingUtil.log.debug(`Action type :${action}`)
        
        switch(action){
               case ItsmRequestType.IncidentCategories.toString():
                    return service.getIncidentCategories(payload, config);

               case ItsmRequestType.Priorites.toString():
                    return service.getPriorites(payload, config);    

               case ItsmRequestType.GetSpecificKnowledgeArticle.toString():
                    return service.getSpecificKnowledgeArticle(payload, config);

               case ItsmRequestType.GetSCvariables.toString():
                    return service.getVariablesOfCatalog(payload,config);

               case ItsmRequestType.AddInCartSC.toString():
                    return service.addInCartCatalog(payload, config);

               case ItsmRequestType.SubmitOrderSC.toString():
                    return service.submitOrderCatalog(payload,config);

               case ItsmRequestType.UserDetailsByUserName.toString():
                    return service.getUserDetailsByUserName(payload, config);

               case ItsmRequestType.CreateSR.toString():
                    return service.createSR(payload, config);

               case ItsmRequestType.CreateIncident.toString():
                    return service.createIncident(payload, config);

               case ItsmRequestType.CreateInteraction.toString():
                         return service.createInteraction(payload, config);

               case ItsmRequestType.ModifyIncident.toString():
                    return service.modifyIncident(payload, config);    

               case ItsmRequestType.ReadIncident.toString():
                    return service.getIncident(payload, config);

               case ItsmRequestType.SysId.toString():
                    return service.getSysId(payload, config);

               case ItsmRequestType.ReadMultipleIncidents.toString():
                    return service.getIncidents(payload, config);

               case ItsmRequestType.ServiceRequestStatus.toString():
                    return service.getServiceRequestStatus(payload, config);

               case ItsmRequestType.ServiceRequestStatusByUser.toString():
                    return service.getServiceRequestStatusByUser(payload, config);

               case ItsmRequestType.Outages.toString():
                    return service.getOutages(payload, config);    

               case ItsmRequestType.AssetDetailsByUserSysId.toString():
                    return service.getAssetDetailsByUserSysId(payload, config);
          // =======================
               case ItsmRequestType.KnowledgeArticles.toString():
                    return service.getKnowledgeArticles(payload, config);

               case ItsmRequestType.HardwareAssets.toString():
                    return service.getHardwareAssets(payload, config);    

               case ItsmRequestType.SoftwareAssets.toString():
                    return service.getSoftwareAssets(payload, config);

               case ItsmRequestType.SysIdOfCatalogItem.toString():
                    return service.getSysIdOfCatalogItem(payload, config);

               case ItsmRequestType.Allcatalogitems.toString():
                    return service.getallcatalogitems(payload, config);    

               case ItsmRequestType.CreateServiceRequest.toString():
                    return service.createServiceRequest(payload, config);

               case ItsmRequestType.AddAttachment.toString():
                    return service.addAttachment(payload, config);

               case ItsmRequestType.AddAttachmentWithGetCall.toString():
                    return service.addAttachmentWithGetCall(payload, config);

               case ItsmRequestType.UserDetails.toString():
                    return service.getUserDetails(payload, config);

               case ItsmRequestType.ModifyUserDetails.toString():
                    return service.modifyUserDetails(payload, config);

               case ItsmRequestType.Manager.toString():
                    return service.getManager(payload, config);

               case ItsmRequestType.searchServiceCatalog.toString():
                    return service.searchServiceCatalog(payload, config);
               
               case ItsmRequestType.BuyItem.toString():
                    return service.buyItem(payload, config);

               default:
                    console.log('default');
                    break;
         }

        throw new Error("Method not implemented.");
    }

}