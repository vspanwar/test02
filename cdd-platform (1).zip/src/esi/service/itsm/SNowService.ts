import { ItsmRequestType } from './../../../common/enums/PlatformEnums';
import { HttpUtil } from './../../../common/utils/HttpUtil';
import { LoggingUtil } from './../../../common/utils/log4js';
import { ItsmInterface } from "./ItsmInterface";
const axios = require('axios');


export class SNowService implements ItsmInterface {

    private static incidentInterfacelUri: string = '/api/now/v1/table/incident';
    private static interactionUri: string ='/api/now/table/interaction';
    private static knowledgeInterfaceURi: string = '/api/now/v1/table/kb_knowledge';
    private static getOutageInterfaceURi: string = '/api/now/table/cmdb_ci_outage'
    private static getSysidInterfaceURi: string = '/api/now/table/sys_user'
    private static getHardwareAssetsInterfaceURi: string = '/api/now/table/alm_hardware'
    private static getSoftwareAssetsInterfaceURi: string = '/api/now/table/cmdb_ci_spkg'
    private static sysIdOfCatalogInterfacelUri: string = '/api/now/table/sc_cat_item';
    private static sysIdOfUserInterfacelUri: string = '/api/now/table/sys_user';
    private static buyItemInterfacelUri: string = '/api/sn_sc/servicecatalog/items/';
    private static submitOrderInterfacelUri: string = '/api/sn_sc/servicecatalog/cart/submit_order'
    private static serviceRequestInterfacelUri: string = '/api/now/table/sc_req_item'
    private static attachmentInterfacelUri: string = '/api/now/attachment/file'
    private static userDetailsInterface: string = '/api/now/table/sys_user'
    private static modifyUserDetailsInterface: string = '/api/now/table/sys_user/'
    private static userAssetDetailsInterface: string = '/api/now/table/alm_hardware'
    private static incidentCategoriesInterface: string = '/api/now/table/sys_choice'
    private static getPriorites: string = '/api/now/table/dl_u_priority'
    private static serviceCatalogUri: string = '/api/sn_sc/servicecatalog/items'
    private static serviceRequestStatus: string = '/api/now/table/sc_req_item'
    private static sysIdQuery: string = '?sysparm_query=user_name%3D'
    private static outageQuery = '?sysparm_query=stateNOT%20IN6%2C7%5Eu_major_incident%3Dtrue%5Epriority%3D1&sysparm_display_value=true&sysparm_limit=10'
    private static incidentGetQuery: string = '?sysparm_query=number%3D';
    private static incidentUpdateQuery: string = '?number=';
    private static getKnowledgeArticleQuery: string = '?sysparm_query=123TEXTQUERY321%3D'
    private static getTicketQuery: string = '?sysparm_query=caller_id%3D'
    private static getHardwareAssetsQuery: string = '?sysparm_query=assigned_to%3D'
    private static getSoftwareAssetsQuery: string = '?sysparm_query=nameSTARTSWITH'
    private static getSysIdOfCatalog: string = '?sysparm_query=nameSTARTSWITH'
    private static getSysIdOfUser: string = '?sysparm_query=user_nameSTARTSWITH'
    private static getServiceRequestNumberQuery: string = '?sysparm_query=request%3D'
    private static getAttachmentQuery = '?table_name=incident&table_sys_id='
    private static userDetailsQuery: string = '?sysparm_query=sys_idSTARTSWITH'
    private static userDetailsQueryByName: string = '?sysparm_query=user_name='
    private static assetDetailsQueryBySysId: string = '?sysparm_query=assigned_to='
    private static getCategories: string = '?sysparm_query=name=incident^element=category&sysparm_fields=value,element'
    private static getManagerQuery: string = '?sysparm_query=sys_id%3D'
    private static getPriorityQuery: string = '?sysparm_display_value=true&sysparm_fields=impact%2Cactive%2Curgency%2Cpriority'
    private static getallcatalogitemsquery: string = '?sysparm_query=active=true^sysparm_display_value=true&sysparm_fields=name,short_description,sys_name,active,sys_class_name,category'
    private static searchScQuery: string = '?sysparm_text='
    private static getSpecificKnowledgeArticleQuery: string = '?sysparm_query=number%3D'
    private static serviceRequestStatusQuery: string = '?sysparm_query=numberSTARTSWITH'
    private static serviceRequestStatusQueryByUser: string = '?sysparm_query=u_receipient_name%3D'
    private static searchGOTOQuery : string="?sysparm_query=GOTO123TEXTQUERY321%3D"

    private static instance: SNowService = null;

    private constructor() {
    }

    public static getInstance(): SNowService {
        if (SNowService.instance == null) {
            SNowService.instance = new SNowService();
        }
        return SNowService.instance;
    }

    private constructHeaders(config:any) {
        let authToken = "Basic " + Buffer.from(config.principal  + ":" + config.secret).toString('base64')
        let headers = {}
        headers['Authorization'] = authToken;
        headers['Content-Type'] = 'application/json';
        LoggingUtil.log.debug("## Token:" + authToken);
        return headers;
    }

    private async getMethod(
        metadata: any,
        requestUrl: string,
        requestName:string): Promise<any> { 

            LoggingUtil.log.debug(`## ${requestName}  getMethod ${JSON.stringify(metadata)}`)
            LoggingUtil.log.debug(`BaseURL::${metadata.url}`)
            const url = metadata.url + requestUrl;
            LoggingUtil.log.debug(`Base url :${metadata.url} fullUrl:${url}`);
            return await HttpUtil.get(url, this.constructHeaders(metadata));
    }

    private async postMethod(payload: any,
        metadata: any,
        requestUrl: string,
        requestName:string): Promise<any> {

            LoggingUtil.log.debug(`## ${requestName}  postMethod ${JSON.stringify(metadata)}`)
            LoggingUtil.log.debug(`BaseURL::${metadata.url}`)
            const url = metadata.url + requestUrl;
            LoggingUtil.log.debug(`Base url :${metadata.url} fullUrl:${url}`);
            return await HttpUtil.post(url, payload, this.constructHeaders(metadata));
    }

    private async putMethod(payload: any,
        metadata: any,
        requestUrl: string,
        requestName:string): Promise<any> {

            LoggingUtil.log.debug(`## ${requestName}  putMethod ${JSON.stringify(metadata)}`)
            LoggingUtil.log.debug(`BaseURL::${metadata.url}`)
            const url = metadata.url + requestUrl;
            LoggingUtil.log.debug(`Base url :${metadata.url} fullUrl:${url}`);
            return await HttpUtil.put(url, payload, this.constructHeaders(metadata));
    }

    // public async updateSR(payload:any, metadata:any){
    //     let sysIdOfRITM = payload.sysId
    //     console.log("THIS is payload: " + JSON.stringify(payload))
    //     let url =SNowService.serviceRequestStatus+"/" + sysIdOfRITM;
    //     return await this.putMethod(payload.update_payload, 
    //         metadata, url, ItsmRequestType.updateSR);
    // }


    public async getIncidentCategories(payload: any, metadata: any): Promise<any> {
        let url =SNowService.incidentCategoriesInterface + SNowService.getCategories;
        return await this.getMethod(metadata, url, ItsmRequestType.IncidentCategories);
    }
    
    public async getPriorites(payload: any, metadata: any): Promise<any> {
        let url =SNowService.getPriorites + SNowService.getPriorityQuery;
        return await this.getMethod(metadata, url, ItsmRequestType.Priorites);
    }

    public async getVariablesOfCatalog(payload: any, metadata: any): Promise<any> {
        let url =SNowService.serviceCatalogUri + payload.sysId+'/variables';
        return await this.getMethod(metadata, url, ItsmRequestType.Priorites);
    }

    public async getUserDetailsByUserName(payload: any, metadata: any): Promise<any> {
        let url =SNowService.userDetailsInterface +  SNowService.searchGOTOQuery + "'" + payload.userName + "'";
        return await this.getMethod(metadata, url, ItsmRequestType.UserDetailsByUserName);
    }

    public async addInCartCatalog(payload: any, metadata: any): Promise<any> {
        let url =SNowService.serviceCatalogUri + payload.sysId+'/order_now';
        let postpayload = payload.payload;
        return await this.postMethod(postpayload, metadata, url, ItsmRequestType.AddInCartSC);
    }

    public async submitOrderCatalog(payload: any, metadata: any): Promise<any> {
        let url =SNowService.submitOrderInterfacelUri
        return await this.postMethod(payload, metadata, url, ItsmRequestType.SubmitOrderSC);
    }

    public async createSR(payload: any, metadata: any): Promise<any> {
        let url =SNowService.serviceRequestStatus;
        return await this.postMethod(payload, metadata, url, ItsmRequestType.CreateIncident);
    }
       public async createIncident(payload: any, metadata: any): Promise<any> {
        let url =SNowService.incidentInterfacelUri;
        return await this.postMethod(payload, metadata, url, ItsmRequestType.CreateIncident);
    }
    public async createInteraction(payload: any, metadata: any): Promise<any> {
        let url =SNowService.interactionUri;
        return await this.postMethod(payload, metadata, url, ItsmRequestType.CreateInteraction);
    }

    public async modifyIncident(payload1: any, metadata: any): Promise<any> {
        console.log("payload:"+JSON.stringify(payload1))
        let sysIdOfIncident = payload1.sysId
        let url =SNowService.incidentInterfacelUri+"/" + sysIdOfIncident;
        return await this.putMethod(payload1.update_payload, 
            metadata, url, ItsmRequestType.ModifyIncident);
    }

    public async getIncident(payload: any, metadata: any): Promise<any> {
        let incId = payload.incId
        let url =SNowService.incidentInterfacelUri+SNowService.incidentGetQuery + incId + '&sysparm_display_value=true'
        return await this.getMethod(metadata, url, ItsmRequestType.ReadIncident);
    }

    public async getSysId(payload: any, metadata: any): Promise<any> {
        let userId = payload.userId
        let url =SNowService.getSysidInterfaceURi+SNowService.getSysIdOfUser + userId
        console.log("URL: "+ url);
        return await this.getMethod(metadata, url, ItsmRequestType.SysId);
    }

    public async getIncidents (payload: any, metadata: any): Promise<any> {
        let userId = payload.userId
        let url =SNowService.incidentInterfacelUri+SNowService.getTicketQuery 
                 + payload.sysId_user + "%5Eactive%3D" 
                 + payload.status 
                 + "%5EORDERBYDESCsys_created_on&sysparm_display_value=true&sysparm_limit=" 
                 + payload.limit + "&sysparm_offset=" + payload.offset;
                 
        return await this.getMethod(metadata, url, ItsmRequestType.ReadMultipleIncidents);
    }
    
    public async getServiceRequestStatus(payload: any, metadata: any): Promise<any> {
        let ritmNumber = payload.ritmNumber
        let url =SNowService.serviceRequestStatus+SNowService.serviceRequestStatusQuery + ritmNumber 
                + '&sysparm_display_value=true&sysparm_fields=number%2Cwork_notes_list%2Csys_updated_on%2Cu_recipient_name%2Csys_id%2Cstate%2Cshort_description%2Cstage%2Capproval&sysparm_limit=1'
        return await this.getMethod(metadata, url, ItsmRequestType.ServiceRequestStatus);
    }

    public async getServiceRequestStatusByUser(payload: any, metadata: any): Promise<any> {
        let userId = payload.sysId_user
        /*let url =SNowService.serviceRequestStatus+SNowService.serviceRequestStatusQueryByUser + userId 
                + '%5EORDERBYDESCsys_created_on&sysparm_display_value=true&sysparm_limit=' + payload.limit;
          */
         
        let url = '/api/now/table/sc_req_item?sysparm_query=u_recipient_name%3D' + userId + '%5EORDERBYDESCsys_created_on&sysparm_display_value=true&sysparm_limit=5&sysparm_offset=' + payload.offset 
        return await this.getMethod(metadata, url, ItsmRequestType.ServiceRequestStatusByUser);
      // return await this.postMethod(payload, metadata, url, ItsmRequestType.ServiceRequestStatusByUser);

    }


   /* public async getOutages(payload: any, metadata: any): Promise<any> {
        let userId = payload.userId
        let url =SNowService.getOutageInterfaceURi+SNowService.outageQuery;
        return await this.getMethod(metadata, url, ItsmRequestType.Outages);
    }

    public async getAssetDetailsByUserSysId(payload: any, metadata: any): Promise<any> {
        let sysId = payload.sysId
        let url =SNowService.userAssetDetailsInterface+SNowService.assetDetailsQueryBySysId + sysId;
        return await this.getMethod(metadata, url, ItsmRequestType.AssetDetailsByUserSysId);
    }*/

    public async getOutages(payload: any, metadata: any): Promise<any> {
        let userId = payload.userId
        let url =SNowService.incidentInterfacelUri+SNowService.outageQuery;
        return await this.getMethod(metadata, url, ItsmRequestType.Outages);
    }
    
    public async getAssetDetailsByUserSysId(payload: any, metadata: any): Promise<any> {
        let sysId = payload.sysId
        let url =SNowService.userAssetDetailsInterface+SNowService.assetDetailsQueryBySysId + sysId;
        return await this.getMethod(metadata, url, ItsmRequestType.AssetDetailsByUserSysId);
    }

    public async  getUserDetails(payload: any, metadata: any): Promise<string> {
        let url =SNowService.userDetailsInterface + SNowService.userDetailsQuery + payload.userName;
        return await this.getMethod(metadata, url, ItsmRequestType.UserDetails);
    }

    updateIncident(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }

   public async getKnowledgeArticles(payload: any, metadata: any): Promise<string> {
       // throw new Error("Method not implemented.");

        let short_description = payload.short_description
        let url =SNowService.knowledgeInterfaceURi+SNowService.searchGOTOQuery+short_description +"&sysparm_fields=sys_id%2Cnumber%2Cshort_description%2Ccategory"
        return await this.getMethod(metadata, url, ItsmRequestType.KnowledgeArticles);
    }

    async addAttachment(payload: any, metadata: any): Promise<string> {
        //throw new Error("Method not implemented.");
        //console.log("## SNowService::addAttachment ->Payload =>  " + JSON.stringify(payload))
        let sysIdOfIncident = payload.sysId
        let filename = payload.fileName

        let requestUrl= SNowService.attachmentInterfacelUri+"?table_name=incident&table_sys_id=" + sysIdOfIncident + '&file_name='+filename;
        // let requestUrl= SNowService.attachmentInterfacelUri+"?table_name=incident&table_sys_id=" + sysIdOfIncident;
        let baseUrl=metadata.url
        const url = metadata.url + requestUrl;
        LoggingUtil.log.debug(`Base url :${metadata.url} fullUrl:${url}`);


        let authToken = "Basic " + Buffer.from(metadata.principal  + ":" + metadata.secret).toString('base64')
        //let content_type=metadata.contentType
        let headers = {}
        headers['Authorization'] = authToken;
        //headers['Content-Type'] = payload.contentType;
        headers['Content-Type'] =payload.contentType
        headers['Accept'] = 'application/json';

        
        let data = payload.filePayload
        console.log("snow file data"+JSON.stringify(data));
        axios.post(url, data.data,{
            headers: {
                'Content-Type':payload.contentType,
                'Authorization':authToken
            }
          })
            .then((res) => {
              LoggingUtil.log.info("file upload result::"+res.data);
            })
            .catch((error) => {
              console.error(error)
            })
        return "upload";
        // return await HttpUtil.post(url, payload.filePayload, headers);
        // let response = await axios.request(config);
        // return await this.postMethod_attach(payload.filePayload, metadata, url, ItsmRequestType.AddAttachment);
     
    }

    async searchServiceCatalog(payload: any, metadata: any): Promise<string> {
        let short_description = payload.item
        let url =SNowService.serviceCatalogUri+SNowService.searchScQuery + short_description + '\''
        return await this.getMethod(metadata, url, ItsmRequestType.searchServiceCatalog);
    
    }



    async getSpecificKnowledgeArticle(payload: any, metadata: any): Promise<string> {
        // throw new Error("Method not implemented.");
 
        let kbNumber = payload.kbNumber
         let url =SNowService.knowledgeInterfaceURi+SNowService.getSpecificKnowledgeArticleQuery + kbNumber 
         return await this.getMethod(metadata, url, ItsmRequestType.KnowledgeArticles);
     }
    getHardwareAssets(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    getSoftwareAssets(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    getSysIdOfCatalogItem(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    getallcatalogitems(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    buyItem(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    createServiceRequest(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }

    addAttachmentWithGetCall(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
   /*async  getUserDetails(payload: any, metadata: any): Promise<string> {
        let url =SNowService.userDetailsInterface + SNowService.userDetailsQuery + payload.userName;
        return await this.getMethod(metadata, url, ItsmRequestType.UserDetails);
        }*/
    modifyUserDetails(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }
    getManager(payload: any, metadata: any): Promise<string> {
        throw new Error("Method not implemented.");
    }

   
    
    
}


