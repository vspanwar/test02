import { BaseDao } from "../../common/core/BaseDao";

export abstract class BaseEsiDao extends BaseDao{

}