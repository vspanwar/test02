import { BaseEsiDao } from "./BaseEsiDao";


export class EsiDao extends BaseEsiDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}