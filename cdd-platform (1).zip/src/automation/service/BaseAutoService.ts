import { BaseService } from "../../common/core/BaseService";

export abstract class BaseAutoService extends BaseService{

}