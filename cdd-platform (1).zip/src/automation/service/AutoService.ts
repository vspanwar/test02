import { AutoDao } from './../dao/AutoDao';
import { BaseAutoService } from "./BaseAutoService";


export class AutoService extends BaseAutoService{
    private dao:AutoDao;

    constructor(){
        super();
        this.dao = new AutoDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}