import { AutoService } from './../service/AutoService';
import { Request, Response } from 'express';
import { BaseAutoController } from './BaseAutoController';
import { BaseAutoService } from '../service/BaseAutoService';

export class AutoController extends BaseAutoController {
    private static instance: AutoController;
    private service:AutoService;

    private constructor(){
        super();
        this.service = new AutoService();
    }
    
    public static getInstance = () => {
        if (AutoController.instance == null) {
            AutoController.instance = new AutoController();
        }
        return AutoController.instance;
    }

    

    public async action(req: Request, res: Response) {
        console.log(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
