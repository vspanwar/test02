import { BaseAutoDao } from "./BaseAutoDao";

export class AutoDao extends BaseAutoDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}