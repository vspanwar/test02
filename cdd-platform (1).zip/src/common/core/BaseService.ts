export abstract class BaseService{

}