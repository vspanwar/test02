export abstract class BaseDao{

}