import { Environment } from './../model/Environment';
import { Module } from './../enums/PlatformEnums';
import { WebAppConfig } from './../web/WebAppConfig';

import { BaseCache } from './BaseCache';
import { EnvironmentParams } from './../../common/startup/EnvironmentParams';

import { AsyncHookMap } from 'async-hooks-map';
import { RequestData } from '../../pltaform/model/RequestData';
import { BaseRouter } from '../web/BaseRouter';
import { LoggingUtil } from '../utils/log4js';
import { testData } from '../../pltaform/model/testData';


export abstract class BaseAppContext {
  //private cache:BaseCache;
  // private router:BaseRouter;
  private webAppConfig:WebAppConfig;


  private requestDataMap = new AsyncHookMap()

   public  init() {
    LoggingUtil.log.info(`${this.getModule()} Init of App context has started`);
      this.onInit();
       this.webAppConfig = new WebAppConfig(this.getRouter());
       this.webAppConfig.initApp();
       LoggingUtil.log.info(`${this.getModule()} Init of App context has ended`);
   }
   public  abstract onInit();


   public abstract getCache():BaseCache;

   public abstract getModule():Module;

   public abstract getRouter():BaseRouter;

   public getEnvironment():Environment{
    return EnvironmentParams.getEnvironment();
   }

    public getWebAppConfig():WebAppConfig{
     return this.webAppConfig;
    }

   public getRequestData(): RequestData {
    if( this.requestDataMap.get('RequestData') === undefined){
      this.requestDataMap.set('RequestData', new RequestData());
    }
     return this.requestDataMap.get('RequestData');
   }

   public gettestData(): testData {
    if( this.requestDataMap.get('RequestData') === undefined){
      this.requestDataMap.set('RequestData', new testData());
    }
     return this.requestDataMap.get('RequestData');
   }


}