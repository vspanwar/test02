import { Module } from './../enums/PlatformEnums';
export class BaseCache {
    private cache: Map<string, object>;

    constructor(public module:Module) { 
        this.cache = new Map<string, object>();
    }

    public getBotCache(): Map<string, object> {
        return this.cache;
    }
    
    // ==================Other cache==================
    public addValue(key: string, val: object) {
        // console.log(`[addBot] botId: ${botId}`);
        this.cache.set(key, val);
        // console.log(`[addBot] cache-size: ${this.cache.size}`);
    }

    public getValue(key: string): object {
        // console.log(`[getBot] botId: ${botId}`);
        return this.cache.get(key);
    }

    public getCache(): Map<string, object> {
        return this.cache;
    }

    public containsVal(key: string): boolean {
        return this.cache.has(key)
    }

    public removeVal(key: string) {
        this.cache.delete(key);
    }

}