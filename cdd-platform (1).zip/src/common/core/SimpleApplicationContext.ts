import { EnvironmentParams } from './../startup/EnvironmentParams';
import { Module } from './../enums/PlatformEnums';
import { BaseCache } from './BaseCache';
import { Environment } from '../model/Environment';
import { BaseAppContext } from "./BaseAppContext";
import { BaseRouter } from '../web/BaseRouter';
import { LoggingUtil } from '../utils/log4js';

export class SimpleApplicationContext extends BaseAppContext{
  private environment:Environment;
  private cache:BaseCache;
  public constructor(private module:Module,
                     private router:BaseRouter){
     super();
     this.cache = new BaseCache(this.module);
     this.environment=EnvironmentParams.getEnvironment();
   }

  
  public  onInit(){
   LoggingUtil.log.debug('Init');

   }

   public  getModule(){
      return this.module;
   }

   public getCache():BaseCache{
       return this.cache;
   }

   public getRouter():BaseRouter{
      return this.router;
   }

   

}