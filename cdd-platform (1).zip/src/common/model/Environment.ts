import { Module, ServerMode, DeploymentEnv, SourceConfig } from './../enums/PlatformEnums';


export class Environment {
    public microsoftAppId: string;
    public microsoftAppPassword: string;
    public luisAppId: string;
    public luisAPIKey: string;
    public luisAPIHostName: string;   
    public storageType: string;
    public defaultLang:string;
    public modules:ModuleEnv[];

    public serverMode:ServerMode; // =SINGLE/ MULTIPLE
    public serverPort:number;
    public deploymentEnv:string;

    public keyvaultName:string;
    public keyvaultState:string;
    public logfile:string;
    public loglevel:string;
    public tenantConfigSrc:string; // tenant_config_src
    public dynaTranslatorFlag:boolean;
    
    public isDeploymentEnvLocal(): boolean {
        return (this.deploymentEnv === DeploymentEnv.LOCAL);
    }
    public isConfigDefinedInJsonFiles(): boolean {
        return (this.tenantConfigSrc === SourceConfig.File);
    }


}

export class ModuleEnv{
    public module:Module;
    public port:number;
    public domain:string;
}