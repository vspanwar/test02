export class DataBaseParams {
    public cosmosDbConnectionString: string;
    public cosmosDbName: string;

    public redisCacheHostname: string;
    public redisCacheKey: string;
    public redisCachePort: string;



}