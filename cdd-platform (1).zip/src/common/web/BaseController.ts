import { Environment } from './../model/Environment';
import { EnvironmentParams } from '../startup/EnvironmentParams';
export abstract class BaseController{

    public getEnvironment():Environment{
        return EnvironmentParams.getEnvironment();
    }

    public isJsonConfig():boolean{
        return this.getEnvironment().isConfigDefinedInJsonFiles();
    }



}
