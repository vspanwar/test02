import { CommonWebPaths } from './CommonWebPaths';
import { Module } from './../enums/PlatformEnums';
import { Router, NextFunction, Request, Response } from 'express';
import { EnvironmentParams } from '../startup/EnvironmentParams';
import { LoggingUtil } from '../utils/log4js';

export abstract class BaseRouter {
  private  router: Router;
  private port:number;
  ;
  /**
   * Initialize the Router
   */
  constructor(private module:Module) {
    LoggingUtil.log.info(`#########${module}*******`); 
    if(EnvironmentParams.contains(this.getModule())) {
        this.port = EnvironmentParams.getModuleEnv(module).port;
        LoggingUtil.log.info(`() BaseRouters ${module} & ${this.port}`);
        this.router = Router();
        this.init();
    }
  }

 /**
  * Take each handler, and attach to one of the Express.Router's
  * endpoints.
  */
  private init():Router {
    this.router.get(CommonWebPaths.HEALTH_CHECK_API_PATH,  this.healthCheck);
    LoggingUtil.log.debug(`BaseRouters ${this.module} & ${this.port}`);
    this.onInit(this.router);
  }
  public getRouter():Router {
    return this.router;
  }

  public getBasePath():string {
    const path = CommonWebPaths.getBasePath(this.module);
    LoggingUtil.log.debug(`Base path ${path}`)
    return path;
  } 
  
  public getModule():Module {
    return this.module;
  }
  public getPort():number {

    return this.port;
  }

  public healthCheck(req: Request, res: Response) {
    
    res.status(200).send(`Service is up and alive !!!`);
   }


    
  abstract onInit(router:Router);


}
