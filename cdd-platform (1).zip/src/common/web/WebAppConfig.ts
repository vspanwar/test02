import { EnvironmentParams } from './../startup/EnvironmentParams';
import { ServerMode } from './../enums/PlatformEnums';
import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as cors from 'cors'
import { LoggingUtil } from '../utils/log4js';

import { BaseRouter} from './BaseRouter'


export class WebAppConfig {

    constructor(private router:BaseRouter){

    }
    app = express();

    public initApp() {
        // ==================== Properties initialization ==========
        
        const environment = EnvironmentParams.getEnvironment();
        const isSingleServer = (environment.serverMode === ServerMode.SINGLE);
        if(!isSingleServer) {
          LoggingUtil.log.info(`Initializing web app`);
            this.app.use(cors({
              origin: '*'
            }));

            this.app.use(express.json({ limit: '50mb' }));
            this.app.use(express.urlencoded({ limit: '50mb', extended: true }));
            this.app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }))
            this.app.use(bodyParser.json());
            this.app.use( this.router.getBasePath(), this.router.getRouter());
            this.app.listen(this.router.getPort(), () => {
              LoggingUtil.log.info(` ${this.router.getModule()} service is started at port  ${this.router.getPort()}`);
            });
            LoggingUtil.log.info(`Initializing web app is now complete for ${this.router.getModule()}`);
        }
      }
}