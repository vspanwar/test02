import { ServerMode } from './../enums/PlatformEnums';
import * as express from 'express';
import * as bodyParser from 'body-parser';
import * as cors from 'cors'
import { LoggingUtil } from '../utils/log4js';
import { BaseRouter} from './BaseRouter'
import { EnvironmentParams } from '../startup/EnvironmentParams';
import { KeyVaultService } from '../../common/utils/keyvault/keyVaultService';
import * as path from 'path';
export class CompositeWebAppConfig {
    private routers:BaseRouter[];
   
    constructor(){
      this.routers = [];
    
    }

    public addRouter(router:BaseRouter){
       this.routers.push(router);
    }

    app = express();

    public initApp() {
        // ==================== Properties initialization ==========
        const environment = EnvironmentParams.getEnvironment();
        const isSingleServer = (environment.serverMode === ServerMode.SINGLE);
        

        if(isSingleServer) {

          LoggingUtil.log.info(`Initializing composite web app`);
            this.app.use(cors({
              origin: '*'
            }));

            this.app.use(express.json({ limit: '50mb' }));
            this.app.use(express.urlencoded({ limit: '50mb', extended: true }));
            this.app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }))
            this.app.use(bodyParser.json());
            this.app.use(express.static(path.join(__dirname,'..','..','..','pages')));
            console.log(path.join(__dirname,'..','..','..','pages'))
            this.bindAndListen();
            LoggingUtil.log.info(`Initializing web app is now complete for all the composite modules`);
        }
      }

      private bindAndListen(){
        const port = EnvironmentParams.getEnvironment().serverPort;
        // this.app.
        for (var router of this.routers) {
             this.app.use( router.getBasePath(), router.getRouter());
        }
        this.app.listen(port, () => {
          LoggingUtil.log.info(`Service is started at port ${port}`);
        });
        
        this.getKeyFromKeyVault();
      }

      public async getKeyFromKeyVault(){
        let key = await KeyVaultService.getInstance().getKey("platformAuthKey");
        LoggingUtil.log.info("GOT KEY FROM KeyVault: "+key);
      }
}