import { EnvironmentParams } from './../startup/EnvironmentParams';
import { Module } from './../enums/PlatformEnums';
export class CommonWebPaths {

    // ~~~~=========== Private =============================
    private static readonly PATH_SEPERATOR = '/';
    private static readonly PLATFORM_VERSION = CommonWebPaths.PATH_SEPERATOR + 'v2.0';
    private static readonly BASE_PATH = CommonWebPaths.PATH_SEPERATOR+ 'api'+ CommonWebPaths.PLATFORM_VERSION;
    private static readonly PLATFORM_SERVICE = CommonWebPaths.PATH_SEPERATOR +Module.PLATFORM;
    private static readonly ADMIN_SERVICE = CommonWebPaths.PATH_SEPERATOR +Module.ADMIN;
    private static readonly AUTH_SERVICE = CommonWebPaths.PATH_SEPERATOR +Module.AUTH;
    private static readonly ESI_SERVICE = CommonWebPaths.PATH_SEPERATOR+ Module.ESI;
    private static readonly AUTOMATION_SERVICE = CommonWebPaths.PATH_SEPERATOR+ Module.AUTOMATION;
    private static readonly METRICES_SERVICE = CommonWebPaths.PATH_SEPERATOR+ Module.METRICS;
    // ==========Public ========================
    public static readonly PLATFORM_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.PLATFORM_SERVICE;
    public static readonly ADMIN_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.ADMIN_SERVICE;
    public static readonly AUTH_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.AUTH_SERVICE;
    public static readonly ESI_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.ESI_SERVICE;
    public static readonly AUTOMATION_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.AUTOMATION_SERVICE;
    public static readonly METRICES_SERVICE_BASE_PATH = CommonWebPaths.BASE_PATH + CommonWebPaths.METRICES_SERVICE;
    public static readonly HEALTH_CHECK_API_PATH = CommonWebPaths.PATH_SEPERATOR +'health';

    public static getBasePath(module:Module){
        return this.BASE_PATH + CommonWebPaths.PATH_SEPERATOR + module + CommonWebPaths.PATH_SEPERATOR;
    }

    public static getfullPath(module:Module){
      return   CommonWebPaths.getDomain(module) + this.getBasePath(module);
    }

    public static getDomain(module:Module){
      return   EnvironmentParams.getModuleDomain(module);
  }
  
}
