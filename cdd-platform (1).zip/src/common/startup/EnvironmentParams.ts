import { ModuleEnv, Environment } from './../model/Environment';
import { Module, ServerMode } from './../enums/PlatformEnums';
import { LoggingUtil } from '../utils/log4js';
import { DataBaseParams } from '../model/DataBaseParams';

import { config } from 'dotenv';
import * as path from 'path';

export class EnvironmentParams {
    private static modules: ModuleEnv[];
    private static cache: Map<Module, ModuleEnv>;
    private static domainCache: Map<Module, string>;
    private static environment: Environment;
    private static dataBaseParams: DataBaseParams;

    public static getModuleEnv(module: Module): ModuleEnv {
        EnvironmentParams.getEnvironment();
        return EnvironmentParams.cache.get(module);
    }

    public static getModuleDomain(module: Module): string {
        EnvironmentParams.getEnvironment();
        return EnvironmentParams.domainCache.get(module);
    }
    
    public static getDBParams(): DataBaseParams{
        EnvironmentParams.getEnvironment();
        return EnvironmentParams.dataBaseParams;
    }
    public static contains(module: Module): boolean {
        EnvironmentParams.getEnvironment();
        return EnvironmentParams.cache.has(module);
    }

    public static getEnvironment(): Environment {
        if (!EnvironmentParams.environment) {
            EnvironmentParams.cache = new Map<Module, ModuleEnv>();
            EnvironmentParams.domainCache = new Map<Module, string>();
            EnvironmentParams.initEnvironment();

        }

        return EnvironmentParams.environment;
    }
    // ==========private methods===========
    private static initEnvironment() {


        const ENV_FILE = path.join(__dirname, '..', '.env');
        config({ path: ENV_FILE });

        EnvironmentParams.environment = new Environment();
        EnvironmentParams.environment.microsoftAppId = process.env.MicrosoftAppId;
        EnvironmentParams.environment.microsoftAppPassword = process.env.MicrosoftAppPassword;
        EnvironmentParams.environment.luisAppId = process.env.LuisAppId;
        EnvironmentParams.environment.luisAPIKey = process.env.LuisAPIKey;
        EnvironmentParams.environment.luisAPIHostName = process.env.LuisAPIHostName;
        EnvironmentParams.environment.serverPort = Number(process.env.platform_service_port);

        EnvironmentParams.environment.storageType = process.env.StorageType;
        EnvironmentParams.environment.defaultLang = process.env.DefaultLanguage;
        EnvironmentParams.environment.deploymentEnv = process.env.platform_deployment_env
        EnvironmentParams.environment.tenantConfigSrc = process.env.tenant_config_src
        const tmp = process.env.plaform_modules.split(',');
        EnvironmentParams.environment.dynaTranslatorFlag = (process.env.dyna_translator_flag == "true");

        EnvironmentParams.modules = [];
        for (var vals of tmp) {
            const tokens = vals.split(':');
            const modEnv = new ModuleEnv();
            LoggingUtil.log.debug(` Token: ${vals}, ${tokens}, ${tokens[0]}, ${tokens[1]} `);
            modEnv.module = Module[tokens[0]];
            modEnv.port = Number(tokens[1]);
            EnvironmentParams.modules.push(modEnv); // prints values: 10, 20, 30, 40
            EnvironmentParams.cache.set(modEnv.module, modEnv);
        }
        EnvironmentParams.environment.modules = EnvironmentParams.modules
        const mode = process.env.platform_server_mode;
        EnvironmentParams.environment.serverMode = ServerMode[mode];

        EnvironmentParams.environment.keyvaultName = process.env.keyvaultName;
        EnvironmentParams.environment.keyvaultState = process.env.keyvaultState;
        EnvironmentParams.environment.logfile = process.env.logfile;
        EnvironmentParams.environment.loglevel = process.env.loglevel;


        EnvironmentParams.domainCache.set(Module.PLATFORM, process.env.platform_domain_name);
        EnvironmentParams.domainCache.set(Module.ADMIN, process.env.admin_domain_name);
        EnvironmentParams.domainCache.set(Module.ESI, process.env.esi_domain_name);
        EnvironmentParams.domainCache.set(Module.METRICS, process.env.metrics_domain_name);
        EnvironmentParams.domainCache.set(Module.AUTH, process.env.auth_domain_name);
        EnvironmentParams.domainCache.set(Module.AUTOMATION, process.env.automation_domain_name);
        EnvironmentParams.domainCache.set(Module.EMAIL, process.env.email_domain_name);
        EnvironmentParams.domainCache.set(Module.TWILIO, process.env.twilio_domain_name);

        EnvironmentParams.dataBaseParams = new DataBaseParams();
        EnvironmentParams.dataBaseParams.cosmosDbConnectionString = process.env.cosmos_db_connection_string
        EnvironmentParams.dataBaseParams.cosmosDbName = process.env.cosmos_db_name
        
        EnvironmentParams.dataBaseParams.redisCacheHostname = process.env.redis_cache_hostname;
        EnvironmentParams.dataBaseParams.redisCacheKey = process.env.redis_cache_key;
        EnvironmentParams.dataBaseParams.redisCachePort = process.env.redis_cache_port;


        EnvironmentParams.dataBaseParams = new DataBaseParams();
        EnvironmentParams.dataBaseParams.cosmosDbConnectionString = process.env.cosmos_db_connection_string
        EnvironmentParams.dataBaseParams.cosmosDbName = process.env.cosmos_db_name

        EnvironmentParams.dataBaseParams.redisCacheHostname = process.env.redis_cache_hostname
        EnvironmentParams.dataBaseParams.redisCacheKey = process.env.redis_cache_key
        EnvironmentParams.dataBaseParams.redisCachePort = process.env.redis_cache_port

    }

}