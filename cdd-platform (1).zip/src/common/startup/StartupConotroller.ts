import { TwilioRouter } from './../../twilio/routes/TwilioRouter';
import { EmailRouter } from './../../email/routes/EmailRouter';
import { MetricsRouter } from './../../metrics/routes/MetricsRouter';
import { EsiRouter } from './../../esi/routes/EsiRouter';
import { AutoRouter } from './../../automation/routes/AutoRouter';
import { CompositeWebAppConfig } from './../web/CompositeWebAppConfig';
import { SimpleApplicationContext } from './../core/SimpleApplicationContext';
import { AdminRouter } from './../../admin/routes/AdminRouter';
import { Environment } from './../model/Environment';
import { Module, ServerMode } from './../enums/PlatformEnums';
import { PlatformApplicationContext } from './../../pltaform/core/PlatformApplicationContext';

import { EnvironmentParams } from './EnvironmentParams';

import { WebAppConfig } from '../web/WebAppConfig';
import { BaseAppContext } from '../core/BaseAppContext';
import { BaseRouter } from '../web/BaseRouter';
import { AuthRouter } from '../../auth/routes/AuthRouter';
import { LoggingUtil } from '../utils/log4js';



export class StartupConotroller{
    private static instance: StartupConotroller;
    private appCtxs:BaseAppContext[];
    private environment:Environment;
    private cache: Map<Module, BaseAppContext>;

    private constructor(){      
        this.cache = new Map<Module, BaseAppContext>();
        this.appCtxs = [PlatformApplicationContext.getInstance(),
                        new SimpleApplicationContext(Module.ADMIN,new AdminRouter()),
                        new SimpleApplicationContext(Module.AUTH,new AuthRouter()),
                        new SimpleApplicationContext(Module.AUTOMATION,new AutoRouter()),
                        new SimpleApplicationContext(Module.ESI,new EsiRouter()),
                        new SimpleApplicationContext(Module.METRICS, new MetricsRouter()),
                        new SimpleApplicationContext(Module.EMAIL, new EmailRouter()),
                        new SimpleApplicationContext(Module.TWILIO, new TwilioRouter())

                      ];
        LoggingUtil.log.info(`====>>>Module ${EnvironmentParams.getEnvironment().modules}`);


        for (const ctx of this.appCtxs) {
          
          if(EnvironmentParams.contains(ctx.getModule())) {
            LoggingUtil.log.info(`====>>> ${ctx.getModule()}`);
               this.cache.set(ctx.getModule(), ctx);
           }
        }
    }

    public static getInstance(): StartupConotroller {
      if (StartupConotroller.instance == null) {
        StartupConotroller.instance = new StartupConotroller();
      }
      return StartupConotroller.instance;
    }


    public  init() {
      LoggingUtil.log.info('start of sartup controller ...');
        this.environment = EnvironmentParams.getEnvironment();
        const webCnf = new CompositeWebAppConfig();
      //   const isMultipleServer = !(this.environment.serverMode === ServerMode.SINGLE);
        for (const val of this.environment.modules) {
          LoggingUtil.log.info(`----Module-----: ${val.module} & ${val.port}`);
           const ctx = this.cache.get(val.module);
           ctx.init();
           webCnf.addRouter(ctx.getRouter());
         }
         webCnf.initApp();
         LoggingUtil.log.info(`End of sartup controller ...`);
   }

}