export enum Module {
    PLATFORM = 'platform',
    ADMIN = 'admin',
    AUTH = 'auth',
    ESI = 'esi',
    AUTOMATION = 'automation',
    METRICS = 'metrics',
    EMAIL = 'email',
    TWILIO = 'twilio'
}

export enum DeploymentEnv{
    LOCAL='LOCAL',DEV='DEV',UAT='UAT',PROD='PROD'
}
export enum SourceConfig{
    File='File',CosmosDB='CosmosDB',MySQL='MySQL'
}

export enum ServerMode{
    SINGLE, MULTIPLE
}

export enum NLP{
    LUIS='LUIS', QnA='QnA',LEX='LEX',Dialogflow='Dialogflow', 
    Composite='Composite',Simple='Simple',Dummy='Dummy'
}

export enum ExternalApp{
    ServiceNow='ServiceNow', Remedy='Remedy'
}
export enum ExternalAppCategory{
    ITSM='ITSM', Others='Others'
}

// export enum ItsmOperation{
//     Query_Incident='Query_Incident', 
//     Create_Incident='Create_Incident',
//     Service_Request_Status_By_User='ServiceRequestStatusByUser',
//     Service_Request_Status='Service_Request_Status'
// }

export enum ItsmRequestType {
    IncidentCategories = 'getIncidentCategories',
    Priorites='getPriorites',
    UserDetailsByUserName='getUserDetailsByUserName',
    CreateIncident='createIncident',
    CreateInteraction='createInteraction',
    ModifyIncident='modifyIncident',
    ReadIncident='getIncident',
    SysId='getSysI',
    CreateSR = 'createSR',
    ReadMultipleIncidents='getIncidents',
    ServiceRequestStatus='getServiceRequestStatus',
    ServiceRequestStatusByUser='getServiceRequestStatusByUser',
    Outages='getOutages',
    AssetDetailsByUserSysId='getAssetDetailsByUserSysId',
    AddAttachmentToIncident='AddAttachmentToIncident',
    // updateIncident,
    GetSCvariables = 'getVariablesOfCatalog',
    GetSpecificKnowledgeArticle = 'getSpecificKnowledgeArticle',
    AddInCartSC = 'addInCartCatalog',
    SubmitOrderSC = 'submitOrderCatalog',
    KnowledgeArticles = 'getKnowledgeArticles',
    HardwareAssets='getHardwareAssets',
    SoftwareAssets='getSoftwareAssets',
    SysIdOfCatalogItem='getSysIdOfCatalogItem',
    Allcatalogitems='getallcatalogitems',
    BuyItem='getallcatalogitems',
    CreateServiceRequest='createServiceRequest',
    AddAttachment='addAttachment',
    AddAttachmentWithGetCall='addAttachmentWithGetCall',
    UserDetails='getUserDetails',
    ModifyUserDetails='modifyUserDetails',
    Manager='getManager',
    searchServiceCatalog='searchServiceCatalog'
}
