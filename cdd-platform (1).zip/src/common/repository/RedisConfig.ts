import { LoggingUtil } from './../utils/log4js';
import { EnvironmentParams } from './../startup/EnvironmentParams';
import{ RedisClient } from 'redis'
// var redis = require("redis");
const Redis = require("redis");
// const client = redis.createClient();

export class RedisConfigClient {
    protected client:RedisClient;

    private static redisClient:RedisClient;

    
    public static getConnection() {
        if(RedisConfigClient.redisClient)
          return RedisConfigClient.redisClient

        try{            
            RedisConfigClient.redisClient = Redis.createClient(
                EnvironmentParams.getDBParams().redisCachePort, 
                EnvironmentParams.getDBParams().redisCacheHostname, 
                {   auth_pass: EnvironmentParams.getDBParams().redisCacheKey, 
                    tls: {servername: EnvironmentParams.getDBParams().redisCacheHostname}});
             return RedisConfigClient.redisClient
        }catch(error){
            LoggingUtil.log.error('Fetching records failed',error)
        }         
    }
    public async hashDelete(hashName:string,fieldName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hdel(hashName,fieldName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }


}