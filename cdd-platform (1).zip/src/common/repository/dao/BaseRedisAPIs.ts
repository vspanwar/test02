import{ RedisClient } from 'redis' 
import { LoggingUtil } from '../../utils/log4js';
import { RedisConfigClient } from '../RedisConfig';


export class BaseRedisAPIs {
    protected client:RedisClient;

    constructor(){
        this.client = RedisConfigClient.getConnection()
    }

    /* Redis String APIs */
    public async stringSet(stringName:string,value:string):Promise<any>{
        return new Promise((resolve,reject)=>{
            if (!(typeof value == "string" || typeof value == "number")) {
                throw new TypeError("Value parameter must be a string or number");
            }

            this.client.set(stringName, value,(err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async stringGet(StringName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.get(StringName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    /* Redis Hashes APIs*/
    public async hashGet(hashName:string,fieldName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hget(hashName, fieldName,(err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async hashExists(hashName:string,fieldName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hexists(hashName, fieldName,(err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async hashSet(hashName:string,fieldName:string,value:string):Promise<any>{
        LoggingUtil.log.debug("name: "+hashName+" :fieldname: "+fieldName+" :value: "+value);
        return new Promise((resolve,reject)=>{
            if (!(typeof value == "string" || typeof value == "number")) {
                throw new TypeError("Value parameter must be a string or number");
            }
            this.client.hset(hashName,fieldName,value, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async hashDelete(hashName:string,fieldName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hdel(hashName,fieldName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async hashLength(hashName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hlen(hashName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    
    public async hashGetAll(hashName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hgetall(hashName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async hashGetValues(hashName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hvals(hashName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    //scans key based in pattern and provide matched values from '0'th pointer
    /** 
    
    *suppose you want to find `'Cbo Mfdm Bot'` key then, pattern would be like `Cbo*` or `*Bot` or `*Mfdm*` in response will get all matching results from given hash   
    
    */
    public async hashScan(hashName:string,pattern:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.hscan(hashName,"0",'MATCH',pattern ,(err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    /* Redis LIST APIs */
    public async listPush(listName:string,value:any):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.lpush(listName,value, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async listPushFromTail(listName:string,value:any):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.rpush(listName,value, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async listPopFromStart(listName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.lpop(listName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async listPopFromEnd(listName:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.rpop(listName, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    public async listRange(listName:string,start:number,end:number):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.lrange(listName,start,end, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    /* Redis Set APIs */
    public async setAdd(setName:string,value:string):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.sadd(setName,value, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }

    /* Redis Sorted Set APIs*/
    public async sortedSetAdd(setName:string,score:number,value:number):Promise<any>{
        return new Promise((resolve,reject)=>{

            this.client.zadd(setName,score,value, (err: Error, reply: any) => {
                if (err !== null) {
                    reject(err);
                }

                resolve(reply);
            });
            
        })
    }
}