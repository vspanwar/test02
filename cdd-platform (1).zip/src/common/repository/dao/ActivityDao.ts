import { BaseDao } from './../BaseDao';


export class ActivityDao extends BaseDao{

    
}