import { EnvironmentParams } from './../startup/EnvironmentParams';
import { MongoClient, Db } from 'mongodb';
import { LoggingUtil } from '../utils/log4js';
var util = require('util')
export class MongoConfig{

    // private static url="mongodb://cdddb:x41fM7ppD9WcC0K6yICuStEv4fR4Ckg3ACfplhIbvwES17tLxOPiex7nOEdkEUpE4jPg7qinBXMKJYmcOrIecA==@cdddb.mongo.cosmos.azure.com:10255?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdddb@"

    private static dbConnection:Db;

    public static async getDBConnection(): Db {

        if(MongoConfig.dbConnection)
           return MongoConfig.dbConnection
        
        let client: MongoClient
        try{            
            client =await MongoClient.connect(EnvironmentParams.getDBParams().cosmosDbConnectionString 
            ,{ useUnifiedTopology: true })
            MongoConfig.dbConnection=client.db(EnvironmentParams.getDBParams().cosmosDbName) //
            
            return MongoConfig.dbConnection
        }catch(error){
            
            LoggingUtil.log.info(`Fetching records failed!`)
            LoggingUtil.log.info(error)
            
            return error
        }
         
    }
}