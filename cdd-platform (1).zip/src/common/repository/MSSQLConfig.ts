import { EnvironmentParams } from './../startup/EnvironmentParams';
import { MongoClient, Db } from 'mongodb';
import { LoggingUtil } from '../utils/log4js';
import {Request,Connection } from 'tedious'
var util = require('util')
export class MSSQLConfig{

    // private static url="mongodb://cdddb:x41fM7ppD9WcC0K6yICuStEv4fR4Ckg3ACfplhIbvwES17tLxOPiex7nOEdkEUpE4jPg7qinBXMKJYmcOrIecA==@cdddb.mongo.cosmos.azure.com:10255?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdddb@"

    private static dbConnection;

    public static async getDBConnection() {

        if(MSSQLConfig.dbConnection)
           return MSSQLConfig.dbConnection
        
        //let client
        try{            
           
            let dbname = 'ipsoftaudit'
            var config = 
            {  
                server: 'aznc-rpasqld001.corp.duracell.com',
                // process.env.sql_server,
               
                authentication: {
                    type: 'default',
                    options: {
                        // userName: await KeyVaultService.getInstance().getKey('SQLusername'), 
                        // password: await KeyVaultService.getInstance().getKey('SqlToken')
    
                        userName: 'ms_bf',
                        password: 'jJN5&2P9B5AZT3S6q&u@'
                    }
                },
                options: {
                
                    encrypt: true,
                    database: dbname
                    //'ipsoftaudit' 
                }       
            }; 

     
            MSSQLConfig.dbConnection = await new Connection(config)
            return MSSQLConfig.dbConnection

        }catch(error){
            
            LoggingUtil.log.info(`Error in connecting MSSQL`)
            LoggingUtil.log.info(error)
            
            return error
        }
         
    }

    public async getDBdetails()
    {
         // let dbname = process.env.DatabaseName
        // let tablename = process.env.TableName
        let data = {
            dbname:'ipsoftaudit',
            tablename:'mbf_history'
        }
        return data
    }

    public async getConfig(){
        let db = await this.getDBdetails()
        let dbname = db.dbname
        var config = 
        {  
            server: 'aznc-rpasqld001.corp.duracell.com',
            // process.env.sql_server,
           
            authentication: {
                type: 'default',
                options: {
                    // userName: await KeyVaultService.getInstance().getKey('SQLusername'), 
                    // password: await KeyVaultService.getInstance().getKey('SqlToken')

                    userName: 'ms_bf',
                    password: 'jJN5&2P9B5AZT3S6q&u@'
                }
            },
            options: {
            
                encrypt: true,
                database: dbname
                //'ipsoftaudit' 
            }       
        }; 
        return config
    }
}