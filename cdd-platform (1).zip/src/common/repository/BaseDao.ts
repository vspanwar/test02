import { MongoConfig } from "./MongoConfig";

import { MongoClient, Db } from "mongodb";
import { LoggingUtil } from "../utils/log4js";
var util = require('util')
export class BaseDao{

    /*private static baseDao: BaseDao;
    public static getInstance(): BaseDao {

        if (BaseDao.baseDao == null) {
            BaseDao.baseDao = new BaseDao()
        }
        
        return BaseDao.baseDao;
    }*/
    
    constructor(private collection: string){

    }

    public async findAll(): Promise<any> {
        
            console.log("Enetred in the BaseDao find() : ");
            let db=await MongoConfig.getDBConnection()
            try{
                
                let result= await db.collection(this.collection).find().toArray()
                
                return result
            }catch(error){
                console.log(`Fetching records failed!`)
                console.log(error)
                return error
            }

            

    }   

    public async getAllData(){
        let db=await MongoConfig.getDBConnection()
        try{
            //console.log("payload " + JSON.stringify(payload['query'])  + " filter" + JSON.stringify(payload['filter']))
            let result= await db.collection(this.collection).find().toArray()

            return result
        }catch(error){
            console.log(`Fetching records failed!`)
            console.log(error)
            return error
        }
    }



    public async query(payload:any): Promise<any> {
        let db=await MongoConfig.getDBConnection()
        try{
            console.log("payload " + JSON.stringify(payload['query'])  + " filter" + JSON.stringify(payload['filter']))
            let result= await db.collection(this.collection).find(payload['query'], payload['filter']).toArray()

            return result
        }catch(error){
            console.log(`Fetching records failed!`)
            console.log(error)
            return error
        }
    }
    public async create(payload:any): Promise<any> {
        let db=await MongoConfig.getDBConnection()
        console.log("base dao datatype",typeof(payload.date),payload.date)
        try{
            console.log("payload " + JSON.stringify(payload) )
            let result= await db.collection(this.collection).insertOne(payload)

            return result
        }catch(error){
            console.log(`Fetching records failed!`)
            console.log(error)
            return error
        }
    }

    public async add(query:any, data:any): Promise<any> { //push()
        let db=await MongoConfig.getDBConnection()
        try{
            console.log("query " + JSON.stringify(query))
            console.log("data " + JSON.stringify(data))
            LoggingUtil.log.debug("payload " + JSON.stringify(data) + "query" + JSON.stringify(query))
            let result= await db.collection(this.collection).updateOne(query,{$push:data})
            
            return result
        }catch(error){
            console.log(`add record failed!`)
            console.log(error)
            return error
        }
    }

    public async replace(filter:any, newDocument:any){
        let db=await MongoConfig.getDBConnection()
        try{
            let result = await db.collection(this.collection).replaceOne(filter,newDocument)
            LoggingUtil.log.debug("filter " + JSON.stringify(filter) + "newDocument" + JSON.stringify(newDocument))
            return result
        }
        catch(error){
            console.log("replace record failed..!")
            console.log(error)
            return error
        }
    }


    public async delete(): Promise<any> {
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).remove()
            console.log('Deletion successfully')
            return result
        }catch(error){
            console.log(`Deletion records failed!`)
            console.log(error)
            return error
        }
    }

    public async getMax(query:any):Promise<any>{ //getScalar()*
        LoggingUtil.log.debug(query)
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).find().sort(query).toArray()
            console.log("result"+ JSON.stringify(result))
            return result
        }catch(error){
            console.log(error)
            return error
        }
    }

    public async getMaxbyID(payload : any , query:any):Promise<any>{ //getScalar()*
        LoggingUtil.log.debug(query)
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).find(payload).sort(query).limit(1).toArray()
            console.log("result"+ JSON.stringify(result))
            return result
        }catch(error){
            console.log(error)
            return error
        }
    }

    public async getMaxFromArray(arrayName:any, fieldOfArray:any, queryData:any):Promise<any>{

        LoggingUtil.log.debug(arrayName + " " + fieldOfArray)
        let db=await MongoConfig.getDBConnection()
        try{
            let query=queryData
            let result= await db.collection(this.collection).aggregate([
                
                {$match : query},
                {$unwind :"$" + arrayName}, 
                {$group : {_id:null, max: {$max:'$' + fieldOfArray}}},
                {$project:{max:1, _id:0}},
            ]).toArray()
            console.log(result)
            
            return result[0]
        }catch(error){

        }
    }

    public async aggregate(payload:any):Promise<any>{

        LoggingUtil.log.debug(payload['match'] + "---------->" + payload['project'])
        let db=await MongoConfig.getDBConnection()
        try{
            
            let result= await db.collection(this.collection).aggregate([
                payload['match'],
                payload['project']]).toArray()
            console.log(result)

            return result[0]
        }catch(error){

        }
    }

    public async updateInArray(query:any , payload:any, filters){
        LoggingUtil.log.debug(query)
        LoggingUtil.log.debug(payload)
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).updateOne(query,
                {$set: payload},
                {arrayFilters:filters})
            console.log(result)

            return result
        }catch(error){

        }
    }

    public async update(query:any, payload:any):Promise<any>{
        LoggingUtil.log.debug(query)
        LoggingUtil.log.debug(payload)
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).updateOne(query,{$set: payload})
            console.log(result)

            return result
        }catch(error){

        }

    }

    public async updateMany(query:any, payload:any):Promise<any>{
        LoggingUtil.log.debug("inside update--------->" + JSON.stringify(query) + "---------->" + JSON.stringify(payload))
        LoggingUtil.log.debug(query)
        LoggingUtil.log.debug(payload)
        let db=await MongoConfig.getDBConnection()
        try{
            let result= await db.collection(this.collection).updateMany(query,{$set: payload})
            console.log("update result ---> " + JSON.stringify(result))

            return result
        }catch(error){

        }

    }
    
}