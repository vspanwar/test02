import { LoggingUtil } from './../log4js';
import { IntentResult } from './IntentResult';
import { RecognizerResult } from "botbuilder";

export abstract class BaseRecognizer {
    public  async recognize(context:any): Promise<IntentResult>{
        try {
            this.preProcess(context);
            const result = await this.onRecognize(context);
            //console.log("}}}}}}}}}" ,result)
            result.sourceNlp = this.getName();
            this.postProcess(result);
            return result;
        } catch (error) {
            console.error(error);
        }
    }

    public getUtterence(context:any){
        const utterance: string = context.activity.text || '';
        return utterance;
    }

    private preProcess(context:any){
        const utterance = this.getUtterence(context);
        LoggingUtil.log.debug(`[${this.getName()}] User utterence ${utterance} `);
    }

    private postProcess(result:IntentResult){

        result.topIntent = result.topIntent.replace(/_/g, '.');
        LoggingUtil.log.debug(`[${this.getName()}] Intent  ${result.topIntent}`);
    }

    public abstract onRecognize(context:any): Promise<IntentResult>;
    public abstract  getName(): string;

}