import { LoggingUtil } from './../../log4js';
import { NLP } from './../../../enums/PlatformEnums';
import { IntentResult } from './../IntentResult';
import { PlatformApplicationContext } from '../../../../pltaform/core/PlatformApplicationContext';
import { LuisApplication, LuisRecognizer, LuisRecognizerOptionsV3 } from 'botbuilder-ai';
import { RecognizerResult, TurnContext, getTopScoringIntent } from "botbuilder";
import { WaterfallStepContext } from 'botbuilder-dialogs';
import { BaseRecognizer } from '../BaseRecognizer';
// const { LuisRecognizer } = require('botbuilder-ai');

export class Luis extends BaseRecognizer{

    private recognizer:LuisRecognizer;

    constructor(nlp:any){
        super();
        const env =  PlatformApplicationContext.getInstance().getEnvironment();
        const luisApp = { applicationId: nlp.appId, 
                          endpointKey: nlp.luisAPIKey, 
                          endpoint: nlp.host };
        const recognizerOptions: LuisRecognizerOptionsV3 = {
                            apiVersion : 'v3'
                        };
        this.recognizer = new LuisRecognizer(luisApp, recognizerOptions);
    }

    /**
     *
     * @param context
     */
    public async onRecognize(context:any): Promise<IntentResult> {
        
        const luisResult = await this.recognizer.recognize(context);
        const topIntent =  LuisRecognizer.topIntent(luisResult);
        //LoggingUtil.log.debug(`LUIS-------------------${topIntent}`)
        const topResult = getTopScoringIntent(luisResult);
        const result = new IntentResult();
        result.entities = luisResult.entities;
        result.topIntent = topResult.intent;
        result.topScore = topResult.score;
        result.intents =  luisResult.intents
        return result;
    }
    public getName(): string {
        return NLP.LUIS.toString();

    }

}


