import { NLP } from './../../../enums/PlatformEnums';
import { IntentResult } from './../IntentResult';
import { BaseRecognizer } from "../BaseRecognizer";

export class SimpleRecognizer extends BaseRecognizer {

    constructor(){
        super();
    }

    public async onRecognize(context:any): Promise<IntentResult> {
        const result = new IntentResult();
        // result.entities = luisResult.entities;
        result.topIntent = 'DateResolverDialog';
        result.topScore = .90
        return result;
    }
    public getName(): string {
        return NLP.Simple.toString();

    }

}