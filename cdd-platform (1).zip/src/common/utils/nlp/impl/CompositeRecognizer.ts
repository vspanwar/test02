import { Dialogflow } from './Dialogflow';
import { AwsLex } from './AwsLex';
import { Qnamaker } from './Qnamaker';
import { DummyNLP } from './DummyRecognizer';

import { Luis } from './Luis';


import { IntentResult } from '../IntentResult';
import { BaseRecognizer } from "../BaseRecognizer";
import { NLP } from '../../../enums/PlatformEnums';

export class CompositeRecognizer extends  BaseRecognizer{
    private nlpApps:BaseRecognizer[];

    constructor(bot:any){
        super();
        this.nlpApps= [];
        for (let nlp of bot.nlpApps) {

            //console.log("&&&&&&&&&&&", nlp.type)
            const nplApp = (nlp.type === NLP.LUIS)? new Luis(nlp):
                           (nlp.type === NLP.QnA)? new Qnamaker(nlp):
                           (nlp.type === NLP.LEX)? new AwsLex(nlp):
                           (nlp.type === NLP.Dialogflow)? new Dialogflow(nlp):
                           new DummyNLP();
            if(nlp.isActive) {
               this.nlpApps.push(nplApp);
            }
        }
    }


    public async onRecognize(context:any): Promise<IntentResult> {
        let result:IntentResult = new IntentResult();
        result.topScore = 0;
        for (let apps of this.nlpApps) {
            const tmp = await apps.recognize(context);
            result = (tmp.topScore > result.topScore)?tmp:result;
        }

        return result;
    }
    public getName(): string {
        return NLP.Composite.toString();

    }
}