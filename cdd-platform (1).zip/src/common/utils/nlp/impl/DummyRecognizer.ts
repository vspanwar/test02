import { NLP } from './../../../enums/PlatformEnums';
import { IntentResult } from '../IntentResult';
import { BaseRecognizer } from '../BaseRecognizer';
// const { LuisRecognizer } = require('botbuilder-ai');

export class DummyNLP extends BaseRecognizer {

    constructor(){
        super();
    }

    /**
     *
     * @param context
     */
    public async onRecognize(context:any): Promise<IntentResult> {
        const result = new IntentResult();
        // result.entities = luisResult.entities;
        result.topIntent = 'Unknown';
        result.topScore = .50
        return result;
    }
    public getName(): string {
        return NLP.Dummy.toString();

    }

}


