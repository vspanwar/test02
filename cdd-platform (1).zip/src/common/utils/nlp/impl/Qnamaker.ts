import { NLP } from './../../../enums/PlatformEnums';
import { IntentResult } from './../IntentResult';
import { BaseRecognizer } from "../BaseRecognizer";
import {QnAMaker,QnAMakerOptions} from 'botbuilder-ai'
import { LoggingUtil } from '../../log4js';

export class Qnamaker extends BaseRecognizer{
    private recognizer:QnAMaker;

    constructor(nlp:any){
        super();
        const qnaApp = { knowledgeBaseId: nlp.appId, 
                         endpointKey: nlp.EndpointKey, 
                         host: nlp.host };

        const recognizerOptions: QnAMakerOptions = {
            scoreThreshold : 0.3
        };
        this.recognizer = new QnAMaker(qnaApp, recognizerOptions);
    }

     public async onRecognize(context: any): Promise<IntentResult> {
        const qnaResult = await this.recognizer.getAnswers(context);
        const result = new IntentResult();
        try{
            result.topIntent = 'qnamaker.base.dialog';
            result.topScore = qnaResult[0].score;
            result.context = qnaResult[0].context;
            result.id = qnaResult[0].id;
            result.answer = qnaResult[0].answer;
    
            LoggingUtil.log.info("qna result"+JSON.stringify(result));
        }catch(err){
            LoggingUtil.log.error("error in QNA:"+err)
        }
         return result;
    }
    
    public getName(): string {
        return NLP.QnA.toString();

    }
}