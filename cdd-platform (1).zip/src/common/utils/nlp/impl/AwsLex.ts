import { NLP } from './../../../enums/PlatformEnums';
import { IntentResult } from '../IntentResult';
import { BaseRecognizer } from "../BaseRecognizer";

export class AwsLex extends BaseRecognizer{
    constructor(nlp:any){
        super();
    }
    public onRecognize(context: any): Promise<IntentResult> {
        throw new Error("Method not implemented.");
    }

    public getName(): string {
        return NLP.LUIS.toString();

    }
}