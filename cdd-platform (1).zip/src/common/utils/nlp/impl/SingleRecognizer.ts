import { Dialogflow } from './Dialogflow';
import { AwsLex } from './AwsLex';
import { Qnamaker } from './Qnamaker';
import { DummyNLP } from './DummyRecognizer';

import { Luis } from './Luis';


import { IntentResult } from '../IntentResult';
import { BaseRecognizer } from "../BaseRecognizer";
import { NLP } from '../../../enums/PlatformEnums';

export class SingleRecognizer extends  BaseRecognizer{
    private nlpApps:BaseRecognizer[];
    private nlpApp:BaseRecognizer;
    private _type:NLP;
    constructor(bot:any){
        super();
        this.nlpApps= [];
        
        for (let nlp of bot.nlpApps) {
            //console.log("##############" , nlp.type)
            const nlpApps = (nlp.type === NLP.LUIS)? new Luis(nlp):
                           (nlp.type === NLP.QnA)? new Qnamaker(nlp):
                           (nlp.type === NLP.LEX)? new AwsLex(nlp):
                           (nlp.type === NLP.Dialogflow)? new Dialogflow(nlp):
                           new DummyNLP();
            if(nlp.isActive) {
               //console.log("SSSSSSSSSSSSS" , this.nlpApps)
               this.nlpApps.push(nlpApps);

               //console.log("!!!!!!!!!",this.nlpApps)
            }
        }
        this.nlpApp = this.nlpApps[0];
        //console.log("@@@@@@@@@@@@" , this.nlpApp)
    }

    public set type (nlp:NLP){
        this._type = nlp;
        //console.log("aaaaaaaaaaaaaaaaaaaa",nlp)

        for (let nlpApp of this.nlpApps) {
            if(nlp === nlpApp.getName()) {
                this.nlpApp = nlpApp;
        }
     }
    }


    public async onRecognize(context:any): Promise<IntentResult> {
        let result:IntentResult = new IntentResult(); 
        //console.log("aaaaaaaaaaaa" , this.nlpApp)              
        result = await this.nlpApp.recognize(context);
        return result;
    }

    public getName(): string {
        return NLP.Composite.toString();

    }
}