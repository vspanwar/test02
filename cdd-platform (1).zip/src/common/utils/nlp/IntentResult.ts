export class IntentResult {
    /**
     * Utterance sent to recognizer
     */
    public text: string;

    /**
     * If original text is changed by things like spelling, the altered version.
     */
    public alteredText?: string;

    /**
     * Intents recognized for the utterance.
     *
     * @remarks
     * A map of intent names to an object with score is returned.
     */
    public intents: { [name: string]: { score: number } };

    /**
     * (Optional) entities recognized.
     */
    public entities?: any;

    public topIntent:string;
    public topScore:number;
    public sourceNlp:string;
    public context?:any;
    public id?:any;
    public answer?:any;
    /**
     * (Optional) other properties
     */
    [propName: string]: any;
}