import { TurnContext } from "botbuilder";

export interface ITimeoutProps {
    context: TurnContext;
    promptHandler: any;
    endConvoHandler: any;
}

export class TimeoutStore {
    private readonly store = new Map<string, ITimeoutProps>();

    public storeConvoIdAndSession(id: string, context: TurnContext) {
        const props = { context, promptHandler: false, endConvoHandler: false} as ITimeoutProps;
        this.store.set(id, props);
    }

    public setPromptHandlerFor(id: string, value: any): void {
        this.store.get(id).promptHandler = value;
    }

    public setEndConvoHandlerFor(id: string, value: any): void {
        this.store.get(id).endConvoHandler = value;
    }

    public getPromptHandlerFor(id: string): any {
        return this.store.get(id).promptHandler;
    }

    public getEndConvoHandlerFor(id: string): any {
        return this.store.get(id).endConvoHandler;
    }

    public getSessionFor(id: string): TurnContext {
        return this.store.get(id).context;
    }

    public isValid(id: string):boolean {
        return this.store.has(id);
    }

    public removeConvoFromStore(id: string): boolean {
        return this.store.delete(id);
    }


}
