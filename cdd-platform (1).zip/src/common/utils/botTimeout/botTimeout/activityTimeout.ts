import { TurnContext, Activity, BotAdapter } from "botbuilder";
import { BasePlatformBot } from "../../../../pltaform/core/bot/BasePlatformBot";
import { Timeout } from "./timeout";
import { LoggingUtil } from "../../log4js";

export class ActivityTimeout {

    private timeOut: Timeout = null;

    constructor(basePlatformBot: BasePlatformBot) {
        this.timeOut = new Timeout();
        basePlatformBot.onConversationUpdate(async (context: TurnContext, next) => {
            LoggingUtil.log.debug("** Conversation add in Timer Mapt");
            this.timeOut.onUpdate(context);
            await next();
        });

        basePlatformBot.onTurn(async (context: TurnContext, next) => {

            if (context.activity.channelId === "msteams" &&  !this.timeOut.timeoutStore.isValid(context.activity.conversation.id)){
                this.timeOut.onUpdate(context);
            }

            if (context.activity.from.role === 'user' && context.activity.type==="message") {
                LoggingUtil.log.debug("** Activity from User");
                this.timeOut.onReceive(context);
            }

            context.onSendActivities(async (sendContext: TurnContext, activities: Partial<Activity>[], nextSend) => {
                activities.filter(a => a.type !== 'typing' && a.type !== 'endOfConversation').forEach(a => {
                    LoggingUtil.log.debug("** Activity from Bot");
                    this.timeOut.onSend(context);
                });
                return nextSend();

            });
            await next();
        });
    }
}