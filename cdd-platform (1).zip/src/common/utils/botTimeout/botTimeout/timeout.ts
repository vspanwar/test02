import {  Activity, BotAdapter, TurnContext } from "botbuilder";
import { DialogContext, DialogSet } from "botbuilder-dialogs";
import { PlatformApplicationContext } from "../../../../pltaform/core/PlatformApplicationContext";
import { DialogFactory } from "../../../../pltaform/dialogs/impl/DialogFactory";
import { LoggingUtil } from "../../log4js";
import { TimeoutStore } from "./storage";
import { TimerCache } from "./timerCache";

export interface ITimeoutOptions {
    PROMPT_IF_USER_IS_ACTIVE_MSG?: string;
    PROMPT_IF_USER_IS_ACTIVE_BUTTON_TEXT?: string;
    PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS?: number;
    END_CONVERSATION_MSG?: string;
    END_CONVERSATION_TIMEOUT_IN_MS?: number;
}
export class Timeout {

    private static timeoutOptions: ITimeoutOptions = {
        PROMPT_IF_USER_IS_ACTIVE_MSG: "Are you there?",
        PROMPT_IF_USER_IS_ACTIVE_BUTTON_TEXT: "Yes",
        //PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS: 600000,
        PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS: 1800000,
        //PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS: 120000,        //timeout for local
        END_CONVERSATION_MSG: "When you come back, you can start a new conversation by typing something orclickingthebuttonbelow.",
        END_CONVERSATION_TIMEOUT_IN_MS: 1800000,
    };

    public readonly timeoutStore: TimeoutStore = null;

    constructor() {
        this.timeoutStore = new TimeoutStore();
    }

    public onUpdate(context: TurnContext) {
        const convoId = context.activity.conversation.id;
        this.timeoutStore.storeConvoIdAndSession(convoId, context);
    }

    public onReceive(context: TurnContext) {
       // if (context.activity.type === "message" && context.activity.text != Timeout.timeoutOptions.PROMPT_IF_USER_IS_ACTIVE_MSG) {
            //clear timeout handlers when we receive message from user
            this.clearTimeoutHandlers(context.activity.conversation.id);
            this.resetHandlers(context.activity.conversation.id);
       // }
    }

    public onSend(context: TurnContext) {
        if (1===1) {
            const convoId = context.activity.conversation.id;
            if (this.timeoutStore.isValid(convoId)) {
                if (this.timeoutStore.getPromptHandlerFor(convoId) === false) {
                    this.startPromptTimer(context);
                }
            }
        }
    }


    private startEndConversationTimer(context: TurnContext) {
        try {
           const conversationReference = TurnContext.getConversationReference(context.activity);
            context.adapter.continueConversation(conversationReference, async (turnContext: any) => {
                LoggingUtil.log.debug("** f");
                await new Promise((resolve) => {
                    const handler = setTimeout(async (resolve) => {
                        turnContext.sendActivity(Timeout.timeoutOptions.END_CONVERSATION_MSG);
                        const dialogSet1:DialogSet = PlatformApplicationContext.getInstance().getRequestData().dialogSet;
                        dialogSet1.add(DialogFactory.getRegistry().get('platform.weather'));
                        const dialogContext = await dialogSet1.createContext(turnContext);
                        LoggingUtil.log.info("---00001-", dialogSet1);
                        dialogContext.beginDialog('platform.weather');


                        LoggingUtil.log.debug("** Execute EndConvertion Timer");
                    }, Timeout.timeoutOptions.END_CONVERSATION_TIMEOUT_IN_MS);
                    this.timeoutStore.setEndConvoHandlerFor(context.activity.conversation.id, handler);
                });
            });
        } catch (e) {
            LoggingUtil.log.debug("** startEndConversationTimer ** error :", e);
        }
    }
    private async startPromptTimer444(turnContext: any) {
        try {
            LoggingUtil.log.debug("** Register Prompt Timer", turnContext);
            await new Promise((resolve) => {
                const handler = setTimeout(async (resolve) => {
                   // turnContext.sendActivity(Timeout.timeoutOptions.PROMPT_IF_USER_IS_ACTIVE_MSG);

                    const dialogSet: DialogSet = PlatformApplicationContext.getInstance().getRequestData().dialogSet;
                    LoggingUtil.log.info("---0001-");

                    const dlg = DialogFactory.getRegistry().get('Timeout');
                    LoggingUtil.log.info("---dlg-", dlg);
                    dialogSet.add(dlg);

                    LoggingUtil.log.info("---0002-", PlatformApplicationContext.getInstance().getRequestData().dialogContext);




                    const dialogContext = await dialogSet.createContext(turnContext);
                    LoggingUtil.log.info("---0000iiiiii-", dialogSet);



                    dialogContext.replaceDialog('Timeout');
                    dialogContext.cancelAllDialogs(true);
                    LoggingUtil.log.debug("** Execute Prompt Timer");
                    this.startEndConversationTimer(turnContext);
                }, Timeout.timeoutOptions.PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS);
                this.timeoutStore.setPromptHandlerFor(turnContext.activity.conversation.id, handler);
            });
        } catch (e) {
            LoggingUtil.log.debug("** startPromptTimer ** error :", e);
        }
    }
    private startPromptTimer(context: TurnContext) {
        //if(context.activity.channelId == 'msteams'){//||context.activity.channelId == 'emulator'){
        try {
            const conversationReference = TurnContext.getConversationReference(context.activity);
            context.adapter.continueConversation(conversationReference, async (turnContext:any) => {
                LoggingUtil.log.debug("** Register Prompt Timer");
                await new Promise((resolve) => {
                    const handler = setTimeout(async (resolve) => {
                        //turnContext.sendActivity(Timeout.timeoutOptions.PROMPT_IF_USER_IS_ACTIVE_MSG);
                       
                        const dialogSet:DialogSet = PlatformApplicationContext.getInstance().getRequestData().dialogSet;
                        dialogSet.add(DialogFactory.getRegistry().get('Timeout'));
                        //dialogSet.add(DialogFactory.getRegistry().get('HrGreeting'));
                        const dialogContext = await dialogSet.createContext(turnContext);
                        //LoggingUtil.log.debug("context in timeout",dialogContext)

                        TimerCache.getInstance().cache.set(turnContext.activity.conversation.id, { isPromptTimerActive: true });

                        //dialogContext.beginDialog('Timeout');
                        dialogContext.cancelAllDialogs(true);
                        //LoggingUtil.log.debug("context in timeout-->")
                        dialogContext.replaceDialog('Timeout');
                        
                        
                        LoggingUtil.log.debug("** Execute Prompt Timer");
                        
                    //    this.startEndConversationTimer(turnContext);
                    }, Timeout.timeoutOptions.PROMPT_IF_USER_IS_ACTIVE_TIMEOUT_IN_MS);
                    this.timeoutStore.setPromptHandlerFor(context.activity.conversation.id, handler);
                });
            });
        } catch (e) {
            LoggingUtil.log.debug("** startPromptTimer ** error :", e);
        }
    //}
    }

    private clearTimeoutHandlers(convoId: string) {
        if (this.timeoutStore.getPromptHandlerFor(convoId) !== false) {
            // if the function has not already been executed,
            // stop the execution by calling the clearTimeout() method.
            clearTimeout(this.timeoutStore.getPromptHandlerFor(convoId));
        }
        if (this.timeoutStore.getEndConvoHandlerFor(convoId) !== false) {
            clearTimeout(this.timeoutStore.getEndConvoHandlerFor(convoId));
        }
    }

    private resetHandlers(convoId: string) {
        this.timeoutStore.setPromptHandlerFor(convoId, false)
        this.timeoutStore.setEndConvoHandlerFor(convoId, false);
    }
}