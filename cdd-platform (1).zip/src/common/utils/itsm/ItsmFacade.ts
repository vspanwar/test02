import { Module } from './../../enums/PlatformEnums';
import { CommonWebPaths } from './../../web/CommonWebPaths';
import { HttpUtil } from './../HttpUtil';


export class ItsmFacade {

    private _config:any;
    constructor(config:any){
        this._config = config;
    }

    public async execute(operation:string,
                   payloadDetails:{}): Promise<any> {

        let fullPayload = {config: this._config,
                           payload:payloadDetails,
                           action: operation}
        let response = HttpUtil.post(CommonWebPaths.getfullPath(Module.ESI) + 'itsm',
                       fullPayload);
        return response;
    }


}