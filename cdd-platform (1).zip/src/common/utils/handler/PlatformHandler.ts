export interface Handler {
    setNext(handler: Handler): Handler;
    handle(request: any): any;
    isValid(request: any):boolean;
}

export abstract class AbstractHandler implements Handler
{
    private nextHandler: Handler;

    public setNext(handler: Handler): Handler {
        this.nextHandler = handler;
        return handler;
    }

    public handle(request: any): string {
        if (this.isValid(request)) {
            return this.onHandle(request);
        } else if (this.nextHandler) {
            return this.nextHandler.handle(request);
        } else{
            return null;
        }
    }

    public abstract isValid(request: any):boolean;
    public abstract onHandle(request: any):any;
}

// class DummyHandler extends AbstractHandler {
//     public handle(request: string): string {
//         if (request === 'Dummy') {
//             return `Dummy`;
//         }
//         return super.handle(request);
//     }x
// }

/**
 * The client code is usually suited to work with a single handler. In most
 * cases, it is not even aware that the handler is part of a chain.
 */
// function clientCode(handler: Handler) {
//     const foods = ['Nut', 'Banana', 'Cup of coffee'];

//     for (const food of foods) {
//         console.log(`Client: Who wants a ${food}?`);

//         const result = handler.handle(food);
//         if (result) {
//             console.log(`  ${result}`);
//         } else {
//             console.log(`  ${food} was left untouched.`);
//         }
//     }
// }

/**
 * The other part of the client code constructs the actual chain.
 */
// const monkey = new MonkeyHandler();
// const squirrel = new SquirrelHandler();
// const dog = new DogHandler();

// monkey.setNext(squirrel).setNext(dog);

/**
 * The client should be able to send a request to any handler, not just the
 * first one in the chain.
 */
// console.log('Chain: Monkey > Squirrel > Dog\n');
// clientCode(monkey);
// console.log('');

// console.log('Subchain: Squirrel > Dog\n');
// clientCode(squirrel);