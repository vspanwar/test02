import { LoggingUtil } from '../log4js';
import * as keyvault from './keyvaultKeys.json';
import { EnvironmentParams } from '../../startup/EnvironmentParams';
const { ManagedIdentityCredential,DefaultAzureCredential } = require("@azure/identity");
const { SecretClient } = require("@azure/keyvault-secrets");

export class KeyVaultService {

    private static instance: KeyVaultService;

    public static getInstance(): KeyVaultService {
        if(KeyVaultService.instance==null){
            KeyVaultService.instance = new KeyVaultService();
        }
        return KeyVaultService.instance;
    }

    public async getKey(key: string): Promise<string> {
        if(EnvironmentParams.getEnvironment().keyvaultState == "start"){
            const secret = await this.fetchFromVault(keyvault.start[key]);
            return secret;
        }else {
            return keyvault.stop[key]?keyvault.stop[key]:"KEYNOTTHERE";
        }

    }

    private async fetchFromVault(key: string): Promise<string> {
        const credential = new ManagedIdentityCredential();
        const vaultName = EnvironmentParams.getEnvironment().keyvaultName;
        const url = `https://${vaultName}.vault.azure.net`;

        const client = new SecretClient(url, credential);
        
        try {
            // TODO: getSecret is async
            const resVault = await client.getSecret(key);
            LoggingUtil.log.info('Key Secret:' + resVault.value);
            return resVault.value

            //return 'platformdeskservicecognitive'
        } catch (err) {
            LoggingUtil.log.error('Error in fetching key:' + err);
        }
    }


}