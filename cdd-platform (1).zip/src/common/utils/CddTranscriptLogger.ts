import { LoggingUtil } from './log4js';
import { Activity, TranscriptLogger } from "botbuilder";
import { AdminService } from '../../pltaform/service/AdminService';
import { po_data } from '../../pltaform/model/PO_details';
import { DialogUtils } from '../../pltaform/dialogs/impl/DialogUtils';
import { Datastore } from '../../pltaform/dialogs/impl/Datastore';

var moment =require('moment-timezone')

export class CddTranscriptLogger implements TranscriptLogger {
    /**
     * Log an activity to the transcript.
     * @param activity Activity being logged.
     */
    public async logActivity(activity: Activity) {
        if (!activity) { throw new Error('Activity is required.'); }
        //LoggingUtil.log.debug('Activity Log:', activity);
        let m = moment().tz('America/Toronto').format()
        let d=m.substring(0,10)+" "+m.substring(11,19)
      
      LoggingUtil.log.info('env variable:'+process.env.bcr_name)
      let name = "Bot"

       if(activity.type === 'message' && (activity.from.name == process.env.bcr_name || activity.from.name == 'Bot')) 
       { 
            LoggingUtil.log.info("Activity text condition") 
            if(activity.text == undefined)
            {
            //LoggingUtil.log.info("Activity text undefined:")  
            }
            else
            { 
              let data = name +" ("+d+") : "+ activity.text+"|"
              LoggingUtil.log.info("inside transcript logger ",activity.channelId)
              
              if(activity.channelId == 'directline'){
              //if(activity.channelId == 'directline'||activity.channelId=="emulator"){ 
              await Datastore.getInstance().logTranscript(data,activity.conversation.id)
              }
              // else{
              //   let session_id = await Datastore.getInstance().get_SessionID(activity.conversation.id)
              //   //console.log("session id-->", session_id)
              //   await Datastore.getInstance().logTranscriptHR(activity.text,session_id,"BOT")
              // }
                  
            }
        }
    
       if(activity.attachments != undefined){
       if(activity.attachments[0].contentType ==="application/vnd.microsoft.card.hero" && (activity.from.name ==process.env.bcr_name || activity.from.name == 'Bot')){
          
            //let text = activity.attachments[0].content.text
            let data = name+" ("+d+ ") : "+ activity.attachments[0].content.text
            LoggingUtil.log.info("inside  Activity text :"+data)
            LoggingUtil.log.info("inside transcript logger 2nd condition", activity.channelId)   
            //po_data.transcript.push(data)
            if(activity.channelId == 'directline'){ 
            //if(activity.channelId == 'directline'||activity.channelId == 'emulator'){ 
             await Datastore.getInstance().logTranscript(data,activity.conversation.id)
            }
            // else{
            //   let session_id = await Datastore.getInstance().get_SessionID(activity.conversation.id)
            //   //console.log("session id-->", session_id)
            //   await Datastore.getInstance().logTranscriptHR(activity.text,session_id,"BOT")
            // }
       }
      }
      
        
       
    // if(activity.attachments[0].content.type==="AdaptiveCard"){
    //    // LoggingUtil.log.info("Activity text in ac:"+JSON.s activity.attachments[0].content) 

     
    //   }
      //LoggingUtil.log.info("Arrayyyyyyyyyyyyyyyyyyyyyyyyyyyyyy:"+po_data.transcript)

       
        
    }
}