import { StartupConotroller } from './common/startup/StartupConotroller';
import { PlatformApplicationContext } from './pltaform/core/PlatformApplicationContext';
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

import * as path from 'path';

import { config } from 'dotenv';
const ENV_FILE = path.join(__dirname, '..', '.env');
config({ path: ENV_FILE });

import * as restify from 'restify';

// Import required bot services.
// See https://aka.ms/bot-services to learn more about the different parts of a bot.


// This bot's main dialog.


// PlatformApplicationContext.getInstance().init();
StartupConotroller.getInstance().init();
