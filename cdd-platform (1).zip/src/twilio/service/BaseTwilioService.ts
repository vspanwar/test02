import { BaseService } from "../../common/core/BaseService";

export abstract class BaseTwilioService extends BaseService{

}