import { BaseTwilioService } from "./BaseTwilioService";
import { TwilioDao } from "../dao/TwilioDao";


export class TwilioService extends BaseTwilioService{
    private dao:TwilioDao;

    constructor(){
        super();
        this.dao = new TwilioDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}