import { BaseController } from "../../common/web/BaseController";

export abstract class BaseTwilioController extends BaseController{

}