import { LoggingUtil } from './../../common/utils/log4js';

import { Request, Response } from 'express';
import { BaseTwilioController } from './BaseTwilioController';
import { TwilioService } from '../service/TwilioService';

export class TwilioController extends BaseTwilioController {
    private static instance: TwilioController;
    private service:TwilioService;

    private constructor(){
        super();
        this.service = new TwilioService();
    }
    
    public static getInstance = () => {
        if (TwilioController.instance == null) {
            TwilioController.instance = new TwilioController();
        }
        return TwilioController.instance;
    }

    

    public async action(req: Request, res: Response) {
        LoggingUtil.log.debug(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
