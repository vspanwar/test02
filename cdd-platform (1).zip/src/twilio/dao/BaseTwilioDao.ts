import { BaseDao } from "../../common/core/BaseDao";

export abstract class BaseTwilioDao extends BaseDao{

}