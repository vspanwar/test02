import { BaseTwilioDao } from "./BaseTwilioDao";

export class TwilioDao extends BaseTwilioDao{

    public async action(req: any, res: any): Promise<any> {
        res.send({ "error": "error in your request" });
    }
}