export  class Tenant{

}