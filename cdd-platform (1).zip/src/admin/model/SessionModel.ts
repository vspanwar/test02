
export interface Session{
    channel:string;
    user_conversation_id:string;
    agent_conversation_id:string;
    create_timestamp: Date;
    end_timestamp: Date;
    status: string;
    user: user;
    agent: agent;
    itsm: itsm;
    usecase: usecase;
    transfer_chats: Boolean;
    abandoned_chats: Boolean;
}

export interface itsm{
    ticket_number: number;
    agent_name: string;
}

export interface user{
    user_id: string;
    user_name: string;
    user_email: string;
    region: String;
    create_timestamp: Date;
}

export interface agent{
    user_id: string;
    user_name: string;
    user_email: string;
    region: String;
    create_timestamp: Date;
}


export interface usecase{
    usecase_name: [string];
    language: string;
    create_timestamp: Date;
    end_timestamp: Date;
    transcript: [transcript];
    feedback: feedback;
}

export interface transcript{
    bot_response: string;
    user_text: string;
    requester_id: string;
    requester: string;
    requester_type: string;
    create_timestamp: Date;
}

export interface feedback{
    status: string;
    user_feedback: string;
    timestamp: Date;
}