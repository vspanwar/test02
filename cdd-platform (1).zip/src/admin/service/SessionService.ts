import { LoggingUtil } from '../../common/utils/log4js';
import { SessionDao } from '../dao/SessionDao';

export class SessionService{

    private static SessionService:SessionService

    public static getInstance(){
        if(SessionService.SessionService == null){
            SessionService.SessionService = new SessionService()
        }
        return SessionService.SessionService;
    }

    public async getUserSession(payload:any): Promise<any> {
        let sessionDao = SessionDao.getInstance();
        return await sessionDao.getUserSession(payload.conversationId);
    }

    public async getData(): Promise<any> {
        let sessionDao = SessionDao.getInstance();
        return await sessionDao.getData();
    }

    public async createUserSession(payload:any): Promise<any> {
        let sessionDao = SessionDao.getInstance();
        return await sessionDao.createUserSession(payload);
    }


    public async updateUserSession(payload:any): Promise<any> {
        let sessionDao = SessionDao.getInstance();
        return await sessionDao.updateUserSession(payload);
    }

    public async appendUserSession(payload:any): Promise<any> {
        let sessionDao = SessionDao.getInstance();
        return await sessionDao.appendUserSession(payload);
    }


}