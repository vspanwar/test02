import { BaseService } from "../../common/core/BaseService";

export abstract class BaseAdminService extends BaseService{

}