
import { NLPDao } from '../dao/NLPDao';


export class NLPService {

    public static nlpServices: NLPService;

    private constructor() {
    }

    public static getInstance(): NLPService {
        if (NLPService.nlpServices == null) {
            NLPService.nlpServices = new NLPService();
        }
        return NLPService.nlpServices;
    }

    

    public async getNLPconfigsById(nlpConfigId: string): Promise<any> {
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.getNLPconfigsById(nlpConfigId);
    }

    public async createNLPConfig(nlpConfigId: string): Promise<any> {
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.createNLPConfig(nlpConfigId);
    }

    public async addIntent(payload:any, nlpConfigId: string):Promise<any>{
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.addIntent(payload, nlpConfigId);
    }

    public async addUtterances(payload:any, nlpConfigId: string):Promise<any>{
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.addUtterances(payload, nlpConfigId);
    }

    public async replaceNLPConfig(id:string, payload:any):Promise<any>{
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.replaceNLPConfig(id, payload);
    }

    public async getIntents(id:string):Promise<any>{
        let nlpDao = NLPDao.getInstance();
        return await nlpDao.getIntents(id);
    }

}