import { ReportingDao } from '../dao/ReportingDao';

export class ReportingService{

    private static ReportService:ReportingService

    public static getInstance(){
        if(ReportingService.ReportService == null){
            ReportingService.ReportService = new ReportingService()
        }
        return ReportingService.ReportService;
    }

    public async getUserSession(): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.getUserSession();
    }

    public async getUserByIDSession(payload): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.getUserByIDSession(payload);
    }

    public async getPreviousUserSession(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        
        return await reportingDao.getPreviousSession(payload);
    }

    public async createUserSession(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.createUserSession(payload);
    }

    public async deleteUserSession(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.deleteUserSession(payload);
    }

    public async updateUserSession(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.updateUserSession(payload);
    }

    public async appendUserSession(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.appendUserSession(payload);
    }
    
    public async appendChat(payload:any): Promise<any> {
        let reportingDao = ReportingDao.getInstance();
        return await reportingDao.appendChat(payload);
    }


}