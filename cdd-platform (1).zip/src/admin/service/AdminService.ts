import { AdminDao } from './../dao/AdminDao';
import { BaseAdminService } from "./BaseAdminService";

export class AdminService extends BaseAdminService{
    private dao:AdminDao;

    constructor(){
        super();
        this.dao = new AdminDao();
    }

    public async action(req: any, res: any): Promise<any> {
        return await this.dao.action(req, res);
    }

}