import { TenantBotDao } from '../dao/TenantBotDao';


export class TenantBotService {

    public static tenantService: TenantBotService;

    private constructor() {
    }

    public static getInstance(): TenantBotService {
        if (TenantBotService.tenantService == null) {
            TenantBotService.tenantService = new TenantBotService();
        }
        return TenantBotService.tenantService;
    }

    

    public async findTenantBot(tenantId: string): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.findTenantBot(tenantId);
    }

    public async createTenant(payload:any):Promise<any>{
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.createTenant(payload)
    }

    public async getNewTenantId():Promise<any>{
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getNewTenantId()
    }

   

    public async getAllTenantBotDetails(): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getAllTenantBotDetails();
    }

    public async getActiveTenantBotDetails(): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getActiveTenantBotDetails();
    }

    public async updateRecord(id:string, payload:any): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.updateRecord(id, payload);
    }

    public async addBot(id:string, payload:any): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.addBot(id, payload);
    }

    public async addChannel(tenantId:string, botId:string, payload:any): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.addChannel(tenantId, botId, payload);
    }

    public async extApplication(tenantId:string, botId:string, payload:any): Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.extApplication(tenantId, botId, payload);
    }
    
    public async getNewBotId():Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getNewBotId();
    }

    public async updateChannel(tenantId:string, botId:string, payload:any):Promise<any>{
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.updateChannel(tenantId, botId, payload);
    }
    
    public async getPlatformChannels():Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getPlatformChannels();
    }

    public async addNLPapp(tenantId:string, botId:string, payload:any):Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.addNLPapp(tenantId, botId, payload);
    }

    public async updateBot(tenantId:string, botId:string, payload:any):Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.updateBot(tenantId, botId, payload);
    }

    public async updateExtApp(tenantId:string, botId:string, payload:any):Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.updateExtApp(tenantId, botId, payload);
    }

    public async updateNLPApp(tenantId:string, botId:string, payload:any):Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.updateNLPApp(tenantId, botId, payload);
    }

    public async getDropdowns():Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.getDropdowns();
    }

    public async replaceTenant(tenantId:string, payload:any):Promise<any> {
        let tenantBotDao = TenantBotDao.getInstance();
        return await tenantBotDao.replaceTenant(tenantId, payload);
    }

}