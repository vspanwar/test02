import {  MeetingRoomDao } from '../dao/MeetingRoomDao';
import { NLPDao } from '../dao/NLPDao';



export class MeetingRoomService {

    public static meetingroomServices: MeetingRoomService;

    private constructor() {
    }

    public static getInstance(): MeetingRoomService {
        if (MeetingRoomService.meetingroomServices == null) {
            MeetingRoomService.meetingroomServices = new  MeetingRoomService();
        }
        return  MeetingRoomService.meetingroomServices;
    }
    
    public async getMeetingRoomconfigsById(meetingroomConfigId: string): Promise<any> {
        let meetingroomDao = MeetingRoomDao.getInstance();
        return await meetingroomDao.getMeetingRoomconfigsById(meetingroomConfigId);
    }

    public async createMeetingRoomConfig(meetingroomConfigId: string): Promise<any> {
        let meetingroomDao = MeetingRoomDao.getInstance();
        return await meetingroomDao.createMeetingRoomConfig(meetingroomConfigId);
    }

    public async addIntent(payload:any, meetingroomConfigId: string):Promise<any>{
        let meetingroomDao =MeetingRoomDao.getInstance();
        return await meetingroomDao.addIntent(payload, meetingroomConfigId);
    }
    public async getdocumentbyId(payload:any):Promise<any>{
    
        let meetingroomDao =MeetingRoomDao.getInstance();
        return await meetingroomDao.getdocumentbyId(payload);
    }

    public async addUtterances(payload:any, meetingroomConfigId: string):Promise<any>{
        let meetingroomDao =MeetingRoomDao.getInstance();
        return await meetingroomDao.addUtterances(payload, meetingroomConfigId);
    }

    public async getIntents(id:string):Promise<any>{
        let meetingroomDao = MeetingRoomDao.getInstance();
        return await meetingroomDao.getIntents(id);
    }

}
