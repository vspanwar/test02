import { Router, Request, Response, NextFunction } from 'express';
import { TenantBotCtrl } from '../controller/TenantBotCntroller';
import { NLPCtrl } from '../controller/NLPController';

export class NLPRouter {
    private static router: Router

    public static getInstance(): Router {
        if (NLPRouter.router == null) {
            let or = new NLPRouter()
            or.init();
        }
        return NLPRouter.router;
    }

    private constructor() {
        NLPRouter.router = Router();
    }

    public getNLPconfigsById(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.getNLPconfigsById(req, res);
    }
    public createNLPConfig(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.createNLPConfig(req, res);
    }
    public addIntent(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.addIntent(req, res);
    }
    public getIntents(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.getIntents(req, res);
    }
    public addUtterances(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.addUtterances(req,res)
    }

    public getDialogConfig(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.getDialogConfig(req, res);
    }
   

    public replaceNLPConfig(req: Request, res: Response) {
        let ctrl = NLPCtrl.getInstance();
        ctrl.replaceNLPConfig(req, res);
    }
    
    init() {

        
        NLPRouter.router.get('/nlpconfig/:nlpconfigid', this.getNLPconfigsById);
        NLPRouter.router.get('nlp/dialogconfig', this.getDialogConfig);
        NLPRouter.router.post('/create', this.createNLPConfig)
        NLPRouter.router.post('/addintent/:nlpconfigid', this.addIntent)
        NLPRouter.router.get('/intents/:nlpconfigid', this.getIntents)
        NLPRouter.router.post('/addutterance/:nlpconfigid', this.addUtterances)
        
        NLPRouter.router.post('/replace/:nlpconfigid', this.replaceNLPConfig)
        
    }

}
