import { Router, Request, Response, NextFunction } from 'express';
import { TenantBotCtrl } from '../controller/TenantBotCntroller';
import { MeetingRoomCtrl } from '../controller/MeetingRoomController';

export class MeetingRoomRouter {
    private static router: Router

    public static getInstance(): Router {
        if (MeetingRoomRouter.router == null) {
            let or = new MeetingRoomRouter()
            or.init();
        }
        return MeetingRoomRouter.router;
    }
    private constructor() {
        MeetingRoomRouter.router = Router();
    }

    public getMeetingRoomconfigsById(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.getMeetingRoomconfigsById(req, res);
    }
    public createMeetingRoomConfig(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.createMeetingRoomConfig(req, res);
    }
    public addIntent(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.addIntent(req, res);
    }
    public getIntents(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.getIntents(req, res);
    }
    public addUtterances(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.addUtterances(req,res)
    }

    public getDialogConfig(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.getDialogConfig(req, res);
    }
    
    public getdocumentbyId(req: Request, res: Response) {
        let ctrl = MeetingRoomCtrl.getInstance();
        ctrl.getdocumentbyId(req, res);
    }
    
    init() {

        
        MeetingRoomRouter.router.get('/meetingroomconfig/:meetingroomconfigid', this.getMeetingRoomconfigsById);
        MeetingRoomRouter.router.get('meetingroom/dialogconfig', this.getDialogConfig);
        MeetingRoomRouter.router.post('/getdocument', this.getdocumentbyId)
        MeetingRoomRouter.router.post('/addintent/:meetingroomconfigid', this.addIntent)
        MeetingRoomRouter.router.get('/intents/:meetingroomconfigid', this.getIntents)
        MeetingRoomRouter.router.post('/addutterance/:meetingroomconfigid', this.addUtterances)
      
        
    }

}
