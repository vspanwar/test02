import { Router, Request, Response} from 'express';
import { ReportingController } from '../controller/ReportingController';

export class ReportingRouter{
    private static router:Router;

    public static getInstance():Router{
        if(ReportingRouter.router==null){
            let or = new ReportingRouter();
            or.init();
        }
        return ReportingRouter.router;
    }

    private constructor(){
        ReportingRouter.router = Router();
    }

    public async getUserSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.getUserSession(req,res);
    }

    public async getUserByIDSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.getUserByIDSession(req,res);
    }

    public async getPreviousUserSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.getPreviousUserSession(req,res);
    }

    public async createUserSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.createUserSession(req, res);
    }

    public async deleteUserSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.deleteUserSession(req, res);
    }

    public async updateUserSession(req:Request, res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.updateUserSession(req, res);
    }

    public async appendUserSession(req:Request,res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.appendUserSession(req, res);
    }

    public async appendChat(req:Request,res:Response){
        let ctrl = ReportingController.getInstance();
        ctrl.appendChat(req, res);
    }

    init(){
        ReportingRouter.router.post('/usecase/get',this.getUserSession)
        ReportingRouter.router.post('/usecase/create',this.createUserSession)
       // ReportingRouter.router.post('/usecase/update',this.updateUserSession)
       // ReportingRouter.router.post('/usecase/append',this.appendUserSession)
       // ReportingRouter.router.post('/usecase/chat/append',this.appendChat)
        ReportingRouter.router.post('/usecase/getPrevious',this.getPreviousUserSession)
        //ReportingRouter.router.post('/usecase/delete',this.deleteUserSession)
        ReportingRouter.router.post('/usecase/getByUserId',this.getUserByIDSession)
        
    }
}