import { Router, Request, Response, NextFunction } from 'express';
import { TenantBotCtrl } from '../controller/TenantBotCntroller';

export class TenantBotRouter {
    private static router: Router

    public static getInstance(): Router {
        if (TenantBotRouter.router == null) {
            let or = new TenantBotRouter()
            or.init();
        }
        return TenantBotRouter.router;
    }

    private constructor() {
        TenantBotRouter.router = Router();
    }

    public findTenantBot(req: Request, res: Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.findTenantBot(req, res);
    }

    public getActiveTenantBotDetails(req: Request, res: Response) {
        console.log("here1")
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getActiveTenantBotDetails(req, res);
    }

    public getAllTenantBotDetails(req: Request, res: Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getAllTenantBotDetails(req, res);
    }
    public createTenant(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.createTenant(req, res);
    }

    public getNewTenantId(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getNewTenantId(req, res);
    }

    public updateRecord(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.updateRecord(req, res);
    }

    public addBot(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.addBot(req, res);
    }

    public addChannel(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.addChannel(req, res);
    }

    public extApplication(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.extApplication(req, res);
    }

    public getNewBotId(req: Request, res:Response) {
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getNewBotId(req, res);
    }

    public updateChannel(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.updateChannel(req, res);
    }

    public getPlatformChannels(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getPlatformChannels(req, res);
    }

    public addNLPapp(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.addNLPapp(req, res);
    }

    public async updateBot(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.updateBot(req, res);
    }

    public async updateExtApp(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.updateExtApp(req, res);
    }

    public async updateNLPApp(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.updateNLPApp(req, res);
    }

    public async getDropdowns(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.getDropdowns(req, res);
    }

    public async replaceTenant(req: Request, res:Response){
        let ctrl = TenantBotCtrl.getInstance();
        ctrl.replaceTenant(req, res);
    }

   

    init() {

        
        TenantBotRouter.router.get('/tntBot/:id', this.findTenantBot);
        //TenantBotRouter.router.get('/:tenantId', this.getAllTenantBotDetails);
        TenantBotRouter.router.post('/create', this.createTenant)
        TenantBotRouter.router.get('/active', this.getActiveTenantBotDetails);
        TenantBotRouter.router.get('/newtenant', this.getNewTenantId);
        TenantBotRouter.router.post('/update/:id', this.updateRecord);
        TenantBotRouter.router.post('/add/bot/:id', this.addBot)
        TenantBotRouter.router.post('/add/channel/:tenantid/:botid', this.addChannel)
        TenantBotRouter.router.post('/add/extapp/:tenantid/:botid', this.extApplication)
        TenantBotRouter.router.get('/newbot', this.getNewBotId)
        TenantBotRouter.router.post('/update/channel/:tenantid/:botid', this.updateChannel)
        TenantBotRouter.router.get('/platform/channels', this.getPlatformChannels)
        TenantBotRouter.router.post('/add/nlpapp/:tenantid/:botid', this.addNLPapp)
        TenantBotRouter.router.get('/all', this.getAllTenantBotDetails)
        TenantBotRouter.router.post('/update/bot/:tenantid/:botid', this.updateBot)
        TenantBotRouter.router.post('/update/extapp/:tenantid/:botid', this.updateExtApp)
        TenantBotRouter.router.post('/update/nlpapp/:tenantid/:botid', this.updateNLPApp)
        TenantBotRouter.router.get('/dropdowns', this.getDropdowns)
        TenantBotRouter.router.post('/replace/:tenantid', this.replaceTenant)
        
        
        
    }

}
