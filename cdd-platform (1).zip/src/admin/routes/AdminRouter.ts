import { LoggingUtil } from './../../common/utils/log4js';
import { AdminController } from './../controller/AdminController';
import { Router, NextFunction, Request, Response } from 'express';
import { Module } from './../../common/enums/PlatformEnums';
import { BaseRouter } from "../../common/web/BaseRouter";
import { TenantBotRouter } from '../routes/TenantBotRouter';
import { NLPRouter } from './NLPRouter';
import { MeetingRoomRouter } from './MeetingRoomRouter';
import { ReportingRouter } from "./ReportingRouter";
import { SessionRouter } from "./SessionRouter"

export class AdminRouter extends BaseRouter {

    private controller:AdminController;
    /**
   * Initialize the Router
   */
    constructor() {
        super(Module.ADMIN);
        //this.controller = new AdminController();
    }


    onInit(router: Router) {
        LoggingUtil.log.debug(' action ...');
        router.get('/action', this.action);
        router.use('/tenant/config', TenantBotRouter.getInstance()) //tenant/config*
        router.use('/nlp', NLPRouter.getInstance())
        router.use('/meetingroom',MeetingRoomRouter.getInstance())
        router.use('/report',ReportingRouter.getInstance());
        router.use('/session',SessionRouter.getInstance());


        
        // throw new Error("Method not implemented.");
    }

    public action(req: Request, res: Response) {
        AdminController.getInstance().action(req, res);
    }

}