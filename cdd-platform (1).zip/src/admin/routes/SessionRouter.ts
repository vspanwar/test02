import { Router, Request, Response} from 'express';
import { LoggingUtil } from '../../common/utils/log4js';
import { SessionController } from '../controller/SessionController';

export class SessionRouter{
    private static router:Router;

    public static getInstance():Router{
        if(SessionRouter.router==null){
            let or = new SessionRouter();
            or.init();
        }
        return SessionRouter.router;
    }

    private constructor(){
        SessionRouter.router = Router();
    }

    public async getUserSession(req:Request, res:Response){
        let ctrl = SessionController.getInstance();
        ctrl.getUserSession(req,res);
    }

    public async getData(req:Request, res:Response){
        let ctrl = SessionController.getInstance();
        ctrl.getData(req,res);
    }
    
    public async createUserSession(req:Request, res:Response){
        let ctrl = SessionController.getInstance();
        ctrl.createUserSession(req, res);
    }


    public async updateUserSession(req:Request, res:Response){
        LoggingUtil.log.info("updateUserSession in reporting router")
        let ctrl = SessionController.getInstance();
        ctrl.updateUserSession(req, res);
    }

    public async appendUserSession(req:Request,res:Response){
        let ctrl = SessionController.getInstance();
        ctrl.appendUserSession(req, res);
    }



    init(){
        SessionRouter.router.get('/userSession/get',this.getUserSession)
        SessionRouter.router.post('/userSession/create',this.createUserSession)
        SessionRouter.router.post('/userSession/update',this.updateUserSession)
        SessionRouter.router.post('/userSession/append',this.appendUserSession)
        SessionRouter.router.get('/userSession/getalldata',this.getData)
    }
}