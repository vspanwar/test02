import { LoggingUtil } from './../../common/utils/log4js';
import { JsonConfigDao } from './../dao/JsonConfigDao';
import { Request, Response } from 'express';
import { TenantBotService } from '../service/TenantBotService';
import { NLPService } from '../service/NLPServices';
import { BaseAdminController } from './BaseAdminController';


export class NLPCtrl extends BaseAdminController {

    private static instance: NLPCtrl;

    private constructor() {
        super();
    }

    public static getInstance = () => {
        if (NLPCtrl.instance == null) {
            NLPCtrl.instance = new NLPCtrl();
        }
        return NLPCtrl.instance;
    }


    public async getIntents(req: Request, res: Response): Promise<any> {
        let ts = NLPService.getInstance();
        ts.getNLPconfigsById(req.params.nlpconfigid).then(tenant => {
            res.send(tenant);
        });
    }

    public async createNLPConfig(req: Request, res: Response): Promise<any> {
        let ts = NLPService.getInstance();
        ts.createNLPConfig(req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async addIntent(req: Request, res: Response): Promise<any> {
        let ts = NLPService.getInstance();
        ts.addIntent(req.body, req.params.nlpconfigid).then(results => {
            res.send(results);
        });
    }

    public async addUtterances(req:Request, res:Response):Promise<any> {
        let ts = NLPService.getInstance();
        ts.addUtterances(req.body, req.params.nlpconfigid).then(results => {
            res.send(results);
        });
    }

    public async replaceNLPConfig(req:Request, res:Response):Promise<any> {
        let ts = NLPService.getInstance();
        ts.replaceNLPConfig(req.params.nlpconfigid, req.body).then(results => {
            res.send(results);
        });
    }

    /**
     * 
     * 
     */
    public async getNLPconfigsById(req: Request, res: Response): Promise<any> {
        if(this.isJsonConfig() ){
            for (let tenant of JsonConfigDao.getTenantCfg()) {
                if(tenant.tenantId == req.query.tenantId) {
                    for (let bot of tenant.tenantBot) {
                        if(bot.botId == req.query.botId){
                            res.send(JsonConfigDao.getNlpCfg(bot.intentRef));
                        }
                    }
                }
            }

            // const bot = JsonConfigDao.getTenantCfg().tenantBot[0];
            // LoggingUtil.log.debug(bot.intentRef);
            // return JsonConfigDao.getNlpCfg(bot.intentRef);
         } else {
            NLPService.getInstance().getNLPconfigsById(req.params.nlpconfigid).then(tenant => {
                res.send(tenant);
            });
        }

    }

    public async getDialogConfig(req: Request, res: Response): Promise<any> {
        if(this.isJsonConfig() ){
            for (let tenant of JsonConfigDao.getTenantCfg()) {
                if(tenant.tenantId == req.query.tenantId) {
                    for (let bot of tenant.tenantBot) {
                        if(bot.botId == req.query.botId){
                            res.send(JsonConfigDao.getDialogConfig(req.query.tenantName,
                                req.query.dialogName));
                        }
                    }
                }
            }
         } else {
                res.send({});
        }

    }

    


}
