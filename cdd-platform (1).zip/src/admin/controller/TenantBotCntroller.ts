import { JsonConfigDao } from './../dao/JsonConfigDao';
import { Request, Response } from 'express';
import { TenantBotService } from '../service/TenantBotService';
import { EnvironmentParams } from '../../common/startup/EnvironmentParams';
import { BaseAdminController } from './BaseAdminController';


export class TenantBotCtrl  extends BaseAdminController {

    private static instance: TenantBotCtrl;

    private constructor() {
        super();
    }

    public static getInstance = () => {
        if (TenantBotCtrl.instance == null) {
            TenantBotCtrl.instance = new TenantBotCtrl();
        }
        return TenantBotCtrl.instance;
    }

    
    public async findTenantBot(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.findTenantBot(req.params.id).then(tenant => {
            res.send(tenant);
        });
    }

   

    public async getAllTenantBotDetails(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.getAllTenantBotDetails().then(tenant => {
            res.send(tenant);
        });
    }

    public async getNewTenantId(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.getNewTenantId().then(tenant => {
            res.send(tenant);
        });
    }

    public async createTenant(req: Request, res: Response):Promise<any> {
        let ts=TenantBotService.getInstance();
        ts.createTenant(req.body).then(tenant=>{
            res.send(tenant)
        })
    }

    
    public async updateRecord(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.updateRecord(req.params.id, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async addBot(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.addBot(req.params.id, req.body).then(tenant => {
            res.send(tenant);
        });
    }
    public async addChannel(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.addChannel(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }
    public async extApplication(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.extApplication(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async getNewBotId(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.getNewBotId().then(tenant => {
            res.send(tenant);
        });
    }

    public async updateChannel(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.updateChannel(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async updateBot(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.updateBot(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async updateExtApp(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.updateExtApp(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async getPlatformChannels(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.getPlatformChannels().then(tenant => {
            res.send(tenant);
        });
    }

    public async updateNLPApp(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.updateNLPApp(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async addNLPapp(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.addNLPapp(req.params.tenantid, req.params.botid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async getDropdowns(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.getDropdowns().then(tenant => {
            res.send(tenant);
        });
    }

    public async replaceTenant(req: Request, res: Response): Promise<any> {
        let ts = TenantBotService.getInstance();
        ts.replaceTenant(req.params.tenantid, req.body).then(tenant => {
            res.send(tenant);
        });
    }

    /**
     *Get Active tenants - either from DB or from JSON File
     * @param req
     * @param res
     */
    public async getActiveTenantBotDetails(req: Request, res: Response): Promise<any> {
        if(this.isJsonConfig() ){
           res.send(JsonConfigDao.getTenantCfg());
        } else {
            TenantBotService.getInstance().getActiveTenantBotDetails().then(tenant => {
                res.send(tenant);
            });
        }
    }

     
    

}
