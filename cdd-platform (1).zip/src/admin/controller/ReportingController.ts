import { ReportingService } from "../service/ReportingService";
import { Request, Response } from 'express';

export class ReportingController{
    private static instance:ReportingController;

    public static getInstance(){
        if(ReportingController.instance == null){
            ReportingController.instance =  new ReportingController();
        }
        return ReportingController.instance;
    }

    public async getUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.getUserSession().then(user => {
            res.send(user);
        });
    }

    public async getUserByIDSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.getUserByIDSession(req.body).then(user => {
            res.send(user);
        });
    }

    public async getPreviousUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.getPreviousUserSession(req.body).then(user => {
            res.send(user);
        });
    }

    public async updateUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.updateUserSession(req.body).then(user => {
            res.send(user);
        });
    }

    public async createUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.createUserSession( req.body).then(user => {
            res.send(user);
        });
    }

    public async deleteUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.deleteUserSession( req.body).then(user => {
            res.send(user);
        });
    }
    

    public async appendUserSession(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.appendUserSession(req.body).then(user => {
            res.send(user);
        });
    }

    public async appendChat(req: Request, res: Response): Promise<any> {
        let ts = ReportingService.getInstance();
        ts.appendChat(req.body).then(user => {
            res.send(user);
        });
    }

}