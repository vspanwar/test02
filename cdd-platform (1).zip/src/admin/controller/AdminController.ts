import { AdminService } from './../service/AdminService';
import { BaseAdminController } from "./BaseAdminController";
import { Request, Response } from 'express';
import { LoggingUtil } from '../../common/utils/log4js';


export class AdminController extends BaseAdminController {
    private static instance: AdminController;
    private service:AdminService;

    private constructor(){
        super();
        this.service = new AdminService();
    }
    
    public static getInstance = () => {
        if (AdminController.instance == null) {
            AdminController.instance = new AdminController();
        }
        return AdminController.instance;
    }

    

    public async action(req: Request, res: Response) {

        LoggingUtil.log.debug(' action ...2');
        return await this.service.action(req, res).then(tb => {
            res.send(tb);
        });
    }
}
