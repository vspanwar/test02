import { LoggingUtil } from './../../common/utils/log4js';
import { JsonConfigDao } from './../dao/JsonConfigDao';
import { Request, Response } from 'express';
import { TenantBotService } from '../service/TenantBotService';
import { MeetingRoomService } from '../service/MeetingRoomService';
import { BaseAdminController } from './BaseAdminController';


export class MeetingRoomCtrl extends BaseAdminController {

    private static instance: MeetingRoomCtrl ;

    private constructor() {
        super();
    }
    
    public static getInstance = () => {
        if (MeetingRoomCtrl.instance == null) {
            MeetingRoomCtrl.instance = new MeetingRoomCtrl();
        }
        return MeetingRoomCtrl.instance;
    }
    


    public async getIntents(req: Request, res: Response): Promise<any> {
        let ts = MeetingRoomService.getInstance();
        ts.getMeetingRoomconfigsById(req.params.meetingroomconfigid).then(tenant => {
            res.send(tenant);
        });
    }

    public async createMeetingRoomConfig(req: Request, res: Response): Promise<any> {
        let ts = MeetingRoomService.getInstance();
        ts.createMeetingRoomConfig(req.body).then(tenant => {
            res.send(tenant);
        });
    }

    public async addIntent(req: Request, res: Response): Promise<any> {
        let ts = MeetingRoomService.getInstance();
        ts.addIntent(req.body, req.params.meetingroomconfigid).then(results => {
            res.send(results);
        });
    }
    public async getdocumentbyId(req:Request, res:Response):Promise<any> {
        let ts = MeetingRoomService.getInstance();
        ts.getdocumentbyId(req.body).then(tenant => {
            res.send(tenant);
        });
    }

    
    public async addUtterances(req:Request, res:Response):Promise<any> {
        let ts = MeetingRoomService.getInstance();
        ts.addUtterances(req.body, req.params.meetingroomconfigid).then(results => {
            res.send(results);
        });
    }

    /**
     * 
     * 
     */
    public async getMeetingRoomconfigsById(req: Request, res: Response): Promise<any> {
        if(this.isJsonConfig() ){
            for (let tenant of JsonConfigDao.getTenantCfg()) {
                if(tenant.tenantId == req.query.tenantId) {
                    for (let bot of tenant.tenantBot) {
                        if(bot.botId == req.query.botId){
                            res.send(JsonConfigDao.getMeetingRoomCfg(bot.intentRef));
                        }
                    }
                }
            }

            // const bot = JsonConfigDao.getTenantCfg().tenantBot[0];
            // LoggingUtil.log.debug(bot.intentRef);
            // return JsonConfigDao.getNlpCfg(bot.intentRef);
         } else {
            MeetingRoomService.getInstance().getMeetingRoomconfigsById(req.params.nlpconfigid).then(tenant => {
                res.send(tenant);
            });
        }

    }

    public async getDialogConfig(req: Request, res: Response): Promise<any> {
        if(this.isJsonConfig() ){
            for (let tenant of JsonConfigDao.getTenantCfg()) {
                if(tenant.tenantId == req.query.tenantId) {
                    for (let bot of tenant.tenantBot) {
                        if(bot.botId == req.query.botId){
                            res.send(JsonConfigDao.getDialogConfig(req.query.tenantName,
                                req.query.dialogName));
                        }
                    }
                }
            }
         } else {
                res.send({});
        }

    }

    

}