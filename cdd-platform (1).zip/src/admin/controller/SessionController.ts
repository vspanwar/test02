import { SessionService } from "../service/SessionService";
import { Request, Response } from 'express';
import { LoggingUtil } from "../../common/utils/log4js";

export class SessionController{
    private static instance:SessionController;

    public static getInstance(){
        if(SessionController.instance == null){
            SessionController.instance =  new SessionController();
        }
        return SessionController.instance;
    }

    public async getUserSession(req: Request, res: Response): Promise<any> {
        let ts = SessionService.getInstance();
        ts.getUserSession(req.body).then(user => {
            res.send(user);
        });
    }

    public async getData(req: Request, res: Response): Promise<any> {
        let ts = SessionService.getInstance();
        ts.getData().then(user => {
            res.send(user);
        });
    }

    public async updateUserSession(req: Request, res: Response): Promise<any> {
        let ts = SessionService.getInstance();
        ts.updateUserSession(req.body).then(user => {
            res.send(user);
        });
    }
    
    public async createUserSession(req: Request, res: Response): Promise<any> {
        let ts = SessionService.getInstance();
        ts.createUserSession( req.body).then(user => {
            res.send(user);
        });
    }



    public async appendUserSession(req: Request, res: Response): Promise<any> {
        let ts = SessionService.getInstance();
        ts.appendUserSession(req.body).then(user => {
            res.send(user);
        });
    }

    

}