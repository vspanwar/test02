import { Request, Response } from "express"; 
import { MongoClient, Db } from "mongodb";
import { BaseDao } from "../../common/repository/BaseDao";
import { LoggingUtil } from "../../common/utils/log4js";
const schema= require("../../../resources/config/schema/nlpconfig.json")
var util = require('util')


export class MeetingRoomDao extends BaseDao{
    
    private static meetingroomDao:  MeetingRoomDao;
    private static client= null;
    private static url="mongodb://cdddb:x41fM7ppD9WcC0K6yICuStEv4fR4Ckg3ACfplhIbvwES17tLxOPiex7nOEdkEUpE4jPg7qinBXMKJYmcOrIecA==@cdddb.mongo.cosmos.azure.com:10255?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdddb@"


    public static getInstance():  MeetingRoomDao {

        if ( MeetingRoomDao. meetingroomDao == null) {
            MeetingRoomDao. meetingroomDao = new  MeetingRoomDao()
        }
        
        return  MeetingRoomDao. meetingroomDao;
    }

    private constructor() {
        super("meetingroomdetails")
    }
    public async getdocumentbyId(data:any): Promise<any> {
        
        console.log("Entered in the getNLPApps : ",data.id );
        let payload={}
        payload['query']={'user_id':data.id}
        payload['filter']={}
        let meetingroomApps=await MeetingRoomDao.getInstance().query(payload)
        return meetingroomApps
    }
  
    public async getMeetingRoomconfigsById(id: any): Promise<any> {
        
        console.log("Entered in the getNLPApps : ", id);
        let payload={}
        var nlpConfigId: number = +id;
        payload['query']={'meetingroomConfigId':nlpConfigId}
        payload['filter']={}
        let meetingroomApps=await MeetingRoomDao.getInstance().query(payload)
        return meetingroomApps[0]
        /*let client =await MongoClient.connect(NLPDao.url,{ useUnifiedTopology: true })
        let db=client.db("cdd_dev_db")
        let result= await db.collection("tenants").aggregate([
            {$match:{'tenantBot.tenantId':id}},
            {$project: {
                tenantBot:{ $filter: {
                    input : '$tenantBot',
                    as : 'tenantBot', 
                    cond: { $eq:['$$tenantBot.tenantId',id]}
                }},
                _id:0
            }}
        ]).toArray()
        let nlpApps=result[0].tenantBot[0].nlpApps
        console.log(util.inspect(result, { showHidden: false, depth: null }));*/
        
    
    
    
}

public async createMeetingRoomConfig(data:any){
    LoggingUtil.log.debug("Entered in the create NLP config");
    let payload = await this.setTenantData(data)
    LoggingUtil.log.debug("payload" + JSON.stringify(payload))
    
    let meetingroomConfig=await MeetingRoomDao.getInstance().create(payload)
    return meetingroomConfig
}

public async addIntent(payload:any, id:any){
    console.log("Entered in the add intent");
    var meetingroomConfigId: number = +id;
    let query={"meetingroomConfigId":meetingroomConfigId}
    let data={}
    data['intents']={
        $each:payload.intents
    }
    let meetingroomConfig=await MeetingRoomDao.getInstance().add(query, data)
    return meetingroomConfig
}

public async addUtterances(payload:any, id:any){
    console.log("Entered in the add utterance");
    var meetingroomConfigId: number = +id;
    let query={"meetingroomConfigId":meetingroomConfigId}
    let data={}
    data['utterances']={
        $each:payload.utterances
    }
    let meetingroomConfig=await MeetingRoomDao.getInstance().add(query, data)
    return meetingroomConfig
}




public async getNewMeetingRoomAppId(){
    LoggingUtil.log.debug('Entered in getNewNLPAppId');
    let query={}
    query['meetingroomConfigId']=-1
    let meetingroomApp=await this.getMax(query)
    let newId=meetingroomApp.nlpConfigId + 1
    
    return {"meetingroomConfigId" : newId}
}

public async getIntents(id:string){
    LoggingUtil.log.debug('Entered in get intents');
    var meetingroomConfigId: number = +id;
    let query={}
    query={"meetingroomConfigId":meetingroomConfigId}
    let meetingroomIntents=await this.query(query)
    
    
    return meetingroomIntents
}


public async setTenantData(payload:any){
  
    let meetingroomCfg = {...schema}
    for(var key in payload){
        if(meetingroomCfg.hasOwnProperty(key)){
            meetingroomCfg[key]=payload[key]
        }
    }
    return meetingroomCfg

}



    
}