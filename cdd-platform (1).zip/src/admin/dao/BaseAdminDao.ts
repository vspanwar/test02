import { BaseDao } from "../../common/core/BaseDao";

export abstract class BaseAdminDao extends BaseDao{

}