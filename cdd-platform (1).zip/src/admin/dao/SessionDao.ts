import { BaseDao } from "../../common/repository/BaseDao";
import { LoggingUtil } from "../../common/utils/log4js";
import { Session} from '../model/SessionModel';

export class SessionDao extends BaseDao{
    private static SessionDao:SessionDao;

    public static getInstance(){
        if(SessionDao.SessionDao==null){
            SessionDao.SessionDao = new SessionDao();
        }
        return SessionDao.SessionDao;
    }

    private constructor() {
        super("SessionDB");
    }

    public async createUserSession(payload:Session){
        LoggingUtil.log.info("SessionDao payload Model: "+JSON.stringify(payload));
        let user=await this.create(payload)
        LoggingUtil.log.info("SessionDao added in db: "+JSON.stringify(user));
        return user;
    }

        public async updateUserSession(payload:any){

        LoggingUtil.log.info("Entered update user Session"+JSON.stringify(payload));
        let query={"user_conversation_id":payload.conversationId}
        // let query={'Language_chats':"Chats waiting in queue"}
        let data = {};
        if(payload && payload.updateField !== undefined){
            data[payload.updateField] = payload.payload
        }else{
            data = payload.payload
        }
        
        LoggingUtil.log.info("userDetails  in db: "+JSON.stringify(data));

        let user=await this.update(query,data)
        LoggingUtil.log.info("userDetails updated in db: "+JSON.stringify(user)+" payload:"+JSON.stringify(payload));
        return user;


    }

    public async getData(){
        let result = await this.getAllData()
        return result
    }
    
    public async getUserSession(conversationId:string){
        console.log("CAME HERE444444444")
        let user=await this.findAll()
        LoggingUtil.log.info("getAgentDetails added in db: "+JSON.stringify(user));
        return user;
    }


    public async appendUserSession(payload:any){
        LoggingUtil.log.info("Entered append user Session");
        let query={"user_conversation_id":payload.conversationId}
        let data={}
        data[payload.appendField]={
            $each:payload.appendData
        }
        let user=await this.add(query,data)
        LoggingUtil.log.info("userDetails appended in db: "+JSON.stringify(user)+" payload:"+JSON.stringify(payload));
        return user;
    }

}