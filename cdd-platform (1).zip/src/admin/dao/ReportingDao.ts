import { BaseDao } from "../../common/repository/BaseDao";
import { LoggingUtil } from "../../common/utils/log4js";

export class ReportingDao extends BaseDao{
    private static ReportDao:ReportingDao;

    public static getInstance(){
        if(ReportingDao.ReportDao==null){
            ReportingDao.ReportDao = new ReportingDao();
        }
        return ReportingDao.ReportDao;
    }

    private constructor() {
        super("usecaseReports");
    }

    public async createUserSession(payload:any){
        let user = await this.create(payload)
        LoggingUtil.log.info("useCase added in db: "+JSON.stringify(payload));
        return user;
    }

    public async deleteUserSession(payload:any){

        let user = await this.delete()
        LoggingUtil.log.info("useCase added in db: "+JSON.stringify(payload));
        return user;
    }

    public async getPreviousSession(payload){

        //let payload={conversationId : '60a17c4e39aa445d98bf6dcd'}
        LoggingUtil.log.debug('Entered in ');
        let query={'_id' : -1}
       
        let user =await this.getMaxbyID(payload , query)
        return user;
    }
    
    public async updateUserSession(payload:any){
        LoggingUtil.log.info("Entered update feedback Session"+JSON.stringify(payload));
        let query={"conversationId":payload.conversationId, "active":true}

        let data = {};
        data['feedback']=payload.feedbackPayload
        
        LoggingUtil.log.info("userDetails  in db: "+JSON.stringify(data));

        let user=await this.update(query,data)
        LoggingUtil.log.info("feedback updated in db: "+JSON.stringify(user)+" payload:"+JSON.stringify(payload));
        return user;
    }
    
    public async getUserSession(){
        let payload = {}
        payload['query']={}
        payload['filter']={}
        let user=await this.query(payload)
        LoggingUtil.log.info("userDetails in db: "+JSON.stringify(user));
        return user;
    }

    public async getUserByIDSession(payload){
        let payload1 = {}
        payload1['query']=payload
        payload1['filter']={}
        let user=await this.query(payload1)
        LoggingUtil.log.info("userDetails in db: "+JSON.stringify(user));
        return user;
    }

    public async appendUserSession(payload:any){

        
        let query={"conversationId":payload.conversationId,"active":true}
  
        let data={}
        data['chat']=payload.updatePayload
        let user=await this.add(query,data)
        LoggingUtil.log.info("chat details appended in db: "+JSON.stringify(user)+" payload:"+JSON.stringify(payload));
        return user;
    }

    public async appendChat(payload:any){

        let query={"conversationId":payload.conversationId,"active":true}
  
        let data={}
        data['chat']=payload.updatePayload
        let user=await this.add(query,data)
        LoggingUtil.log.info("chat details appended in db: "+JSON.stringify(user)+" payload:"+JSON.stringify(payload));
        return user;
    }
}