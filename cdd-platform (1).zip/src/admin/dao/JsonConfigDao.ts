import { LoggingUtil } from './../../common/utils/log4js';
const tenantCfg = require('../../../resources/config/tenant.json');

export class JsonConfigDao{

    public static getTenantCfg () {
        LoggingUtil.log.debug('TenantCfg');
         return tenantCfg;
       }
       public static getMeetingRoomCfg (jsonFile:string) {
        LoggingUtil.log.debug(`jsonFile ::${jsonFile}`);
         const cfg = require('../../../resources/config/tenants/'+jsonFile );
         //console.log(cfg);
         return cfg;
       }
  
       public static getNlpCfg (jsonFile:string) {
        LoggingUtil.log.debug(`jsonFile ::${jsonFile}`);
         const cfg = require('../../../resources/config/tenants/'+jsonFile );
         //console.log(cfg);
         return cfg;
       }
  
       public static getDialogConfig (tenantName:string,  dialogName:string) {
            LoggingUtil.log.debug(`tenantName:: ${tenantName} dialogName ::${dialogName}`);
            // if(token.length < 2 )
            //    return {}
            try {
                 const cfg = require('../../../resources/config/tenants/'
                                     +tenantName + '/dialogs/' +  dialogName +'.json');
                  return cfg;
            } catch (e) {
                 LoggingUtil.log.error(`${dialogName} config not found`);
                 return {};
             }
       }

}