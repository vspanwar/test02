import { Request, Response } from "express"; 
import { MongoClient, Db } from "mongodb";
import { BaseDao } from "../../common/repository/BaseDao";
import { LoggingUtil } from "../../common/utils/log4js";
import { NLPDao } from "./NLPDao";
const schema1= require("../../../resources/config/schema/tenant.json")
const dropdown=require("../../../resources/config/schema/dropdown.json")

var util = require('util')

export class TenantBotDao extends BaseDao{
    
    private static tenantBotDao: TenantBotDao;

    private static url="mongodb://cdddb:x41fM7ppD9WcC0K6yICuStEv4fR4Ckg3ACfplhIbvwES17tLxOPiex7nOEdkEUpE4jPg7qinBXMKJYmcOrIecA==@cdddb.mongo.cosmos.azure.com:10255?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdddb@"

    constructor(){
        super("tenants")
    }

    public static getInstance(): TenantBotDao {

        if (TenantBotDao.tenantBotDao == null) {
            TenantBotDao.tenantBotDao = new TenantBotDao()
        }
        
        return TenantBotDao.tenantBotDao;
    }

    public async findTenantBot(id: string): Promise<any> {
        try{
            console.log("Enetred in the findTenantBot : ", id);
            /*let client =await MongoClient.connect(TenantBotDao.url,{ useUnifiedTopology: true })
            let db=client.db("cdd_dev_db")
            let result= await db.collection("tenants").aggregate([
                {$match:{'tenantBot.tenantId':id}},
                {$project: {
                    tenantBot:{ $filter: {
                        input : '$tenantBot',
                        as : 'tenantBot',
                        cond: { $eq:['$$tenantBot.tenantId',id]}
                    }},
                    _id:0
                }}
            ]).toArray()
            console.log(util.inspect(result, { showHidden: false, depth: null }));
            client.close()*/
            var tenantId: number = +id;
            let payload={}
            payload['query']={"tenantId": tenantId}
            payload['filter']={}
            let tenants=await this.query(payload)
            return tenants
        
        }catch(error){
            console.log(`Fetching records failed!`)
            console.log(error)
            return error
        }
        
        
    }

    


    public async getActiveTenantBotDetails(): Promise<any> {
        //console.log("Enetred in the get TenantChannel : ");
        let payload={}
        payload['query']={"tenantStatus": "active"}
        payload['filter']={}
        let tenants=await this.query(payload)
        return tenants
        
    }

    public async getAllTenantBotDetails(): Promise<any> {
        //console.log("Enetred in the get TenantChannel : ");
        let payload={}
        payload['query']={}
        payload['filter']={}
        let tenants=await this.query(payload)
        return tenants
        
    }

    public async createTenant(data:any):Promise<any>{

        LoggingUtil.log.debug("Entered in the crateTenant");
        let newTenantId=await this.getNewTenantId()
        data['tenantId']=newTenantId.tenantId
      
        let payload= await this.setTenantData(data)

        let tenants=await TenantBotDao.getInstance().create(payload)
        return tenants
    }

    public async getNewTenantId():Promise<any>{
        LoggingUtil.log.debug('Entered in getNewTenant');
        let query={}
        query['tenantId']=-1
        let tenant=await this.getMax(query)
        let newId=tenant.tenantId + 1
        
        return {"tenantId" : newId}

    }
    public async addBot(id:any,data:any){
        console.log("Entered in the add bot");
        var tenantId: number = +id;
        let query={"tenantId":tenantId}
        let newBotId=await this.getNewBotId()

        let payload=await this.setBotData(data)
        payload['tenantId']=tenantId
        payload['botId']=newBotId.botId
        let data2={}
        data2["tenantBot"]=payload
        let nlpConfig=await TenantBotDao.getInstance().add(query, data2)
        nlpConfig['botId']=newBotId.botId
        return nlpConfig
    }

   

    public async addChannel(tenant_id:any,bot_id:any, payload:any){

        console.log("Entered in the add channel");
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        let query={"tenantId":tenantId, "tenantBot.botId": botId}
        let data={}
        data['tenantBot.$.channel']=payload
        let response=await TenantBotDao.getInstance().add(query, data)
        return response
    }

    public async extApplication(tenant_id:any,bot_id:any, payload:any){

        console.log("Entered in the add ext application");
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        let query={"tenantId":tenantId, "tenantBot.botId": botId}
        let data={}
        data['tenantBot.$.extApp']=payload
        let response=await TenantBotDao.getInstance().add(query, data)
        return response
    }

    public async getNewBotId(){
        LoggingUtil.log.debug("Getting new bot ID")
        
        
        let response =await TenantBotDao.getInstance().getMaxFromArray("tenantBot","tenantBot.botId", {})
        let max:number = + response.max
        return {"botId" : max + 1}
        

    }

    public async updateRecord(id: string, payload:any){
        var tenantId: number = +id;
        let query={"tenantId":tenantId}
        let response=await TenantBotDao.getInstance().update(query, payload)
        return response

    }

    public async updateChannel(tenant_id: string, bot_id: string, payload:any){
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        let query={"tenantId":tenantId}
        let setPayload={}
        let arrayFilters=[{"tenantBot.botId":botId},{"channel.channelName":payload.channelName}]
        setPayload={"tenantBot.$[tenantBot].channel.$[channel]":payload}
        let response=await TenantBotDao.getInstance().updateInArray(query, setPayload, arrayFilters)
        return response

    }

    public async updateExtApp(tenant_id: string, bot_id:string, payload:any){
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        let query={"tenantId":tenantId}
        let setPayload={}
        let arrayFilters=[{"tenantBot.botId":botId},{"extApp.name":payload.name}]
        setPayload={"tenantBot.$[tenantBot].extApp.$[extApp]":payload}
        let response=await TenantBotDao.getInstance().updateInArray(query, setPayload, arrayFilters)
        return response
    }

    public async updateNLPApp(tenant_id:string, bot_id:string, payload:any){
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        let query={"tenantId":tenantId}
        let setPayload={}
        let arrayFilters=[{"tenantBot.botId":botId},{"nlpApps.nlpConfigId":payload.nlpConfigId}]
        setPayload={"tenantBot.$[tenantBot].nlpApps.$[nlpApps]":payload}
        let response=await TenantBotDao.getInstance().updateInArray(query, setPayload, arrayFilters)


        return response

    }

    public async updateBot(tenant_id: string, bot_id: string, data:any){
        LoggingUtil.log.debug("Inside update bot..!")
        var tenantId: number = +tenant_id;
        var botId: number = +bot_id
        var botData=await this.getBot(botId,tenantId)
        LoggingUtil.log.debug("fetched bot data.. " + JSON.stringify(botData))
        let payload=await this.updateBotData(data,botData.tenantBot[0])
        
        LoggingUtil.log.debug("final payload.. " + payload)
        let query={"tenantId":tenantId}
        let setPayload={}
        let arrayFilters=[{"tenantBot.botId":botId}]
        setPayload={"tenantBot.$[tenantBot]":payload}
        let response=await TenantBotDao.getInstance().updateInArray(query, setPayload, arrayFilters)
        return response

    }

    public async getPlatformChannels(){
        let payload={}
        payload['match']={"$match":{"tenantName": "platform"}}
        payload['project']={"$project": {
                                "tenantBot.channel":{ "$filter": {
                                            input : '$tenantBot.channel',
                                            as : "tenantBot",
                                            cond: {}
                                }},
                        }}
        let channels=await this.aggregate(payload)

        return channels
    }

    public async getBot(botId:any, tenantId:any){
        let payload={}
        payload['match']={"$match":{"tenantId": tenantId}}
        payload['project']={"$project": {
                                "tenantBot":{ "$filter": {
                                input : '$tenantBot',
                                as : 'tenantBot',
                                cond: { $eq:['$$tenantBot.botId',botId]}
                            }},
            _id:0
        }}
        let bots=await this.aggregate(payload)

        return bots
    }

    public async addNLPapp(tenant_id:any, bot_id:any, payload:any){
        LoggingUtil.log.debug("Entered in the add NLP app");

        let newId=await NLPDao.getInstance().getNewNLPAppId()
        payload['nlpConfigId']=newId.nlpConfigId 

        var tenantId: number = +tenant_id;
        var botId: number = +bot_id

        let query={"tenantId":tenantId, "tenantBot.botId": botId}
        let payload2 = {...payload}

        payload2['tenantId']=tenantId
        payload2['botId']=botId
        let data={}
        data['tenantBot.$.nlpApps']=payload
        let response=await TenantBotDao.getInstance().add( query, data)

        let response2= await NLPDao.getInstance().createNLPConfig(payload2)
        response2['nlpConfigId']=newId.nlpConfigId 
        
        
        return response2
    }

    public async replaceTenant(tenant_id:string, payload:any){
        var tenantId: number = +tenant_id;
        let response= await TenantBotDao.getInstance().replace({'tenantId':tenantId},payload)
        return response
    }

    public async getDropdowns(){
        let dropdowns = {...dropdown}
        return dropdowns
    }


    
    public async setTenantData(payload:any){
      
        let tenantCfg = {...schema1.newTenant}
        for(var key in payload){
            if(tenantCfg.hasOwnProperty(key)){
                tenantCfg[key]=payload[key]
            }
        }
        return tenantCfg

    }

    public async setBotData(payload:any){
    
        
        let botCfg = {...schema1.newBot}
        for(var key in payload){
            if(botCfg.hasOwnProperty(key)){
                botCfg[key]=payload[key]
            }
        }
        return botCfg

    }

    public async updateBotData(newData:any, originalData:any){
        for(var key in newData){
            if(originalData.hasOwnProperty(key)){
                originalData[key]=newData[key]
            }
        }
        return originalData
    }
   
}