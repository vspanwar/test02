import { Request, Response } from "express"; 
import { MongoClient, Db } from "mongodb";
import { BaseDao } from "../../common/repository/BaseDao";
import { LoggingUtil } from "../../common/utils/log4js";
const schema= require("../../../resources/config/schema/nlpconfig.json")
var util = require('util')


export class NLPDao extends BaseDao{
    
    private static nlpDao: NLPDao;
    private static client= null;
    private static url="mongodb://cdddb:x41fM7ppD9WcC0K6yICuStEv4fR4Ckg3ACfplhIbvwES17tLxOPiex7nOEdkEUpE4jPg7qinBXMKJYmcOrIecA==@cdddb.mongo.cosmos.azure.com:10255?ssl=true&replicaSet=globaldb&retrywrites=false&maxIdleTimeMS=120000&appName=@cdddb@"


    public static getInstance(): NLPDao {

        if (NLPDao.nlpDao == null) {
            NLPDao.nlpDao = new NLPDao()
        }
        
        return NLPDao.nlpDao;
    }

    private constructor() {
        super("nlpConfigs")
    }
    

  

    
    public async getNLPconfigsById(id: any): Promise<any> {
        
            console.log("Entered in the getNLPApps : ", id);
            let payload={}
            var nlpConfigId: number = +id;
            payload['query']={'nlpConfigId':nlpConfigId}
            payload['filter']={}
            let nlpApps=await NLPDao.getInstance().query(payload)
            return nlpApps[0]
            /*let client =await MongoClient.connect(NLPDao.url,{ useUnifiedTopology: true })
            let db=client.db("cdd_dev_db")
            let result= await db.collection("tenants").aggregate([
                {$match:{'tenantBot.tenantId':id}},
                {$project: {
                    tenantBot:{ $filter: {
                        input : '$tenantBot',
                        as : 'tenantBot', 
                        cond: { $eq:['$$tenantBot.tenantId',id]}
                    }},
                    _id:0
                }}
            ]).toArray()
            let nlpApps=result[0].tenantBot[0].nlpApps
            console.log(util.inspect(result, { showHidden: false, depth: null }));*/
            
        
        
        
    }

    public async createNLPConfig(data:any){
        LoggingUtil.log.debug("Entered in the create NLP config");
        let payload = await this.setTenantData(data)
        LoggingUtil.log.debug("payload" + JSON.stringify(payload))
        
        let nlpConfig=await NLPDao.getInstance().create(payload)
        return nlpConfig
    }

  


    public async addIntent(payload:any, id:any){
        console.log("Entered in the add intent");
        var nlpConfigId: number = +id;
        let query={"nlpConfigId":nlpConfigId}
        let data={}
        data['intents']={
            $each:payload.intents
        }
        let nlpConfig=await NLPDao.getInstance().add(query, data)
        return nlpConfig
    }

    public async addUtterances(payload:any, id:any){
        console.log("Entered in the add utterance");
        var nlpConfigId: number = +id;
        let query={"nlpConfigId":nlpConfigId}
        let data={}
        data['utterances']={
            $each:payload.utterances
        }
        let nlpConfig=await NLPDao.getInstance().add(query, data)
        return nlpConfig
    }



    public async getNewNLPAppId(){
        LoggingUtil.log.debug('Entered in getNewNLPAppId');
        let query={}
        query['nlpConfigId']=-1
        let nlpApp=await this.getMax(query)
        let newId=nlpApp.nlpConfigId + 1
        
        return {"nlpConfigId" : newId}
    }

    public async getIntents(id:string){
        LoggingUtil.log.debug('Entered in get intents');
        var nlpConfigId: number = +id;
        let query={}
        query={"nlpConfigId":nlpConfigId}
        let nlpIntents=await this.query(query)
        
        
        return nlpIntents
    }

    public async replaceNLPConfig(id:string, payload:any){
        var nlpConfigId: number = +id;
        let response= await NLPDao.getInstance().replace({'nlpConfigId':nlpConfigId},payload)
        return response
    
    }


    public async setTenantData(payload:any){
      
        let nlpCfg = {...schema}
        for(var key in payload){
            if(nlpCfg.hasOwnProperty(key)){
                nlpCfg[key]=payload[key]
            }
        }
        return nlpCfg

    }

    



    
}